const fs = require('fs');
let c = fs.readFileSync('src/pages/TaskDetailsDeveloper.tsx', 'utf8');
c = c.replace(/dY"\?/g, '');
c = c.replace(/dY\?\?/g, '✅');
c = c.replace(/\? Auto 3-Hour Report/g, '🕒 Auto 3-Hour Report');
c = c.replace(/\-  Start Task/g, '▶ Start Task');
fs.writeFileSync('src/pages/TaskDetailsDeveloper.tsx', c);
