import React, { createContext, useContext, useState } from 'react';

export type Role = 'manager' | 'developer' | 'sales' | 'tester' | 'client';

export interface User {
  id: string;
  role: Role;
  name?: string;
  email: string;
  publicKey: string;
  encryptedPrivateKey: string;
  managerId?: string;
}

interface AuthContextType {
  user: User | null;
  privateKey: CryptoKey | null;
  login: (userData: User, privKey: CryptoKey) => void;
  logout: () => void;
  isAuthenticated: boolean;
  isManager: boolean;
  isSales: boolean;
  isDeveloper: boolean;
  isTester: boolean;
  isClient: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [privateKey, setPrivateKey] = useState<CryptoKey | null>(null);

  const login = (userData: User, privKey: CryptoKey) => {
    setUser(userData);
    setPrivateKey(privKey);
  };

  const logout = () => {
    setUser(null);
    setPrivateKey(null);
  };

  return (
    <AuthContext.Provider value={{
      user,
      privateKey,
      login,
      logout,
      isAuthenticated: !!user && !!privateKey,
      isManager: user?.role === 'manager',
      isSales: user?.role === 'sales',
      isDeveloper: user?.role === 'developer',
      isTester: user?.role === 'tester',
      isClient: user?.role === 'client'
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const getInitials = (name?: string, fallback = 'U'): string => {
  if (!name || !name.trim()) return fallback;
  const parts = name.trim().split(/\s+/);
  if (parts.length === 1) {
    return parts[0].substring(0, Math.min(2, parts[0].length)).toUpperCase();
  }
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
};

