// src/utils/crypto.ts
// Web Crypto API utility

const ENCRYPTION_ALGO = 'AES-GCM';
const ECDH_ALGO = 'ECDH';
const PBKDF2_ALGO = 'PBKDF2';

/**
 * Utility to convert ArrayBuffer to Base64 and vice versa
 */
export const bufferToBase64 = (buffer: ArrayBuffer): string => {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
};

export const base64ToBuffer = (base64: string): ArrayBuffer => {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes.buffer;
};

/**
 * Generate a new ECDH Key Pair for the user (Manager/Developer)
 */
export const generateKeyPair = async (): Promise<CryptoKeyPair> => {
  return await window.crypto.subtle.generateKey(
    { name: ECDH_ALGO, namedCurve: 'P-256' },
    true,
    ['deriveKey', 'deriveBits']
  );
};

export const exportPublicKey = async (key: CryptoKey): Promise<string> => {
  const exported = await window.crypto.subtle.exportKey('raw', key);
  return bufferToBase64(exported);
};

export const importPublicKey = async (base64Key: string): Promise<CryptoKey> => {
  const buffer = base64ToBuffer(base64Key);
  return await window.crypto.subtle.importKey(
    'raw',
    buffer,
    { name: ECDH_ALGO, namedCurve: 'P-256' },
    true,
    []
  );
};

/**
 * Derive a Key-Encryption Key (KEK) from a password using PBKDF2
 */
export const deriveKeyFromPassword = async (password: string, saltStr: string): Promise<CryptoKey> => {
  const enc = new TextEncoder();
  const keyMaterial = await window.crypto.subtle.importKey(
    'raw',
    enc.encode(password),
    { name: PBKDF2_ALGO },
    false,
    ['deriveBits', 'deriveKey']
  );
  
  return await window.crypto.subtle.deriveKey(
    {
      name: PBKDF2_ALGO,
      salt: enc.encode(saltStr), // using user ID or email as salt
      iterations: 100000,
      hash: 'SHA-256'
    },
    keyMaterial,
    { name: ENCRYPTION_ALGO, length: 256 },
    true,
    ['wrapKey', 'unwrapKey', 'encrypt', 'decrypt']
  );
};

/**
 * Wrap the generated Private Key with the password-derived KEK
 */
export const wrapPrivateKey = async (privateKey: CryptoKey, kek: CryptoKey): Promise<string> => {
  const iv = window.crypto.getRandomValues(new Uint8Array(12));
  const wrapped = await window.crypto.subtle.wrapKey(
    'pkcs8',
    privateKey,
    kek,
    { name: ENCRYPTION_ALGO, iv: iv }
  );
  // Prepend IV to the wrapped key for storage
  const combined = new Uint8Array(iv.length + wrapped.byteLength);
  combined.set(iv);
  combined.set(new Uint8Array(wrapped), iv.length);
  return bufferToBase64(combined.buffer);
};

export const unwrapPrivateKey = async (wrappedKeyB64: string, kek: CryptoKey): Promise<CryptoKey> => {
  const combined = new Uint8Array(base64ToBuffer(wrappedKeyB64));
  const iv = combined.slice(0, 12);
  const wrapped = combined.slice(12);
  
  return await window.crypto.subtle.unwrapKey(
    'pkcs8',
    wrapped,
    kek,
    { name: ENCRYPTION_ALGO, iv: iv },
    { name: ECDH_ALGO, namedCurve: 'P-256' },
    true,
    ['deriveKey', 'deriveBits']
  );
};

/**
 * Derive Shared Secret (Wrapping Key) using ECDH + HKDF
 */
export const deriveSharedSecret = async (myPrivateKey: CryptoKey, theirPublicKey: CryptoKey): Promise<CryptoKey> => {
  return await window.crypto.subtle.deriveKey(
    {
      name: ECDH_ALGO,
      public: theirPublicKey
    },
    myPrivateKey,
    {
      name: ENCRYPTION_ALGO,
      length: 256
    },
    true,
    ['wrapKey', 'unwrapKey']
  );
};

/**
 * Hybrid Encryption for Tasks and Messages
 */
export const encryptHybrid = async (plaintext: string, myPrivateKey: CryptoKey, theirPublicKey: CryptoKey) => {
  // 1. Generate random AES-GCM data key
  const dataKey = await window.crypto.subtle.generateKey(
    { name: ENCRYPTION_ALGO, length: 256 },
    true,
    ['encrypt', 'decrypt']
  );
  
  // 2. Encrypt plaintext
  const iv = window.crypto.getRandomValues(new Uint8Array(12));
  const enc = new TextEncoder();
  const encryptedPayload = await window.crypto.subtle.encrypt(
    { name: ENCRYPTION_ALGO, iv },
    dataKey,
    enc.encode(plaintext)
  );
  
  // 3. Derive Wrapping Key (Shared Secret)
  const wrappingKey = await deriveSharedSecret(myPrivateKey, theirPublicKey);
  
  // 4. Wrap the data key
  const wrappedDataKey = await window.crypto.subtle.wrapKey(
    'raw',
    dataKey,
    wrappingKey,
    { name: ENCRYPTION_ALGO, iv } // Using same IV for simplicity in demo
  );
  
  // Combine IV + Payload for payload, IV + wrapped key for wrappedKey
  const payloadCombined = new Uint8Array(iv.length + encryptedPayload.byteLength);
  payloadCombined.set(iv);
  payloadCombined.set(new Uint8Array(encryptedPayload), iv.length);
  
  const wrappedKeyCombined = new Uint8Array(iv.length + wrappedDataKey.byteLength);
  wrappedKeyCombined.set(iv);
  wrappedKeyCombined.set(new Uint8Array(wrappedDataKey), iv.length);
  
  return {
    encryptedPayload: bufferToBase64(payloadCombined.buffer),
    wrappedKey: bufferToBase64(wrappedKeyCombined.buffer)
  };
};

export const decryptHybrid = async (
  encryptedPayloadB64: string,
  wrappedKeyB64: string,
  myPrivateKey: CryptoKey,
  theirPublicKey: CryptoKey
): Promise<string> => {
  // 1. Derive Wrapping Key
  const wrappingKey = await deriveSharedSecret(myPrivateKey, theirPublicKey);
  
  const wrappedCombined = new Uint8Array(base64ToBuffer(wrappedKeyB64));
  const iv = wrappedCombined.slice(0, 12);
  const wrapped = wrappedCombined.slice(12);
  
  // 2. Unwrap Data Key
  const dataKey = await window.crypto.subtle.unwrapKey(
    'raw',
    wrapped,
    wrappingKey,
    { name: ENCRYPTION_ALGO, iv },
    { name: ENCRYPTION_ALGO, length: 256 },
    true,
    ['encrypt', 'decrypt']
  );
  
  // 3. Decrypt Payload
  const payloadCombined = new Uint8Array(base64ToBuffer(encryptedPayloadB64));
  // payload iv is first 12 bytes
  const payloadIv = payloadCombined.slice(0, 12);
  const encryptedPayload = payloadCombined.slice(12);
  
  const decrypted = await window.crypto.subtle.decrypt(
    { name: ENCRYPTION_ALGO, iv: payloadIv },
    dataKey,
    encryptedPayload
  );
  
  return new TextDecoder().decode(decrypted);
};

// Re-wrap function for Task Reassignment
export const rewrapDataKey = async (
  wrappedKeyB64: string,
  myPrivateKey: CryptoKey,
  oldDeveloperPublicKey: CryptoKey,
  newDeveloperPublicKey: CryptoKey
) => {
  // 1. Derive OLD Wrapping Key
  const oldWrappingKey = await deriveSharedSecret(myPrivateKey, oldDeveloperPublicKey);
  
  const wrappedCombined = new Uint8Array(base64ToBuffer(wrappedKeyB64));
  const iv = wrappedCombined.slice(0, 12);
  const wrapped = wrappedCombined.slice(12);
  
  // 2. Unwrap Data Key
  const dataKey = await window.crypto.subtle.unwrapKey(
    'raw',
    wrapped,
    oldWrappingKey,
    { name: ENCRYPTION_ALGO, iv },
    { name: ENCRYPTION_ALGO, length: 256 },
    true,
    ['encrypt', 'decrypt']
  );
  
  // 3. Derive NEW Wrapping Key
  const newWrappingKey = await deriveSharedSecret(myPrivateKey, newDeveloperPublicKey);
  
  // 4. Wrap Data Key with New Wrapping Key
  const newIv = window.crypto.getRandomValues(new Uint8Array(12));
  const newWrapped = await window.crypto.subtle.wrapKey(
    'raw',
    dataKey,
    newWrappingKey,
    { name: ENCRYPTION_ALGO, iv: newIv }
  );
  
  const newWrappedKeyCombined = new Uint8Array(newIv.length + newWrapped.byteLength);
  newWrappedKeyCombined.set(newIv);
  newWrappedKeyCombined.set(new Uint8Array(newWrapped), newIv.length);
  
  return bufferToBase64(newWrappedKeyCombined.buffer);
};
