import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import type { Role } from './context/AuthContext';
import { Landing } from './pages/Landing';
import { Login } from './pages/Login';
import { ManagerDashboard } from './pages/ManagerDashboard';
import { DeveloperDashboard } from './pages/DeveloperDashboard';
import { SalesDashboard } from './pages/SalesDashboard';
import { TesterDashboard } from './pages/TesterDashboard';
import { ClientDashboard } from './pages/ClientDashboard';
import { TaskDetailsManager } from './pages/TaskDetailsManager';
import { TaskDetailsDeveloper } from './pages/TaskDetailsDeveloper';

const ProtectedRoute = ({ children, role }: { children: React.ReactNode; role?: Role }) => {
  const { isAuthenticated, user } = useAuth();
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  if (role && user?.role !== role) return <Navigate to={`/${user?.role}`} replace />;
  return <>{children}</>;
};

function AppRoutes() {
  const { user, isAuthenticated } = useAuth();

  return (
    <Routes>
      <Route path="/" element={isAuthenticated ? <Navigate to={`/${user?.role}`} replace /> : <Landing />} />
      <Route path="/login" element={<Login />} />

      <Route path="/manager" element={<ProtectedRoute role="manager"><ManagerDashboard /></ProtectedRoute>} />
      <Route path="/manager/tasks/:id" element={<ProtectedRoute role="manager"><TaskDetailsManager /></ProtectedRoute>} />

      <Route path="/developer" element={<ProtectedRoute role="developer"><DeveloperDashboard /></ProtectedRoute>} />
      <Route path="/developer/tasks/:id" element={<ProtectedRoute role="developer"><TaskDetailsDeveloper /></ProtectedRoute>} />

      <Route path="/sales" element={<ProtectedRoute role="sales"><SalesDashboard /></ProtectedRoute>} />
      <Route path="/tester" element={<ProtectedRoute role="tester"><TesterDashboard /></ProtectedRoute>} />
      <Route path="/client" element={<ProtectedRoute role="client"><ClientDashboard /></ProtectedRoute>} />

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <AppRoutes />
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;
