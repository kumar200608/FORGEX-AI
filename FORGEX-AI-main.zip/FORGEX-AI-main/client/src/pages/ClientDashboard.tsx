import React, { useState, useEffect } from 'react';
import { useAuth, getInitials } from '../context/AuthContext';
import { 
  ShieldCheck, Shield, LogOut, 
  AlertTriangle, RefreshCw, ThumbsUp, ThumbsDown, X
} from 'lucide-react';
import { importPublicKey, decryptHybrid } from '../utils/crypto';

interface ClientProject {
  id: string;
  title: string;
  status: string;
  projectType: string;
  quotedPrice: string;
  version: string;
  changeRequestCount: number;
  encryptedPayload: string;
  wrappedKeyClient?: string;
  wrappedKeyManager?: string;
  rejectionReason?: string;
  createdAt: string;
}

export const ClientDashboard = () => {
  const { user, privateKey, logout } = useAuth();
  const [projects, setProjects] = useState<ClientProject[]>([]);
  const [selectedProject, setSelectedProject] = useState<ClientProject | null>(null);
  const [decryptedContent, setDecryptedContent] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const [showChangeModal, setShowChangeModal] = useState(false);
  const [feedbackText, setFeedbackText] = useState('');
  const [submittingFeedback, setSubmittingFeedback] = useState(false);

  const fetchProjects = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const res = await fetch('http://localhost:3001/api/tasks', {
        headers: { 'x-user-id': user.id, 'x-user-role': user.role }
      });
      if (res.ok) setProjects(await res.json() || []);
    } catch (err: any) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchProjects(); }, [user]);

  const handleSelectProject = async (proj: ClientProject) => {
    setSelectedProject(proj);
    setDecryptedContent(null);
    if (proj.wrappedKeyClient && privateKey) {
      try {
        const myPubKey = await importPublicKey(user!.publicKey);
        const text = await decryptHybrid(proj.encryptedPayload, proj.wrappedKeyClient, privateKey, myPubKey);
        setDecryptedContent(text);
      } catch (e) {
        setDecryptedContent('⚠️ Protected Delivery Payload (Encrypted for Client review).');
      }
    } else {
      setDecryptedContent('Recipient-Bound Encrypted Content.');
    }
  };

  const handleSatisfied = async () => {
    if (!selectedProject || !user) return;
    try {
      const res = await fetch(`http://localhost:3001/api/tasks/${selectedProject.id}/client-review`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', 'x-user-id': user.id, 'x-user-role': user.role },
        body: JSON.stringify({ action: 'SATISFIED' })
      });
      if (!res.ok) throw new Error('Failed to submit review');
      alert('Thank you! Project delivery has been completed and locked.');
      setSelectedProject(null);
      fetchProjects();
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleSubmitChangeRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProject || !user) return;
    setSubmittingFeedback(true);
    try {
      const res = await fetch(`http://localhost:3001/api/tasks/${selectedProject.id}/client-review`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', 'x-user-id': user.id, 'x-user-role': user.role },
        body: JSON.stringify({ action: 'NOT_SATISFIED', feedbackPayload: feedbackText })
      });
      if (!res.ok) throw new Error('Failed to submit change request');
      setShowChangeModal(false);
      setFeedbackText('');
      alert('Your update request has been routed directly to the Engineering Manager for review.');
      setSelectedProject(null);
      fetchProjects();
    } catch (err: any) {
      alert(err.message);
    } finally {
      setSubmittingFeedback(false);
    }
  };

  const projectStatusBadge = (status: string) => {
    if (status === 'COMPLETED') return 'glass-badge glass-badge-emerald';
    if (status === 'CLIENT_REVIEW') return 'glass-badge glass-badge-orange';
    if (status === 'REJECTED') return 'glass-badge glass-badge-red';
    return 'glass-badge glass-badge-neutral';
  };

  return (
    <div className="glass-page">
      {/* Header */}
      <header className="glass-nav">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="glass-icon-wrap">
              <ShieldCheck className="w-4 h-4" style={{ color: 'var(--g-accent)' }} />
            </div>
            <span className="text-sm font-bold tracking-tight" style={{ color: 'var(--g-text-primary)' }}>
              Client Secure Portal
            </span>
          </div>
          <div className="flex items-center space-x-3">
            <div className="glass-user-pill hidden sm:inline-flex items-center space-x-2">
              <div className="w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0"
                style={{ background: 'var(--g-accent)', color: '#ffffff' }}>
                {getInitials(user?.name || user?.email, 'C')}
              </div>
              <div className="flex flex-col text-left leading-tight">
                <span className="font-bold text-xs" style={{ color: 'var(--g-text-primary)' }}>
                  {user?.name || user?.email}
                </span>
                <span className="text-[10px] font-medium capitalize" style={{ color: 'var(--g-text-secondary)' }}>
                  Client
                </span>
              </div>
            </div>
            <button onClick={logout} className="glass-signout-btn">
              <LogOut className="w-3.5 h-3.5 text-red-500" />
              <span>Sign Out</span>
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">

        {/* Welcome Banner */}
        <div className="pb-1">
          <h1 className="text-2xl font-black tracking-tight" style={{ color: 'var(--g-text-primary)' }}>
            Welcome, {user?.name || 'Client'}
          </h1>
          <p className="text-xs mt-0.5" style={{ color: 'var(--g-text-secondary)' }}>
            Encrypted deliverables portal, feedback review, and acceptance signoff
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">

          {/* Left: Project list */}
          <div className="lg:col-span-1 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold uppercase tracking-wider" style={{ color: 'var(--g-text-primary)' }}>
                My Projects
              </h2>
              <span className="text-xs font-mono" style={{ color: 'var(--g-text-muted)' }}>{projects.length} records</span>
            </div>

            {loading ? (
              <div className="glass-card p-6 text-xs" style={{ color: 'var(--g-text-muted)' }}>Loading client deliveries...</div>
            ) : projects.length === 0 ? (
              <div className="glass-card p-8 text-center text-xs" style={{ color: 'var(--g-text-muted)' }}>
                No active project deliveries found.
              </div>
            ) : (
              <div className="space-y-3">
                {projects.map(p => (
                  <div
                    key={p.id}
                    onClick={() => handleSelectProject(p)}
                    className="glass-card p-4 cursor-pointer glass-card-hover transition-all"
                    style={selectedProject?.id === p.id ? {
                      background: 'rgba(168,85,247,0.12)',
                      borderColor: 'rgba(168,85,247,0.4)'
                    } : {}}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="text-sm font-bold" style={{ color: 'var(--g-text-primary)' }}>{p.title}</h3>
                        <div className="text-xs mt-1" style={{ color: 'var(--g-text-muted)' }}>
                          Version: <span className="font-mono" style={{ color: 'var(--g-text-secondary)' }}>{p.version || 'v1'}</span>
                        </div>
                      </div>
                      <span className={projectStatusBadge(p.status)}>{p.status.replace(/_/g, ' ')}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Right: Project detail */}
          <div className="lg:col-span-2 space-y-6">
            {selectedProject ? (
              <div className="glass-card p-6 space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4"
                  style={{ borderBottom: '1px solid rgba(168,85,247,0.15)' }}>
                  <div>
                    <h2 className="text-xl font-bold" style={{ color: 'var(--g-text-primary)' }}>{selectedProject.title}</h2>
                    <p className="text-xs mt-1" style={{ color: 'var(--g-text-secondary)' }}>
                      Delivery Version: <strong className="font-mono" style={{ color: 'var(--g-accent)' }}>{selectedProject.version || 'v1'}</strong>
                      {' '}| Change Requests: <strong style={{ color: 'var(--g-text-primary)' }}>{selectedProject.changeRequestCount || 0}</strong>
                    </p>
                  </div>

                  {selectedProject.status === 'CLIENT_REVIEW' && (
                    <div className="flex items-center space-x-3">
                      <button
                        onClick={() => setShowChangeModal(true)}
                        className="glass-btn glass-btn-secondary"
                      >
                        <ThumbsDown className="w-4 h-4" style={{ color: 'var(--g-warning)' }} />
                        <span>Not Satisfied / Request Update</span>
                      </button>
                      <button
                        onClick={handleSatisfied}
                        className="glass-btn glass-btn-success"
                      >
                        <ThumbsUp className="w-4 h-4" />
                        <span>Satisfied (Complete)</span>
                      </button>
                    </div>
                  )}
                </div>

                {/* Rejection notice */}
                {selectedProject.status === 'REJECTED' && (
                  <div className="p-4 rounded-xl space-y-1"
                    style={{ background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.25)' }}>
                    <span className="text-xs font-bold flex items-center space-x-1.5" style={{ color: 'var(--g-danger)' }}>
                      <AlertTriangle className="w-4 h-4" />
                      <span>Manager Decision: Change Request Rejected</span>
                    </span>
                    <p className="text-xs" style={{ color: 'var(--g-text-secondary)' }}>
                      {selectedProject.rejectionReason || 'The Manager determined that the requested change exceeds scope. The project is delivered under current agreement.'}
                    </p>
                  </div>
                )}

                {/* Payload */}
                <div className="space-y-2">
                  <span className="text-xs font-bold uppercase tracking-wider flex items-center space-x-1.5"
                    style={{ color: 'var(--g-text-muted)' }}>
                    <Shield className="w-3.5 h-3.5" style={{ color: 'var(--g-accent)' }} />
                    <span>Protected Delivery Content</span>
                  </span>
                  <div className="glass-code p-5 font-mono text-xs whitespace-pre-wrap leading-relaxed"
                    style={{ color: 'var(--g-text-secondary)' }}>
                    {decryptedContent || 'Decrypting delivery payload...'}
                  </div>
                </div>
              </div>
            ) : (
              <div className="glass-card p-12 text-center space-y-2">
                <ShieldCheck className="w-8 h-8 mx-auto" style={{ color: 'var(--g-text-faint)' }} />
                <p className="text-sm font-medium" style={{ color: 'var(--g-text-muted)' }}>
                  Select a project delivery to view and inspect.
                </p>
              </div>
            )}
          </div>

        </div>
      </main>

      {/* Modal: Change Request */}
      {showChangeModal && (
        <div className="glass-modal-overlay">
          <div className="glass-modal">
            <button onClick={() => setShowChangeModal(false)} className="glass-btn glass-btn-ghost absolute top-4 right-4 p-1">
              <X className="w-4 h-4" style={{ color: 'var(--g-text-muted)' }} />
            </button>
            <div className="flex items-center space-x-2 mb-2">
              <RefreshCw className="w-5 h-5" style={{ color: 'var(--g-accent)' }} />
              <h3 className="text-base font-bold" style={{ color: 'var(--g-text-primary)' }}>Submit Change / Update Request</h3>
            </div>
            <p className="text-xs mb-4" style={{ color: 'var(--g-text-secondary)' }}>
              Your change request will be routed directly to the Engineering Manager for review and decision.
            </p>
            <form onSubmit={handleSubmitChangeRequest} className="space-y-4">
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--g-text-secondary)' }}>Feedback / Issue Details</label>
                <textarea rows={4} required value={feedbackText} onChange={e => setFeedbackText(e.target.value)}
                  placeholder="Describe the issues or required updates..."
                  className="glass-input" />
              </div>
              <div className="flex items-center justify-end space-x-3 pt-2">
                <button type="button" onClick={() => setShowChangeModal(false)} className="glass-btn glass-btn-ghost text-xs">Cancel</button>
                <button type="submit" disabled={submittingFeedback} className="glass-btn glass-btn-primary">
                  {submittingFeedback ? 'Submitting...' : 'Send Request to Manager'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
