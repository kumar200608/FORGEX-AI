import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Shield, Lock, Eye, EyeOff, ArrowLeft, X } from 'lucide-react';
import {
  generateKeyPair,
  deriveKeyFromPassword,
  wrapPrivateKey,
  exportPublicKey,
  unwrapPrivateKey
} from '../utils/crypto';

// ─── Forgot Password Modal ───────────────────────────────────────────────────
type FPStep = 'email' | 'otp' | 'newpass' | 'done';

const ForgotPasswordModal = ({ onClose }: { onClose: () => void }) => {
  const [step, setStep] = useState<FPStep>('email');
  const [fpEmail, setFpEmail] = useState('');
  const [fpOtp, setFpOtp] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirmPass, setConfirmPass] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showNewPass, setShowNewPass] = useState(false);
  const [resendCooldown, setResendCooldown] = useState(0);

  useEffect(() => {
    let timer: any;
    if (resendCooldown > 0) {
      timer = setInterval(() => setResendCooldown(c => c - 1), 1000);
    }
    return () => clearInterval(timer);
  }, [resendCooldown]);

  const sendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(''); setLoading(true);
    try {
      const res = await fetch('http://localhost:3001/api/auth/forgot-password/send-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: fpEmail })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setResendCooldown(45);
      setStep('otp');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const verifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const res = await fetch('http://localhost:3001/api/auth/forgot-password/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: fpEmail, otp: fpOtp })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setStep('newpass');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const resetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (newPass.length < 6) { setError('Password must be at least 6 characters.'); return; }
    if (newPass !== confirmPass) { setError('Passwords do not match.'); return; }
    setLoading(true);
    try {
      const newPasswordHash = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(newPass))
        .then(b => Array.from(new Uint8Array(b)).map(x => x.toString(16).padStart(2, '0')).join(''));
      const res = await fetch('http://localhost:3001/api/auth/forgot-password/reset', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: fpEmail, otp: fpOtp, newPasswordHash })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setStep('done');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="glass-modal-overlay">
      <div className="glass-modal max-w-sm w-full p-6 relative">
        <button onClick={onClose} className="glass-btn glass-btn-ghost absolute top-4 right-4 p-1">
          <X className="w-4 h-4" style={{ color: 'var(--g-text-muted)' }} />
        </button>

        {step !== 'done' && (
          <div className="flex items-center space-x-2 mb-6">
            <Lock className="w-5 h-5" style={{ color: 'var(--g-accent)' }} />
            <h3 className="text-base font-bold" style={{ color: 'var(--g-text-primary)' }}>Reset Password</h3>
          </div>
        )}

        {/* Step indicators */}
        {step !== 'done' && (
          <div className="flex items-center space-x-2 mb-6">
            {(['email', 'otp', 'newpass'] as FPStep[]).map((s, i) => (
              <React.Fragment key={s}>
                <div className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold transition-colors ${
                  step === s ? 'glass-btn-primary text-white shadow-sm' :
                  (['email','otp','newpass'].indexOf(step) > i) ? 'glass-badge-emerald' :
                  'glass-badge-neutral'
                }`}>{i + 1}</div>
                {i < 2 && <div className="flex-1 h-px" style={{ background: 'rgba(168,85,247,0.2)' }} />}
              </React.Fragment>
            ))}
          </div>
        )}

        {error && (
          <div className="mb-4 p-3 rounded-lg text-xs"
            style={{ background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.25)', color: 'var(--g-danger)' }}>
            {error}
          </div>
        )}

        {/* Step 1: Enter Email */}
        {step === 'email' && (
          <form onSubmit={sendOtp} className="space-y-4">
            <div>
              <p className="text-xs mb-3" style={{ color: 'var(--g-text-secondary)' }}>
                Enter your account email. We'll generate a verification code.
              </p>
              <label className="block text-xs font-medium mb-1" style={{ color: 'var(--g-text-secondary)' }}>Email address</label>
              <input
                type="email" required value={fpEmail} onChange={e => setFpEmail(e.target.value)}
                placeholder="your@email.com"
                className="glass-input"
              />
            </div>
            <button type="submit" disabled={loading} className="glass-btn glass-btn-primary w-full justify-center py-2.5">
              {loading ? 'Sending...' : 'Send OTP'}
            </button>
          </form>
        )}

        {/* Step 2: Enter OTP */}
        {step === 'otp' && (
          <form onSubmit={verifyOtp} className="space-y-4">
            <div>
              <p className="text-xs mb-1" style={{ color: 'var(--g-text-secondary)' }}>
                OTP sent to <span className="font-semibold" style={{ color: 'var(--g-text-primary)' }}>{fpEmail}</span>
              </p>
              <div className="flex justify-between items-center mt-3 mb-1">
                <label className="text-xs font-medium" style={{ color: 'var(--g-text-secondary)' }}>Enter 6-digit OTP</label>
                <button 
                  type="button"
                  disabled={resendCooldown > 0 || loading}
                  onClick={sendOtp}
                  className="text-xs disabled:opacity-50 font-medium"
                  style={{ color: 'var(--g-accent)' }}
                >
                  {resendCooldown > 0 ? `Resend in ${resendCooldown}s` : 'Resend OTP'}
                </button>
              </div>
              <input
                type="text" required maxLength={6} value={fpOtp} onChange={e => setFpOtp(e.target.value.replace(/\D/g, ''))}
                placeholder="______"
                className="glass-input tracking-widest font-mono text-center text-lg py-2.5"
              />
            </div>
            <div className="flex space-x-2 pt-2">
              <button type="button" onClick={() => setStep('email')} className="glass-btn glass-btn-secondary flex-1 justify-center py-2.5">
                <ArrowLeft className="w-4 h-4 mr-1" /> Back
              </button>
              <button type="submit" disabled={loading || fpOtp.length !== 6} className="glass-btn glass-btn-primary flex-1 justify-center py-2.5">
                {loading ? 'Verifying...' : 'Verify OTP'}
              </button>
            </div>
          </form>
        )}

        {/* Step 3: Enter New Password */}
        {step === 'newpass' && (
          <form onSubmit={resetPassword} className="space-y-4">
            <div>
              <label className="block text-xs font-medium mb-1" style={{ color: 'var(--g-text-secondary)' }}>New Password</label>
              <div className="relative">
                <input
                  type={showNewPass ? 'text' : 'password'} required value={newPass}
                  onChange={e => setNewPass(e.target.value)} placeholder="Minimum 6 characters"
                  className="glass-input pr-10"
                />
                <button type="button" onClick={() => setShowNewPass(!showNewPass)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-500 hover:text-neutral-700">
                  {showNewPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
            <div>
              <label className="block text-xs font-medium mb-1" style={{ color: 'var(--g-text-secondary)' }}>Confirm Password</label>
              <input
                type="password" required value={confirmPass} onChange={e => setConfirmPass(e.target.value)}
                placeholder="Repeat new password"
                className="glass-input"
              />
            </div>
            <button type="submit" disabled={loading} className="glass-btn glass-btn-primary w-full justify-center py-2.5">
              {loading ? 'Updating...' : 'Update Password'}
            </button>
          </form>
        )}

        {/* Done */}
        {step === 'done' && (
          <div className="text-center py-4">
            <div className="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4"
              style={{ background: 'rgba(16,185,129,0.15)', border: '1px solid rgba(16,185,129,0.3)' }}>
              <Shield className="w-6 h-6" style={{ color: 'var(--g-success)' }} />
            </div>
            <h3 className="text-lg font-bold mb-2" style={{ color: 'var(--g-text-primary)' }}>Password Updated</h3>
            <p className="text-xs mb-6" style={{ color: 'var(--g-text-secondary)' }}>
              Your password has been successfully changed. You can now sign in with your new credentials.
            </p>
            <button onClick={onClose} className="glass-btn glass-btn-primary w-full justify-center py-2.5">
              Back to Sign In
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

// ─── Main Login / Signup Page ──────────────────────────────────────────────────
export const Login = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { login } = useAuth();

  const isSignup = searchParams.get('signup') === 'true';
  const roleParam = searchParams.get('role') || 'manager';

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPass, setShowPass] = useState(false);
  const [showConfirmPass, setShowConfirmPass] = useState(false);
  const [showForgot, setShowForgot] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (isSignup) {
      if (!name || !name.trim()) {
        setError('Please enter your name.');
        return;
      }
      if (!email || !email.trim()) {
        setError('Please enter your email address.');
        return;
      }
      if (!password) {
        setError('Please enter a password.');
        return;
      }
      if (!confirmPassword) {
        setError('Please confirm your password.');
        return;
      }
      if (password !== confirmPassword) {
        setError('Passwords do not match.');
        return;
      }
    }

    setLoading(true);

    try {
      if (isSignup) {
        const keyPair = await generateKeyPair();
        const pubKeyStr = await exportPublicKey(keyPair.publicKey);
        const kek = await deriveKeyFromPassword(password, email);
        const wrappedPrivKey = await wrapPrivateKey(keyPair.privateKey, kek);
        const passwordHash = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(password))
          .then(b => Array.from(new Uint8Array(b)).map(x => x.toString(16).padStart(2, '0')).join(''));

        const res = await fetch('http://localhost:3001/api/auth/signup', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            name: name.trim(), 
            email, 
            passwordHash, 
            publicKey: pubKeyStr, 
            encryptedPrivateKey: wrappedPrivKey,
            role: 'manager'
          })
        });
        if (!res.ok) {
          const errData = await res.json().catch(() => ({ error: 'Registration failed' }));
          throw new Error(errData.error || 'Registration failed');
        }
        const data = await res.json();
        login(data.user, keyPair.privateKey);
        navigate('/manager');
      } else {
        const passwordHash = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(password))
          .then(b => Array.from(new Uint8Array(b)).map(x => x.toString(16).padStart(2, '0')).join(''));

        const res = await fetch('http://localhost:3001/api/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, passwordHash })
        });
        if (!res.ok) {
          const errData = await res.json().catch(() => ({ error: 'Authentication failed' }));
          throw new Error(errData.error || 'Authentication failed');
        }
        const data = await res.json();
        const user = data.user;

        let privateKey: CryptoKey;
        if (user.publicKey === 'PENDING') {
          const keyPair = await generateKeyPair();
          const pubKeyStr = await exportPublicKey(keyPair.publicKey);
          const kek = await deriveKeyFromPassword(password, email);
          const wrappedPrivKey = await wrapPrivateKey(keyPair.privateKey, kek);
          const regRes = await fetch('http://localhost:3001/api/auth/register-keys', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ userId: user.id, developerId: user.id, publicKey: pubKeyStr, encryptedPrivateKey: wrappedPrivKey })
          });
          if (!regRes.ok) throw new Error('Failed to register keys');
          user.publicKey = pubKeyStr;
          user.encryptedPrivateKey = wrappedPrivKey;
          privateKey = keyPair.privateKey;
        } else {
          const kek = await deriveKeyFromPassword(password, email);
          privateKey = await unwrapPrivateKey(user.encryptedPrivateKey, kek);
        }

        login(user, privateKey);
        navigate(`/${user.role}`);
      }
    } catch (err: any) {
      setError(err.message || 'Authentication failed');
    } finally {
      setLoading(false);
    }
  };

  const roleTitle = roleParam === 'sales' ? 'Sales' : roleParam === 'tester' ? 'Tester' : roleParam === 'client' ? 'Client' : roleParam === 'developer' ? 'Developer' : 'Manager';
  const title = isSignup ? 'Create Manager Account' : `${roleTitle} Sign In`;

  return (
    <div className="glass-page flex flex-col justify-center py-12 px-4 min-h-screen relative">
      {showForgot && <ForgotPasswordModal onClose={() => setShowForgot(false)} />}

      {/* Top-Left Brand Logo: SECURE WORKSPACE */}
      <div 
        onClick={() => navigate('/')}
        className="absolute top-6 left-6 sm:left-10 flex items-center space-x-2.5 cursor-pointer transition-opacity hover:opacity-80 z-20"
        style={{ position: 'absolute', top: '1.5rem', left: '1.5rem', zIndex: 20 }}
      >
        <div className="glass-icon-wrap w-9 h-9 shadow-sm">
          <Shield className="h-4.5 w-4.5" style={{ color: 'var(--g-accent)' }} />
        </div>
        <span className="text-sm font-bold tracking-tight" style={{ color: '#000000' }}>
          SECURE WORKSPACE
        </span>
      </div>

      {/* Heading */}
      <div className="sm:mx-auto sm:w-full sm:max-w-xl text-center mb-8">
        <h2 className="text-4xl sm:text-5xl font-black tracking-tight" style={{ color: '#000000' }}>
          {title}
        </h2>
        <p className="text-sm sm:text-base mt-2.5 font-semibold" style={{ color: '#000000' }}>
          {isSignup ? 'Manager accounts have full workspace access.' : 'End-to-end encrypted by default.'}
        </p>
      </div>

      {/* Main Glass Card Form with increased width */}
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="glass-card p-8 sm:p-9">
          <form className="space-y-4" onSubmit={handleSubmit}>
            {error && (
              <div className="p-3 rounded-lg text-xs"
                style={{ background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.25)', color: 'var(--g-danger)' }}>
                {error}
              </div>
            )}

            {isSignup && (
              <div>
                <label className="block text-xs font-bold mb-1" style={{ color: '#000000' }}>
                  Name
                </label>
                <input
                  type="text" required value={name} onChange={e => setName(e.target.value)}
                  placeholder="Enter your full name"
                  className="glass-input font-medium"
                  style={{ color: '#000000' }}
                />
              </div>
            )}

            <div>
              <label className="block text-xs font-bold mb-1" style={{ color: '#000000' }}>
                Email address
              </label>
              <input
                type="email" required value={email} onChange={e => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="glass-input font-medium"
                style={{ color: '#000000' }}
              />
            </div>

            <div>
              <label className="block text-xs font-bold mb-1" style={{ color: '#000000' }}>
                Password
              </label>
              <div className="relative">
                <input
                  type={showPass ? 'text' : 'password'} required value={password}
                  onChange={e => setPassword(e.target.value)} placeholder="Your password"
                  className="glass-input pr-10 font-medium"
                  style={{ color: '#000000' }}
                />
                <button type="button" onClick={() => setShowPass(!showPass)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-500 hover:text-neutral-700">
                  {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {isSignup && (
              <div>
                <label className="block text-xs font-bold mb-1" style={{ color: '#000000' }}>
                  Confirm password
                </label>
                <div className="relative">
                  <input
                    type={showConfirmPass ? 'text' : 'password'} required value={confirmPassword}
                    onChange={e => setConfirmPassword(e.target.value)} placeholder="Confirm your password"
                    className="glass-input pr-10 font-medium"
                    style={{ color: '#000000' }}
                  />
                  <button type="button" onClick={() => setShowConfirmPass(!showConfirmPass)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-500 hover:text-neutral-700">
                    {showConfirmPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            )}

            <button
              type="submit" disabled={loading}
              className="glass-btn glass-btn-primary w-full justify-center py-2.5 mt-2"
            >
              {loading ? (
                <span className="flex items-center space-x-2">
                  <Lock className="w-4 h-4 animate-pulse" />
                  <span>Processing...</span>
                </span>
              ) : (isSignup ? 'Create Account' : 'Sign In')}
            </button>
          </form>

          {/* Sign Up + Forgot Password row */}
          {!isSignup && (
            <div className="mt-5 flex items-center justify-between text-xs">
              <button
                onClick={() => navigate('/login?signup=true')}
                className="font-medium hover:underline"
                style={{ color: 'var(--g-accent)' }}
              >
                Create account
              </button>
              <button
                onClick={() => setShowForgot(true)}
                className="font-medium hover:underline"
                style={{ color: 'var(--g-text-secondary)' }}
              >
                Forgot password?
              </button>
            </div>
          )}

          {isSignup && (
            <div className="mt-5 text-center">
              <button
                onClick={() => navigate('/login')}
                className="text-xs font-medium hover:underline"
                style={{ color: 'var(--g-accent)' }}
              >
                Already have an account? Sign in
              </button>
            </div>
          )}
        </div>

        <p className="mt-6 text-center text-xs" style={{ color: 'var(--g-text-muted)' }}>
          All credentials are encrypted locally. Keys never leave your device.
        </p>
      </div>
    </div>
  );
};
