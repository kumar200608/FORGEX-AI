import { Link } from 'react-router-dom';
import { Shield, Lock, RefreshCw, Cpu, ArrowRight, CheckCircle2, MessageSquare } from 'lucide-react';

export const Landing = () => {
  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="glass-page">
      
      {/* HEADER */}
      <header className="glass-nav">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="glass-icon-wrap shadow-sm">
              <Shield className="h-4 w-4" style={{ color: 'var(--g-accent)' }} />
            </div>
            <span className="text-sm font-bold tracking-tight" style={{ color: 'var(--g-text-primary)' }}>
              SECURE WORKSPACE
            </span>
            <span className="glass-badge glass-badge-purple hidden sm:inline-flex">
              ENTERPRISE
            </span>
          </div>

          <nav className="flex items-center space-x-3">
            <button 
              onClick={() => scrollToSection('architecture')} 
              className="glass-btn glass-btn-secondary text-xs"
            >
              Architecture
            </button>
            <button 
              onClick={() => scrollToSection('workflow')} 
              className="glass-btn glass-btn-secondary text-xs hidden md:inline-flex"
            >
              Capabilities
            </button>
            <Link
              to="/login"
              className="glass-btn glass-btn-primary text-xs"
            >
              Launch Workspace
            </Link>
          </nav>
        </div>
      </header>

      {/* HERO SECTION */}
      <section className="relative pt-6 pb-12 md:pt-8 md:pb-16 px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto text-center">
        {/* Status Badge */}
        <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full glass-user-pill text-xs font-mono mb-5 shadow-sm">
          <span className="h-2 w-2 rounded-full animate-pulse" style={{ background: 'var(--g-success)' }} />
          <span className="tracking-wider font-semibold" style={{ color: 'var(--g-text-primary)' }}>
            ENCRYPTION ACTIVE
          </span>
        </div>

        {/* Main Heading */}
        <h1 className="text-4xl sm:text-6xl md:text-7xl font-extrabold tracking-tight leading-tight mb-6" style={{ color: 'var(--g-text-primary)' }}>
          Secure Communication <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-600 via-fuchsia-600 to-pink-500">
            for Manager–Developer Workflows
          </span>
        </h1>

        {/* Subtitle */}
        <p className="text-base sm:text-lg max-w-2xl mx-auto mb-10 leading-relaxed font-normal" style={{ color: 'var(--g-text-secondary)' }}>
          Assign work. Share securely. Track progress. Keep sensitive project data encrypted.
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <Link
            to="/login"
            className="glass-btn glass-btn-primary px-6 py-3 text-sm font-bold shadow-lg"
          >
            OPEN WORKSPACE
            <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
          <button
            onClick={() => scrollToSection('architecture')}
            className="glass-btn glass-btn-secondary px-6 py-3 text-sm font-semibold"
          >
            VIEW SECURITY ARCHITECTURE
          </button>
        </div>
      </section>

      {/* SECTION 1: THE PROBLEM & INTEGRATION STACK */}
      <section id="problem" className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            
            {/* Left Content */}
            <div className="lg:col-span-7 space-y-6">
              <span className="text-xs font-mono font-bold tracking-widest uppercase" style={{ color: 'var(--g-accent)' }}>
                THE PROBLEM
              </span>
              <h2 className="text-2xl sm:text-4xl font-extrabold tracking-tight leading-tight" style={{ color: 'var(--g-text-primary)' }}>
                Built for Secure Project Collaboration.
              </h2>
              <p className="text-sm sm:text-base leading-relaxed" style={{ color: 'var(--g-text-secondary)' }}>
                Managers and developers need to exchange tasks, progress updates, results, messages, and files without exposing sensitive project content to the server.
              </p>

              <div className="space-y-3 pt-2">
                {[
                  {
                    title: 'End-to-End Encryption',
                    desc: 'Sensitive task and communication content is encrypted on the client.',
                    icon: Shield
                  },
                  {
                    title: 'Controlled Access',
                    desc: 'Developers are created and assigned by authorized managers.',
                    icon: Lock
                  },
                  {
                    title: 'Secure Progress Tracking',
                    desc: 'Status reports and submissions remain encrypted.',
                    icon: CheckCircle2
                  },
                  {
                    title: 'Revocable Access',
                    desc: 'Keys can be rotated when access changes.',
                    icon: RefreshCw
                  }
                ].map((item, idx) => (
                  <div key={idx} className="glass-card p-3.5 flex items-start space-x-3">
                    <item.icon className="h-5 w-5 shrink-0 mt-0.5" style={{ color: 'var(--g-accent)' }} />
                    <div>
                      <span className="text-sm font-bold mr-1.5" style={{ color: 'var(--g-text-primary)' }}>{item.title}:</span>
                      <span className="text-sm" style={{ color: 'var(--g-text-secondary)' }}>{item.desc}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Right Card: Technology Stack */}
            <div className="lg:col-span-5">
              <div className="glass-card p-6 shadow-xl relative overflow-hidden">
                <div className="flex items-center justify-between pb-4 mb-5" style={{ borderBottom: '1px solid rgba(168,85,247,0.15)' }}>
                  <span className="text-xs font-mono font-bold tracking-wider uppercase flex items-center" style={{ color: 'var(--g-accent)' }}>
                    <Cpu className="h-4 w-4 mr-2" /> SECURITY STACK
                  </span>
                  <span className="h-2.5 w-2.5 rounded-full animate-pulse" style={{ background: 'var(--g-success)' }} />
                </div>

                <div className="space-y-2.5 font-mono text-xs">
                  {[
                    { tech: 'Web Crypto API', role: 'Client Encryption', badgeClass: 'glass-badge-purple' },
                    { tech: 'AES-256-GCM', role: 'Data Encryption', badgeClass: 'glass-badge-emerald' },
                    { tech: 'ECDH P-256', role: 'Key Agreement', badgeClass: 'glass-badge-blue' },
                    { tech: 'HKDF', role: 'Key Derivation', badgeClass: 'glass-badge-orange' },
                    { tech: 'PBKDF2', role: 'Private Key Protection', badgeClass: 'glass-badge-yellow' }
                  ].map((row, idx) => (
                    <div key={idx} className="flex items-center justify-between py-2.5 px-3 glass-inset">
                      <span className="font-semibold" style={{ color: 'var(--g-text-primary)' }}>{row.tech}</span>
                      <span className={`glass-badge ${row.badgeClass}`}>
                        {row.role}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* SECTION 2: SYSTEM ARCHITECTURE */}
      <section id="architecture" className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          
          <div className="text-center max-w-3xl mx-auto mb-14">
            <span className="text-xs font-mono font-bold tracking-widest uppercase" style={{ color: 'var(--g-accent)' }}>
              SYSTEM ARCHITECTURE
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold mt-2 tracking-tight" style={{ color: 'var(--g-text-primary)' }}>
              Secure Manager–Developer Workflow
            </h2>
          </div>

          {/* 2x2 Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Card 1 */}
            <div className="glass-card p-6 flex flex-col justify-between glass-card-hover">
              <div>
                <div className="flex items-center space-x-2 mb-3">
                  <div className="glass-icon-wrap">
                    <Shield className="h-4 w-4" style={{ color: 'var(--g-accent)' }} />
                  </div>
                  <h3 className="text-base font-bold" style={{ color: 'var(--g-text-primary)' }}>Client-Side Encryption</h3>
                </div>
                <p className="text-xs sm:text-sm leading-relaxed mb-6" style={{ color: 'var(--g-text-secondary)' }}>
                  Sensitive task, message, report, and attachment content is encrypted before it leaves the user's device.
                </p>
              </div>
              <div>
                <Link
                  to="/login"
                  className="inline-flex items-center text-xs font-mono font-bold hover:underline"
                  style={{ color: 'var(--g-accent)' }}
                >
                  OPEN CRYPTO LAB →
                </Link>
              </div>
            </div>

            {/* Card 2 */}
            <div className="glass-card p-6 flex flex-col justify-between glass-card-hover">
              <div>
                <div className="flex items-center space-x-2 mb-3">
                  <div className="glass-icon-wrap">
                    <Lock className="h-4 w-4" style={{ color: 'var(--g-accent)' }} />
                  </div>
                  <h3 className="text-base font-bold" style={{ color: 'var(--g-text-primary)' }}>Encrypted Task Workflow</h3>
                </div>
                <p className="text-xs sm:text-sm leading-relaxed" style={{ color: 'var(--g-text-secondary)' }}>
                  Managers create tasks and developers receive encrypted task data through controlled access.
                </p>
              </div>
            </div>

            {/* Card 3 */}
            <div className="glass-card p-6 flex flex-col justify-between glass-card-hover">
              <div>
                <div className="flex items-center space-x-2 mb-3">
                  <div className="glass-icon-wrap">
                    <CheckCircle2 className="h-4 w-4" style={{ color: 'var(--g-success)' }} />
                  </div>
                  <h3 className="text-base font-bold" style={{ color: 'var(--g-text-primary)' }}>Secure Status Reporting</h3>
                </div>
                <p className="text-xs sm:text-sm leading-relaxed mb-6" style={{ color: 'var(--g-text-secondary)' }}>
                  Developers can submit encrypted progress reports while working, including status, blockers, completed work, and next steps.
                </p>
              </div>
              <div className="flex items-center space-x-2 font-mono text-[10px]">
                <span className="glass-badge glass-badge-neutral">START</span>
                <span className="glass-badge glass-badge-purple">SUBMIT</span>
                <span className="glass-badge glass-badge-emerald">REVIEW</span>
              </div>
            </div>

            {/* Card 4 */}
            <div className="glass-card p-6 flex flex-col justify-between glass-card-hover">
              <div>
                <div className="flex items-center space-x-2 mb-3">
                  <div className="glass-icon-wrap">
                    <MessageSquare className="h-4 w-4" style={{ color: 'var(--g-info)' }} />
                  </div>
                  <h3 className="text-base font-bold" style={{ color: 'var(--g-text-primary)' }}>Real-Time Secure Communication</h3>
                </div>
                <p className="text-xs sm:text-sm leading-relaxed mb-6" style={{ color: 'var(--g-text-secondary)' }}>
                  Manager and developer can exchange encrypted messages and files without exposing plaintext content to the backend.
                </p>
              </div>
              <div>
                <Link
                  to="/login"
                  className="inline-flex items-center text-xs font-mono font-bold hover:underline"
                  style={{ color: 'var(--g-accent)' }}
                >
                  OPEN SECURE CHAT →
                </Link>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* SECTION 3: CORE WORKFLOW TIMELINE */}
      <section id="workflow" className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-5xl mx-auto">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="text-xs font-mono font-bold tracking-widest uppercase" style={{ color: 'var(--g-accent)' }}>
              — CORE WORKFLOW
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold mt-2 tracking-tight" style={{ color: 'var(--g-text-primary)' }}>
              Future Security Capabilities
            </h2>
            <p className="text-sm sm:text-base mt-2" style={{ color: 'var(--g-text-secondary)' }}>
              Ten advanced security capabilities designed to extend beyond the core encrypted workflow.
            </p>
          </div>

          {/* Vertical Timeline */}
          <div className="relative space-y-10 before:absolute before:inset-0 before:left-1/2 before:-translate-x-1/2 before:w-0.5 before:bg-purple-200 hidden md:block">
            { [
              {"num":"01","title":"Blind Search","desc":"Future capability: Search encrypted tasks and messages using privacy-preserving search tokens without maintaining a normal plaintext keyword index.","tags":["Searchable Encryption","Blind Index","Privacy Search"]},
              {"num":"02","title":"Ephemeral Self-Destruct","desc":"Future capability: Sensitive temporary tasks can invalidate their protected encryption keys after completion or expiry, reducing long-term decryptable exposure.","tags":["Ephemeral Data","Key Invalidation","Data Lifecycle"]},
              {"num":"03","title":"Double-Ratchet Forward Secrecy","desc":"Planned capability: Future secure messaging can continuously rotate message keys so that a later long-term key compromise does not automatically expose historical conversations.","tags":["Double Ratchet","Forward Secrecy","Secure Messaging"]},
              {"num":"04","title":"Duress Vault","desc":"Future capability: A separate authentication path can open a decoy workspace during a coercion scenario while keeping the primary sensitive workspace protected.","tags":["Plausible Deniability","Secure Login","Privacy"]},
              {"num":"05","title":"Time-Lock Encryption","desc":"Future capability: Progress reports can be cryptographically protected until a defined time, enforcing when protected information becomes available.","tags":["Time-Lock","Encrypted Reports","Access Timing"]},
              {"num":"06","title":"Audit Integrity Anchoring","desc":"Future capability: Periodic hashes of audit records can be anchored to a trusted external timestamp or public system to make later modification detectable.","tags":["Audit Integrity","Hash Anchoring","Verification"]},
              {"num":"07","title":"Multi-Signature Revocation","desc":"Future capability: High-risk task revocation or reassignment can require approval from multiple authorized parties before access changes take effect.","tags":["Multi-Signature","Access Control","Shared Trust"]},
              {"num":"08","title":"Hardware-Backed Authentication","desc":"Future capability: WebAuthn can bind account authentication to a hardware-backed authenticator such as a security key or platform biometric.","tags":["WebAuthn","Security Key","Strong Authentication"]},
              {"num":"09","title":"Metadata Padding","desc":"Future capability: Requests can be padded toward uniform sizes and traffic patterns to reduce information exposed through message size and timing analysis.","tags":["Traffic Privacy","Metadata Protection","Side-Channel Defense"]},
              {"num":"10","title":"Steganographic Encrypted Attachments","desc":"Future capability: Encrypted report data can optionally be embedded inside an innocent-looking image container, separating content secrecy from the appearance of the file.","tags":["Steganography","Encrypted Attachments","Covert Storage"]}
            ].map((item, idx) => (
              <div key={idx} className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group">
                <div className="flex items-center justify-center w-10 h-10 rounded-full border border-purple-300 bg-white font-mono font-bold text-xs shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 shadow-md z-10" style={{ color: 'var(--g-accent)' }}>
                  {item.num}
                </div>
                <div className="w-[calc(50%-2.5rem)] glass-card p-6 glass-card-hover">
                  <h3 className="text-base font-bold mb-2" style={{ color: 'var(--g-text-primary)' }}>{item.title}</h3>
                  <p className="text-xs leading-relaxed mb-4" style={{ color: 'var(--g-text-secondary)' }}>
                    {item.desc}
                  </p>
                  <div className="flex flex-wrap gap-1.5 font-mono text-[10px]">
                    {item.tags.map((tag, i) => (
                      <span key={i} className="glass-badge glass-badge-purple">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Mobile Timeline view */}
          <div className="space-y-4 md:hidden">
            { [
              {"num":"01","title":"Blind Search","desc":"Future capability: Search encrypted tasks and messages using privacy-preserving search tokens without maintaining a normal plaintext keyword index.","tags":["Searchable Encryption","Blind Index","Privacy Search"]},
              {"num":"02","title":"Ephemeral Self-Destruct","desc":"Future capability: Sensitive temporary tasks can invalidate their protected encryption keys after completion or expiry, reducing long-term decryptable exposure.","tags":["Ephemeral Data","Key Invalidation","Data Lifecycle"]},
              {"num":"03","title":"Double-Ratchet Forward Secrecy","desc":"Planned capability: Future secure messaging can continuously rotate message keys so that a later long-term key compromise does not automatically expose historical conversations.","tags":["Double Ratchet","Forward Secrecy","Secure Messaging"]},
              {"num":"04","title":"Duress Vault","desc":"Future capability: A separate authentication path can open a decoy workspace during a coercion scenario while keeping the primary sensitive workspace protected.","tags":["Plausible Deniability","Secure Login","Privacy"]},
              {"num":"05","title":"Time-Lock Encryption","desc":"Future capability: Progress reports can be cryptographically protected until a defined time, enforcing when protected information becomes available.","tags":["Time-Lock","Encrypted Reports","Access Timing"]},
              {"num":"06","title":"Audit Integrity Anchoring","desc":"Future capability: Periodic hashes of audit records can be anchored to a trusted external timestamp or public system to make later modification detectable.","tags":["Audit Integrity","Hash Anchoring","Verification"]},
              {"num":"07","title":"Multi-Signature Revocation","desc":"Future capability: High-risk task revocation or reassignment can require approval from multiple authorized parties before access changes take effect.","tags":["Multi-Signature","Access Control","Shared Trust"]},
              {"num":"08","title":"Hardware-Backed Authentication","desc":"Future capability: WebAuthn can bind account authentication to a hardware-backed authenticator such as a security key or platform biometric.","tags":["WebAuthn","Security Key","Strong Authentication"]},
              {"num":"09","title":"Metadata Padding","desc":"Future capability: Requests can be padded toward uniform sizes and traffic patterns to reduce information exposed through message size and timing analysis.","tags":["Traffic Privacy","Metadata Protection","Side-Channel Defense"]},
              {"num":"10","title":"Steganographic Encrypted Attachments","desc":"Future capability: Encrypted report data can optionally be embedded inside an innocent-looking image container, separating content secrecy from the appearance of the file.","tags":["Steganography","Encrypted Attachments","Covert Storage"]}
            ].map((item, idx) => (
              <div key={idx} className="glass-card p-5">
                <div className="flex items-center space-x-3 mb-2">
                  <span className="glass-badge glass-badge-purple font-mono">
                    {item.num}
                  </span>
                  <h3 className="text-sm font-bold" style={{ color: 'var(--g-text-primary)' }}>{item.title}</h3>
                </div>
                <p className="text-xs leading-relaxed mb-3" style={{ color: 'var(--g-text-secondary)' }}>{item.desc}</p>
                <div className="flex flex-wrap gap-1 font-mono text-[10px]">
                  {item.tags.map((t, i) => (
                    <span key={i} className="glass-badge glass-badge-purple">{t}</span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SECTION 4: ADVANCED SECURITY CAPABILITIES */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-3xl mx-auto mb-14">
            <span className="text-xs font-mono font-bold tracking-widest uppercase" style={{ color: 'var(--g-accent)' }}>
              ADVANCED CAPABILITIES
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold mt-2 tracking-tight" style={{ color: 'var(--g-text-primary)' }}>
              Security Throughout the Lifecycle
            </h2>
            <p className="text-sm sm:text-base mt-2" style={{ color: 'var(--g-text-secondary)' }}>
              This workspace protects project information from encryption and sharing to search, access changes, and revocation.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                icon: '🔐',
                title: 'Per-Payload Key Isolation',
                desc: 'Every task, message, and report receives a unique AES-GCM data key.',
                how: 'Compromise of one payload key does not expose unrelated content.'
              },
              {
                icon: '🔎',
                title: 'Privacy-Preserving Search',
                desc: 'Find matching records without a plaintext index.',
                how: 'Search encrypted payloads locally in-memory without sending raw keywords to the server.'
              },
              {
                icon: '👥',
                title: 'Recipient-Bound Sharing',
                desc: 'Data keys are protected using the recipient\'s public key.',
                how: 'A copied URL cannot provide the private key needed for decryption.'
              },
              {
                icon: '🔄',
                title: 'Event-Driven Key Rotation',
                desc: 'Cryptographic access logically follows changes in project membership.',
                how: 'When a task is reassigned, payload keys are re-wrapped for the new authorized recipient.'
              },
              {
                icon: '🚫',
                title: 'Future-Access Revocation',
                desc: 'Removing a user physically prevents continued access.',
                how: 'Revocation prevents future authorized access to protected content.'
              },
              {
                icon: '🛡️',
                title: 'Tamper Detection',
                desc: 'Detects unauthorized modification of protected content.',
                how: 'AES-GCM authentication tag failure prevents modified plaintext from being accepted.'
              }
            ].map((cap, idx) => (
              <div key={idx} className="glass-card p-6 glass-card-hover flex flex-col justify-between">
                <div>
                  <div className="text-2xl mb-3">{cap.icon}</div>
                  <h3 className="text-base font-bold mb-2" style={{ color: 'var(--g-text-primary)' }}>{cap.title}</h3>
                  <p className="text-xs leading-relaxed mb-4" style={{ color: 'var(--g-text-secondary)' }}>{cap.desc}</p>
                </div>
                <div className="p-3 glass-inset text-xs" style={{ color: 'var(--g-text-secondary)' }}>
                  <strong style={{ color: 'var(--g-text-primary)' }}>Advantage:</strong> {cap.how}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FINAL CTA */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 text-center">
        <div className="max-w-3xl mx-auto glass-card p-10 md:p-14 shadow-xl">
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight mb-4" style={{ color: 'var(--g-text-primary)' }}>
            Ready to Work Securely?
          </h2>
          <p className="text-sm mb-8" style={{ color: 'var(--g-text-secondary)' }}>
            Get started with cryptographic certainty for all your sensitive project workflows.
          </p>
          <Link
            to="/login"
            className="glass-btn glass-btn-primary px-8 py-3.5 text-sm font-bold shadow-xl"
          >
            LAUNCH WORKSPACE
            <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="py-8 text-center text-xs font-mono" style={{ color: 'var(--g-text-muted)', borderTop: '1px solid rgba(168,85,247,0.15)' }}>
        <p>© 2026 PROTOTYPE • SECURE MANAGER–DEVELOPER WORKSPACE</p>
      </footer>

    </div>
  );
};
