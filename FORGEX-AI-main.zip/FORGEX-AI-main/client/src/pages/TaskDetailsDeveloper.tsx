import React, { useEffect, useState, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Shield, ArrowLeft, Download, Clock, Lock } from 'lucide-react';
import { decryptHybrid, encryptHybrid, importPublicKey } from '../utils/crypto';
import { SecureMessageBox } from '../components/SecureMessageBox';

const DEMO_INTERVAL_MS = 30_000;

export const TaskDetailsDeveloper = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, privateKey } = useAuth();

  const [taskData, setTaskData] = useState<any>(null);
  const [decryptedPayload, setDecryptedPayload] = useState<any>(null);
  const [decryptedReports, setDecryptedReports] = useState<any[]>([]);
  const [managerPubKey, setManagerPubKey] = useState<CryptoKey | null>(null);

  const [tamperError, setTamperError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const [submitting, setSubmitting] = useState(false);
  const [submitDescription, setSubmitDescription] = useState('');
  const [submitFile, setSubmitFile] = useState<File | null>(null);
  const [reportProgress, setReportProgress] = useState(50);
  const [reportBlockers, setReportBlockers] = useState('');
  const [reportNextSteps, setReportNextSteps] = useState('');
  const [demoMode, setDemoMode] = useState(true);

  const reportTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const fileToBase64 = (f: File): Promise<string> =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve((reader.result as string).split(',')[1]);
      reader.onerror = reject;
      reader.readAsDataURL(f);
    });

  useEffect(() => {
    const fetchTask = async () => {
      try {
        const res = await fetch(`http://localhost:3001/api/tasks/${id}`, {
          headers: { 'x-user-id': user!.id, 'x-user-role': user!.role }
        });
        if (!res.ok) throw new Error('Failed to fetch');
        const data = await res.json();
        setTaskData(data.task);

        if (data.task.managerId) {
          const mgrPubRes = await fetch(`http://localhost:3001/api/users/${data.task.managerId}/public-key`);
          const mgrPubData = await mgrPubRes.json();
          if (mgrPubData.publicKey && mgrPubData.publicKey !== 'PENDING') {
            const mgrPubKey = await importPublicKey(mgrPubData.publicKey);
            setManagerPubKey(mgrPubKey);

            try {
              const plainStr = await decryptHybrid(
                data.task.encryptedPayload,
                data.task.wrappedKeyDeveloper || data.task.wrappedKeyManager,
                privateKey!,
                mgrPubKey
              );
              setDecryptedPayload(JSON.parse(plainStr));
            } catch (decErr: any) {
              console.error('Decryption failed:', decErr);
              setTamperError(decErr.message || 'Cryptographic authentication failed');
              fetch(`http://localhost:3001/api/audit`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'x-user-id': user!.id, 'x-user-role': user!.role },
                body: JSON.stringify({ action: `TAMPER DETECTED: Task ${id} payload failed authentication`, taskId: id })
              }).catch(console.error);
            }

            const decReps: any[] = [];
            for (const rep of data.reports || []) {
              try {
                const repStr = await decryptHybrid(rep.encryptedPayload, rep.wrappedKeyDeveloper, privateKey!, mgrPubKey);
                decReps.push({ ...rep, content: JSON.parse(repStr) });
              } catch (e) { /* skip undecryptable */ }
            }
            setDecryptedReports(decReps);
          }
        }
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    fetchTask();
  }, [id, user, privateKey]);

  const startTask = async () => {
    await fetch(`http://localhost:3001/api/tasks/${id}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-user-id': user!.id, 'x-user-role': user!.role },
      body: JSON.stringify({ status: 'IN_PROGRESS' })
    });
    setTaskData((prev: any) => ({ ...prev, status: 'IN_PROGRESS' }));
    if (reportTimerRef.current) clearInterval(reportTimerRef.current);
    reportTimerRef.current = setInterval(() => sendAutoReport(), DEMO_INTERVAL_MS);
  };

  const sendAutoReport = async () => {
    if (!managerPubKey) return;
    const report = {
      progress: reportProgress,
      status: 'IN_PROGRESS',
      completed: ['Auto-reported progress'],
      blockers: reportBlockers || 'None',
      nextSteps: reportNextSteps || 'Continue working',
      timestamp: new Date().toISOString(),
      type: 'auto_3h'
    };
    const payloadStr = JSON.stringify(report);
    const mgrEnc = await encryptHybrid(payloadStr, privateKey!, managerPubKey);
    const myPubKey = await importPublicKey(user!.publicKey);
    const devEnc = await encryptHybrid(payloadStr, privateKey!, myPubKey);
    await fetch(`http://localhost:3001/api/tasks/${id}/reports`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-user-id': user!.id, 'x-user-role': user!.role },
      body: JSON.stringify({ encryptedPayload: mgrEnc.encryptedPayload, wrappedKeyManager: mgrEnc.wrappedKey, wrappedKeyDeveloper: devEnc.wrappedKey, isFinal: false })
    });
    console.log('Auto 3-hour report sent securely.');
  };

  const submitWork = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!managerPubKey) return;
    setSubmitting(true);
    try {
      const submissionObj: any = {
        description: submitDescription,
        progress: 100,
        status: 'SUBMITTED',
        timestamp: new Date().toISOString(),
        type: 'final_submission'
      };
      if (submitFile) {
        submissionObj.attachment = {
          filename: submitFile.name,
          mimeType: submitFile.type,
          data: await fileToBase64(submitFile)
        };
      }
      const payloadStr = JSON.stringify(submissionObj);
      const mgrEnc = await encryptHybrid(payloadStr, privateKey!, managerPubKey);
      const myPubKey = await importPublicKey(user!.publicKey);
      const devEnc = await encryptHybrid(payloadStr, privateKey!, myPubKey);
      await fetch(`http://localhost:3001/api/tasks/${id}/reports`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-user-id': user!.id, 'x-user-role': user!.role },
        body: JSON.stringify({ encryptedPayload: mgrEnc.encryptedPayload, wrappedKeyManager: mgrEnc.wrappedKey, wrappedKeyDeveloper: devEnc.wrappedKey, isFinal: true })
      });
      setTaskData((prev: any) => ({ ...prev, status: 'SUBMITTED' }));
      if (reportTimerRef.current) clearInterval(reportTimerRef.current);
    } catch (e) {
      console.error(e);
    } finally {
      setSubmitting(false);
    }
  };

  const handleDownload = (attachment: any) => {
    const link = document.createElement('a');
    link.href = `data:${attachment.mimeType};base64,${attachment.data}`;
    link.download = attachment.filename;
    link.click();
  };

  const statusBadgeClass = (status: string) => {
    switch (status) {
      case 'IN_PROGRESS': return 'glass-badge glass-badge-yellow';
      case 'SUBMITTED':   return 'glass-badge glass-badge-purple';
      case 'COMPLETED':   return 'glass-badge glass-badge-emerald';
      case 'INCOMPLETE':  return 'glass-badge glass-badge-red';
      default:            return 'glass-badge glass-badge-blue';
    }
  };

  if (loading) return (
    <div className="glass-loading-page">
      <div className="flex items-center space-x-3" style={{ color: 'var(--g-text-secondary)' }}>
        <Lock className="w-5 h-5 animate-pulse" style={{ color: 'var(--g-accent)' }} />
        <span className="text-sm font-mono">Decrypting task locally...</span>
      </div>
    </div>
  );

  if (!taskData) return (
    <div className="glass-page flex items-center justify-center min-h-screen">
      <div className="glass-card p-8 text-center text-sm font-mono" style={{ color: 'var(--g-danger)' }}>
        Task not found or decryption failed.
      </div>
    </div>
  );

  return (
    <div className="glass-page flex flex-col min-h-screen">

      {/* Header */}
      <header className="glass-nav">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 py-3 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <button
              onClick={() => navigate('/developer')}
              className="glass-btn glass-btn-secondary p-1.5"
              title="Back to Developer Workspace"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div className="glass-icon-wrap">
              <Shield className="h-4 w-4" style={{ color: 'var(--g-accent)' }} />
            </div>
            <h1 className="text-sm font-bold truncate max-w-xs" style={{ color: 'var(--g-text-primary)' }}>
              {taskData.title}
            </h1>
            <span className={statusBadgeClass(taskData.status)}>
              {taskData.status}
            </span>
          </div>
          <div className="hidden sm:inline-flex items-center text-[10px] font-mono glass-badge glass-badge-emerald">
            🔒 Decrypted Locally
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-5xl mx-auto px-4 sm:px-6 py-8 w-full grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-5">

          {/* Task Description */}
          <div className="glass-card p-6">
            <h2 className="text-sm font-bold pb-3 mb-4 flex items-center" style={{ color: 'var(--g-text-primary)', borderBottom: '1px solid rgba(168,85,247,0.15)' }}>
              Task Description (Decrypted Locally)
              <span className="ml-2 glass-badge glass-badge-emerald text-[9px]">
                🔒 Unique Payload Key
              </span>
            </h2>

            {tamperError ? (
              <div className="p-4 rounded-xl space-y-1" style={{ background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.25)' }}>
                <h3 className="font-bold flex items-center text-sm" style={{ color: 'var(--g-danger)' }}>
                  <Shield className="w-4 h-4 mr-2" /> ⚠️ TAMPER DETECTED
                </h3>
                <p className="text-xs" style={{ color: 'var(--g-danger)' }}>Encrypted content failed authentication and was not decrypted.</p>
                <p className="text-[10px] font-mono mt-1" style={{ color: 'var(--g-danger)' }}>{tamperError}</p>
                <p className="text-[11px] font-semibold mt-2" style={{ color: 'var(--g-danger)' }}>Unauthorized modification was detected before plaintext was accepted.</p>
              </div>
            ) : decryptedPayload ? (
              <div className="space-y-4">
                {taskData.isEphemeral && (
                  <div className="p-3 rounded-lg space-y-1" style={{ background: 'rgba(239,68,68,0.06)', border: '1px solid rgba(239,68,68,0.2)' }}>
                    <h4 className="text-xs font-semibold flex items-center" style={{ color: 'var(--g-danger)' }}>
                      <Shield className="w-3.5 h-3.5 mr-1" /> EPHEMERAL TASK ACTIVE
                    </h4>
                    <p className="text-[11px]" style={{ color: 'var(--g-danger)' }}>
                      <strong>Retention:</strong> Until completion or overdue. Once completed, the data keys will be shredded from the server.
                    </p>
                  </div>
                )}
                <div className="glass-code p-4 font-mono text-xs leading-relaxed whitespace-pre-wrap" style={{ color: 'var(--g-text-primary)' }}>
                  {decryptedPayload.description || 'No task description available.'}
                </div>
                {decryptedPayload.attachment && (
                  <button onClick={() => handleDownload(decryptedPayload.attachment)}
                    className="glass-btn glass-btn-secondary text-xs">
                    <Download className="w-4 h-4 mr-1 text-purple-600" /> {decryptedPayload.attachment.filename}
                    <span className="ml-2 glass-badge glass-badge-emerald text-[9px]">🔒 Encrypted</span>
                  </button>
                )}
              </div>
            ) : (
              <p className="text-xs font-mono" style={{ color: 'var(--g-text-muted)' }}>
                {taskData.encryptedPayload ? 'Encrypted payload (awaiting local decryption)...' : 'No encrypted payload found.'}
              </p>
            )}
          </div>

          {/* Submit Work */}
          {taskData.status !== 'SUBMITTED' && taskData.status !== 'COMPLETED' && (
            <div className="glass-card p-6">
              <h2 className="text-sm font-bold pb-3 mb-4" style={{ color: 'var(--g-text-primary)', borderBottom: '1px solid rgba(168,85,247,0.15)' }}>
                Encrypt & Submit Work 🔐
              </h2>
              <form onSubmit={submitWork} className="space-y-3">
                <textarea
                  rows={4}
                  placeholder="Describe your completed work..."
                  value={submitDescription}
                  onChange={e => setSubmitDescription(e.target.value)}
                  className="glass-input font-mono text-xs"
                  required
                />
                <input
                  type="file"
                  onChange={e => setSubmitFile(e.target.files?.[0] || null)}
                  className="glass-input text-xs"
                />
                <button type="submit" disabled={submitting}
                  className="glass-btn glass-btn-primary w-full justify-center py-2.5">
                  {submitting ? 'Encrypting & Submitting...' : 'Encrypt & Submit 🔐'}
                </button>
              </form>
            </div>
          )}

          {/* Reports */}
          {decryptedReports.length > 0 && (
            <div className="glass-card p-6">
              <h2 className="text-sm font-bold pb-3 mb-4" style={{ color: 'var(--g-text-primary)', borderBottom: '1px solid rgba(168,85,247,0.15)' }}>
                My Reports
              </h2>
              <ul className="space-y-3">
                {decryptedReports.map((r, i) => (
                  <li key={i} className="glass-inset p-4 space-y-2">
                    <div className="flex justify-between">
                      <span className="font-semibold text-xs" style={{ color: 'var(--g-text-primary)' }}>
                        {r.content.type === 'final_submission' ? '🏁 Final Submission' : '⏱ Auto 3-Hour Report'}
                      </span>
                      <span className="text-[10px] font-mono" style={{ color: 'var(--g-text-muted)' }}>{new Date(r.timestamp).toLocaleString()}</span>
                    </div>
                    <pre className="text-xs p-3 rounded-lg overflow-x-auto font-mono glass-code" style={{ color: 'var(--g-success)' }}>
                      {JSON.stringify(r.content, null, 2)}
                    </pre>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>

        {/* Sidebar */}
        <div className="space-y-5">

          {/* Task Controls */}
          <div className="glass-card p-5">
            <h2 className="text-sm font-bold pb-3 mb-4" style={{ color: 'var(--g-text-primary)', borderBottom: '1px solid rgba(168,85,247,0.15)' }}>
              Task Controls
            </h2>
            {taskData.status === 'ASSIGNED' && (
              <button onClick={startTask}
                className="glass-btn glass-btn-success w-full justify-center">
                ▶ Start Task
              </button>
            )}
            <div className="mt-3 text-xs" style={{ color: 'var(--g-text-secondary)' }}>
              <p><span>Deadline:</span> <strong className="font-mono" style={{ color: 'var(--g-text-primary)' }}>{taskData.deadline ? new Date(taskData.deadline).toLocaleString() : 'N/A'}</strong></p>
            </div>
          </div>

          {/* Auto-Report Config */}
          {taskData.status === 'IN_PROGRESS' && (
            <div className="glass-card p-5">
              <h2 className="text-sm font-bold pb-3 mb-4 flex items-center" style={{ color: 'var(--g-text-primary)', borderBottom: '1px solid rgba(168,85,247,0.15)' }}>
                <Clock className="w-4 h-4 mr-2" style={{ color: 'var(--g-accent)' }} /> Auto-Report Config
              </h2>
              <div className="flex items-center mb-3">
                <input type="checkbox" id="demoMode" checked={demoMode} onChange={e => setDemoMode(e.target.checked)} className="mr-2" />
                <label htmlFor="demoMode" className="text-xs cursor-pointer" style={{ color: 'var(--g-text-secondary)' }}>Demo Mode (30 sec)</label>
              </div>
              <div className="space-y-2.5">
                <label className="text-xs font-medium block" style={{ color: 'var(--g-text-secondary)' }}>Progress % ({reportProgress})</label>
                <input type="range" min={0} max={100} value={reportProgress}
                  onChange={e => setReportProgress(Number(e.target.value))}
                  className="w-full accent-purple-600" />
                <input type="text" placeholder="Blockers..." value={reportBlockers}
                  onChange={e => setReportBlockers(e.target.value)}
                  className="glass-input text-xs" />
                <input type="text" placeholder="Next Steps..." value={reportNextSteps}
                  onChange={e => setReportNextSteps(e.target.value)}
                  className="glass-input text-xs" />
                <button onClick={sendAutoReport}
                  className="glass-btn glass-btn-secondary w-full justify-center text-xs mt-1">
                  Send Report Now 🔐
                </button>
              </div>
            </div>
          )}

          {/* Secure Messaging */}
          {taskData && managerPubKey && (
            <SecureMessageBox
              taskId={id!}
              peerId={taskData.managerId}
              existingMessages={[]}
            />
          )}
        </div>
      </main>
    </div>
  );
};
