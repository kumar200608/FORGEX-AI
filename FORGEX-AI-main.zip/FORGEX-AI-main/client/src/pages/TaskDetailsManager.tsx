import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Shield, ArrowLeft, Download, RotateCcw, Lock } from 'lucide-react';
import { decryptHybrid, importPublicKey } from '../utils/crypto';
import { SecureMessageBox } from '../components/SecureMessageBox';

export const TaskDetailsManager = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, privateKey } = useAuth();
  const [taskData, setTaskData] = useState<any>(null);
  const [decryptedPayload, setDecryptedPayload] = useState<any>(null);
  const [decryptedReports, setDecryptedReports] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [tamperError, setTamperError] = useState<string | null>(null);

  const [developers, setDevelopers] = useState<any[]>([]);
  const [reassignDevId, setReassignDevId] = useState('');
  const [reassigning, setReassigning] = useState(false);

  useEffect(() => {
    const fetchTask = async () => {
      try {
        const headers = { 'x-user-id': user!.id, 'x-user-role': user!.role };
        const [taskRes, devsRes] = await Promise.all([
          fetch(`http://localhost:3001/api/tasks/${id}`, { headers }),
          fetch(`http://localhost:3001/api/users/developers`, { headers })
        ]);
        if (!taskRes.ok) throw new Error('Failed to load task');
        const data = await taskRes.json();
        setTaskData(data.task);
        const devs = await devsRes.json();
        setDevelopers(devs.filter((d: any) => d.publicKey !== 'PENDING' && d.id !== data.task.developerId));

        if (data.task.developerId) {
          const devPubKeyRes = await fetch(`http://localhost:3001/api/users/${data.task.developerId}/public-key`);
          const devPubKeyData = await devPubKeyRes.json();
          if (devPubKeyData.publicKey && devPubKeyData.publicKey !== 'PENDING') {
            const devPubKey = await importPublicKey(devPubKeyData.publicKey);

            try {
              const plaintextStr = await decryptHybrid(
                data.task.encryptedPayload,
                data.task.wrappedKeyDeveloper || data.task.wrappedKeyManager,
                privateKey!,
                devPubKey
              );
              setDecryptedPayload(JSON.parse(plaintextStr));
            } catch (decErr: any) {
              console.error('Decryption failed:', decErr);
              setTamperError(decErr.message || 'Cryptographic authentication failed');
              fetch(`http://localhost:3001/api/audit`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'x-user-id': user!.id, 'x-user-role': user!.role },
                body: JSON.stringify({ action: `TAMPER DETECTED: Task ${id} payload failed authentication`, taskId: id })
              }).catch(console.error);
            }

            const decryptedRepArr = [];
            for (const rep of data.reports || []) {
              try {
                const repPlain = await decryptHybrid(rep.encryptedPayload, rep.wrappedKeyManager, privateKey!, devPubKey);
                decryptedRepArr.push({ ...rep, content: JSON.parse(repPlain) });
              } catch(e) { console.error('Report dec failed', e); }
            }
            setDecryptedReports(decryptedRepArr);
          }
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchTask();
  }, [id, user, privateKey]);

  const handleReassign = async () => {
    if (!reassignDevId) return;
    setReassigning(true);
    try {
      const newDev = developers.find(d => d.id === reassignDevId);
      const newDevPubKey = await importPublicKey(newDev.publicKey);
      const { importPublicKey: _importPubKey, encryptHybrid: _encryptHybrid } = await import('../utils/crypto');
      const newDevEncrypted = await _encryptHybrid(JSON.stringify(decryptedPayload), privateKey!, newDevPubKey);
      const myPubKey = await _importPubKey(user!.publicKey);
      const newMgrEncrypted = await _encryptHybrid(JSON.stringify(decryptedPayload), privateKey!, myPubKey);
      const res = await fetch(`http://localhost:3001/api/tasks/${id}/reassign`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-user-id': user!.id, 'x-user-role': user!.role },
        body: JSON.stringify({
          newDeveloperId: reassignDevId,
          newWrappedKeyDeveloper: newDevEncrypted.wrappedKey,
          encryptedPayload: newDevEncrypted.encryptedPayload,
          wrappedKeyManager: newMgrEncrypted.wrappedKey
        })
      });
      if (res.ok) {
        alert('Task Reassigned Successfully\n\nSecurity Event: Encryption access updated. Access revoked for previous developer.');
        navigate('/manager');
      } else {
        alert('Reassignment failed on server');
      }
    } catch(e) {
      console.error(e);
      alert('Error during reassignment');
    }
    setReassigning(false);
  };

  const handleDownload = (attachment: any) => {
    const link = document.createElement('a');
    link.href = `data:${attachment.mimeType};base64,${attachment.data}`;
    link.download = attachment.filename;
    link.click();
  };

  const statusBadgeClass = (status: string) => {
    switch (status) {
      case 'IN_PROGRESS': return 'glass-badge glass-badge-yellow';
      case 'SUBMITTED':   return 'glass-badge glass-badge-purple';
      case 'COMPLETED':   return 'glass-badge glass-badge-emerald';
      case 'INCOMPLETE':  return 'glass-badge glass-badge-red';
      default:            return 'glass-badge glass-badge-blue';
    }
  };

  if (loading) return (
    <div className="glass-loading-page">
      <div className="flex items-center space-x-3" style={{ color: 'var(--g-text-secondary)' }}>
        <Lock className="w-5 h-5 animate-pulse" style={{ color: 'var(--g-accent)' }} />
        <span className="text-sm font-mono">Decrypting secure task...</span>
      </div>
    </div>
  );

  if (!taskData) return (
    <div className="glass-page flex items-center justify-center min-h-screen">
      <div className="glass-card p-8 text-center text-sm font-mono" style={{ color: 'var(--g-danger)' }}>
        Task not found or access denied.
      </div>
    </div>
  );

  return (
    <div className="glass-page flex flex-col min-h-screen">

      {/* Header */}
      <header className="glass-nav">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 py-3 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <button
              onClick={() => navigate('/manager')}
              className="glass-btn glass-btn-secondary p-1.5"
              title="Back to Manager Workspace"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div className="glass-icon-wrap">
              <Shield className="h-4 w-4" style={{ color: 'var(--g-accent)' }} />
            </div>
            <h1 className="text-sm font-bold truncate max-w-xs" style={{ color: 'var(--g-text-primary)' }}>
              {taskData.title}
            </h1>
            <span className={statusBadgeClass(taskData.status)}>
              {taskData.status}
            </span>
          </div>
          <div className="hidden sm:inline-flex items-center text-[10px] font-mono glass-badge glass-badge-emerald">
            🔒 Unique Payload Key
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-5xl mx-auto px-4 sm:px-6 py-8 w-full grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Main Column */}
        <div className="md:col-span-2 space-y-5">

          {/* Task Info */}
          <div className="glass-card p-6">
            <div className="flex justify-between items-center mb-4 pb-3" style={{ borderBottom: '1px solid rgba(168,85,247,0.15)' }}>
              <h2 className="text-sm font-bold flex items-center" style={{ color: 'var(--g-text-primary)' }}>
                Task Information
                <span className="ml-2 glass-badge glass-badge-emerald text-[9px]">
                  🔒 Client-Side Encrypted
                </span>
              </h2>
              {taskData.isEphemeral && (
                <span className="glass-badge glass-badge-red text-[9px]">
                  EPHEMERAL (SHREDS ON COMPLETE)
                </span>
              )}
            </div>

            {tamperError ? (
              <div className="p-4 rounded-xl space-y-1" style={{ background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.25)' }}>
                <h3 className="font-bold flex items-center text-sm" style={{ color: 'var(--g-danger)' }}>
                  <Shield className="w-4 h-4 mr-2" /> ⚠️ TAMPER DETECTED
                </h3>
                <p className="text-xs" style={{ color: 'var(--g-danger)' }}>Encrypted content failed authentication and was not decrypted.</p>
                <p className="text-[10px] font-mono mt-1" style={{ color: 'var(--g-danger)' }}>{tamperError}</p>
              </div>
            ) : decryptedPayload ? (
              <div className="space-y-4">
                <div className="glass-code p-4 font-mono text-xs leading-relaxed whitespace-pre-wrap" style={{ color: 'var(--g-text-primary)' }}>
                  {decryptedPayload.description || 'No task description available.'}
                </div>
                {decryptedPayload.attachment && (
                  <button onClick={() => handleDownload(decryptedPayload.attachment)}
                    className="glass-btn glass-btn-secondary text-xs">
                    <Download className="w-4 h-4 mr-1 text-purple-600" /> {decryptedPayload.attachment.filename}
                    <span className="ml-2 glass-badge glass-badge-emerald text-[9px]">🔒 Encrypted</span>
                  </button>
                )}
              </div>
            ) : (
              <p className="text-xs font-mono" style={{ color: 'var(--g-text-muted)' }}>
                {taskData.encryptedPayload ? 'Encrypted payload (awaiting local decryption)...' : 'No encrypted payload found.'}
              </p>
            )}
          </div>

          {/* Reports */}
          <div className="glass-card p-6">
            <h2 className="text-sm font-bold pb-3 mb-4" style={{ color: 'var(--g-text-primary)', borderBottom: '1px solid rgba(168,85,247,0.15)' }}>
              Reports & Submissions
            </h2>
            {decryptedReports.length === 0 ? (
              <p className="text-xs text-center py-4" style={{ color: 'var(--g-text-muted)' }}>No reports submitted yet.</p>
            ) : (
              <ul className="space-y-3">
                {decryptedReports.map((r, i) => (
                  <li key={i} className="glass-inset p-4 space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="font-semibold text-xs" style={{ color: 'var(--g-text-primary)' }}>
                        Report {new Date(r.timestamp).toLocaleString()}
                      </span>
                    </div>
                    <pre className="text-xs p-3 rounded-lg overflow-x-auto font-mono glass-code" style={{ color: 'var(--g-success)' }}>
                      {JSON.stringify(r.content, null, 2)}
                    </pre>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-5">

          {/* Revoke & Reassign */}
          <div className="glass-card p-5">
            <h2 className="text-sm font-bold pb-3 mb-4 flex items-center" style={{ color: 'var(--g-text-primary)', borderBottom: '1px solid rgba(168,85,247,0.15)' }}>
              <RotateCcw className="w-4 h-4 mr-2" style={{ color: 'var(--g-accent)' }} /> Revoke & Reassign
            </h2>
            <p className="text-xs mb-4" style={{ color: 'var(--g-text-secondary)' }}>
              Cryptographically revoke access from the current developer and wrap keys for a new developer.
            </p>
            <select
              value={reassignDevId}
              onChange={e => setReassignDevId(e.target.value)}
              className="glass-input text-xs mb-3"
            >
              <option value="">Select new developer...</option>
              {developers.map(d => (
                <option key={d.id} value={d.id}>{d.email}</option>
              ))}
            </select>
            <button
              onClick={handleReassign}
              disabled={!reassignDevId || reassigning}
              className="glass-btn glass-btn-danger-solid w-full justify-center"
            >
              <Shield className="w-4 h-4 mr-1.5" />
              {reassigning ? 'Rotating Keys...' : 'Reassign Task 🔐'}
            </button>
          </div>

          {/* Secure Messaging */}
          {taskData && (
            <SecureMessageBox
              taskId={id!}
              peerId={taskData.developerId}
              existingMessages={taskData.messages || []}
            />
          )}
        </div>
      </main>
    </div>
  );
};
