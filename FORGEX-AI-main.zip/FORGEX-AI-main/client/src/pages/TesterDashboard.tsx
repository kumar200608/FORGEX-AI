import React, { useState, useEffect } from 'react';
import { useAuth, getInitials } from '../context/AuthContext';
import { 
  CheckSquare, Shield, LogOut, CheckCircle, 
  Bug, X
} from 'lucide-react';
import { importPublicKey, decryptHybrid } from '../utils/crypto';

interface BugItem {
  id: string;
  title: string;
  description: string;
  expectedResult: string;
  actualResult: string;
  severity: string;
  status: string;
  createdAt: string;
}

interface TestingTask {
  id: string;
  title: string;
  status: string;
  encryptedPayload: string;
  wrappedKeyTester?: string;
  wrappedKeyManager?: string;
  developerId?: string;
  version?: string;
  createdAt: string;
}

export const TesterDashboard = () => {
  const { user, privateKey, logout } = useAuth();
  const [tasks, setTasks] = useState<TestingTask[]>([]);
  const [selectedTask, setSelectedTask] = useState<TestingTask | null>(null);
  const [bugs, setBugs] = useState<BugItem[]>([]);
  const [decryptedContent, setDecryptedContent] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const [showBugModal, setShowBugModal] = useState(false);
  const [bugTitle, setBugTitle] = useState('');
  const [bugDesc, setBugDesc] = useState('');
  const [expectedRes, setExpectedRes] = useState('');
  const [actualRes, setActualRes] = useState('');
  const [severity, setSeverity] = useState('HIGH');
  const [submittingBug, setSubmittingBug] = useState(false);

  const fetchTasks = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const res = await fetch('http://localhost:3001/api/tasks', {
        headers: { 'x-user-id': user.id, 'x-user-role': user.role }
      });
      if (res.ok) setTasks(await res.json() || []);
    } catch (err: any) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchTasks(); }, [user]);

  const handleSelectTask = async (task: TestingTask) => {
    setSelectedTask(task);
    setDecryptedContent(null);
    setBugs([]);

    if (task.wrappedKeyTester && privateKey) {
      try {
        const myPubKey = await importPublicKey(user!.publicKey);
        const text = await decryptHybrid(task.encryptedPayload, task.wrappedKeyTester, privateKey, myPubKey);
        setDecryptedContent(text);
      } catch (e) {
        setDecryptedContent('⚠️ Submitted Work Payload (Encrypted for Tester & Manager review).');
      }
    } else {
      setDecryptedContent('Encrypted payload (awaiting key wrapping for Tester).');
    }

    try {
      const bRes = await fetch(`http://localhost:3001/api/tasks/${task.id}`);
      if (bRes.ok) {
        const data = await bRes.json();
        setBugs(data.bugs || []);
      }
    } catch (e) {}
  };

  const handleReportBug = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTask || !user) return;
    setSubmittingBug(true);
    try {
      const res = await fetch(`http://localhost:3001/api/tasks/${selectedTask.id}/bugs`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-user-id': user.id, 'x-user-role': user.role },
        body: JSON.stringify({ developerId: selectedTask.developerId, title: bugTitle, description: bugDesc, expectedResult: expectedRes, actualResult: actualRes, severity })
      });
      if (!res.ok) throw new Error('Failed to report bug');
      setShowBugModal(false);
      setBugTitle(''); setBugDesc(''); setExpectedRes(''); setActualRes('');
      fetchTasks();
      handleSelectTask(selectedTask);
    } catch (err: any) {
      alert(err.message);
    } finally {
      setSubmittingBug(false);
    }
  };

  const handleVerifyBug = async (bugId: string) => {
    try {
      const res = await fetch(`http://localhost:3001/api/tasks/bugs/${bugId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', 'x-user-id': user!.id },
        body: JSON.stringify({ status: 'VERIFIED' })
      });
      if (res.ok && selectedTask) handleSelectTask(selectedTask);
    } catch (e) {}
  };

  const handleApproveForManager = async () => {
    if (!selectedTask || !user) return;
    try {
      const res = await fetch(`http://localhost:3001/api/tasks/${selectedTask.id}/tester-approve`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', 'x-user-id': user.id, 'x-user-role': user.role }
      });
      if (!res.ok) throw new Error('Failed to approve for Manager');
      alert('Project successfully approved! Advanced to Manager Final Review.');
      setSelectedTask(null);
      fetchTasks();
    } catch (err: any) {
      alert(err.message);
    }
  };

  const openBugsCount = bugs.filter(b => b.status === 'OPEN' || b.status === 'FIXED').length;

  const taskStatusBadge = (status: string) => {
    if (status === 'TESTING') return 'glass-badge glass-badge-emerald';
    if (status === 'RETURNED_TO_DEVELOPER') return 'glass-badge glass-badge-red';
    return 'glass-badge glass-badge-yellow';
  };

  const bugStatusBadge = (status: string) => {
    if (status === 'VERIFIED') return 'glass-badge glass-badge-emerald';
    if (status === 'FIXED') return 'glass-badge glass-badge-yellow';
    return 'glass-badge glass-badge-red';
  };

  return (
    <div className="glass-page">
      {/* Header */}
      <header className="glass-nav">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="glass-icon-wrap" style={{ background: 'rgba(16,185,129,0.12)', borderColor: 'rgba(16,185,129,0.25)' }}>
              <CheckSquare className="w-4 h-4" style={{ color: 'var(--g-success)' }} />
            </div>
            <span className="text-sm font-bold tracking-tight" style={{ color: 'var(--g-text-primary)' }}>
              Quality Assurance & Testing
            </span>
          </div>
          <div className="flex items-center space-x-3">
            <div className="glass-user-pill hidden sm:inline-flex items-center space-x-2">
              <div className="w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0"
                style={{ background: 'var(--g-success)', color: '#ffffff' }}>
                {getInitials(user?.name || user?.email, 'T')}
              </div>
              <div className="flex flex-col text-left leading-tight">
                <span className="font-bold text-xs" style={{ color: 'var(--g-text-primary)' }}>
                  {user?.name || user?.email}
                </span>
                <span className="text-[10px] font-medium capitalize" style={{ color: 'var(--g-text-secondary)' }}>
                  Tester
                </span>
              </div>
            </div>
            <button onClick={logout} className="glass-signout-btn">
              <LogOut className="w-3.5 h-3.5 text-red-500" />
              <span>Sign Out</span>
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">

        {/* Welcome Greeting */}
        <div className="pb-1">
          <h1 className="text-2xl font-black tracking-tight" style={{ color: 'var(--g-text-primary)' }}>
            Welcome, {user?.name || 'Tester'}
          </h1>
          <p className="text-xs mt-0.5" style={{ color: 'var(--g-text-secondary)' }}>
            Quality assurance testing, defect tracking, and verification pipeline
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">

          {/* Left: Task list */}
          <div className="lg:col-span-1 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold uppercase tracking-wider" style={{ color: 'var(--g-text-primary)' }}>
                Assigned Projects
              </h2>
              <span className="text-xs font-mono" style={{ color: 'var(--g-text-muted)' }}>{tasks.length} total</span>
            </div>

            {loading ? (
              <div className="glass-card p-6 text-xs" style={{ color: 'var(--g-text-muted)' }}>Loading test assignments...</div>
            ) : tasks.length === 0 ? (
              <div className="glass-card p-8 text-center text-xs" style={{ color: 'var(--g-text-muted)' }}>
                No active projects pending testing.
              </div>
            ) : (
              <div className="space-y-3">
                {tasks.map(t => (
                  <div
                    key={t.id}
                    onClick={() => handleSelectTask(t)}
                    className={`glass-card p-4 cursor-pointer transition-all ${
                      selectedTask?.id === t.id ? 'glass-row-selected' : 'glass-card-hover'
                    }`}
                    style={selectedTask?.id === t.id ? {
                      background: 'rgba(168,85,247,0.12)',
                      borderColor: 'rgba(168,85,247,0.4)'
                    } : {}}
                  >
                    <div className="flex items-start justify-between">
                      <h3 className="text-sm font-bold" style={{ color: 'var(--g-text-primary)' }}>{t.title}</h3>
                      <span className={taskStatusBadge(t.status)}>{t.status.replace(/_/g, ' ')}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Right: Task detail */}
          <div className="lg:col-span-2 space-y-6">
            {selectedTask ? (
              <div className="glass-card p-6 space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4"
                  style={{ borderBottom: '1px solid rgba(168,85,247,0.15)' }}>
                  <div>
                    <h2 className="text-xl font-bold" style={{ color: 'var(--g-text-primary)' }}>{selectedTask.title}</h2>
                    <p className="text-xs mt-1" style={{ color: 'var(--g-text-secondary)' }}>
                      Status: <strong style={{ color: 'var(--g-success)' }}>{selectedTask.status}</strong>
                    </p>
                  </div>
                  <div className="flex items-center space-x-3">
                    <button
                      onClick={() => setShowBugModal(true)}
                      className="glass-btn glass-btn-danger"
                    >
                      <Bug className="w-4 h-4" />
                      <span>Report Bug</span>
                    </button>
                    <button
                      onClick={handleApproveForManager}
                      disabled={openBugsCount > 0}
                      className="glass-btn glass-btn-success"
                    >
                      <CheckCircle className="w-4 h-4" />
                      <span>Approve for Manager</span>
                    </button>
                  </div>
                </div>

                {/* Payload */}
                <div className="space-y-2">
                  <span className="text-xs font-bold uppercase tracking-wider flex items-center space-x-1.5"
                    style={{ color: 'var(--g-text-muted)' }}>
                    <Shield className="w-3.5 h-3.5" style={{ color: 'var(--g-success)' }} />
                    <span>Submitted Work Payload</span>
                  </span>
                  <div className="glass-code p-4 font-mono text-xs whitespace-pre-wrap leading-relaxed"
                    style={{ color: 'var(--g-text-secondary)' }}>
                    {decryptedContent || 'Decrypting...'}
                  </div>
                </div>

                {/* Bugs */}
                <div className="space-y-3 pt-2">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-bold flex items-center space-x-2" style={{ color: 'var(--g-text-primary)' }}>
                      <Bug className="w-4 h-4" style={{ color: 'var(--g-warning)' }} />
                      <span>Defects & Test Reports ({bugs.length})</span>
                    </h3>
                  </div>

                  {bugs.length === 0 ? (
                    <div className="glass-inset p-4 text-xs text-center" style={{ color: 'var(--g-text-muted)' }}>
                      No defects recorded for this build.
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {bugs.map(b => (
                        <div key={b.id} className="glass-inset p-3 flex items-center justify-between">
                          <div className="space-y-1">
                            <div className="flex items-center space-x-2">
                              <span className="text-xs font-bold" style={{ color: 'var(--g-text-primary)' }}>{b.title}</span>
                              <span className={bugStatusBadge(b.status)}>{b.status}</span>
                            </div>
                            <p className="text-xs" style={{ color: 'var(--g-text-secondary)' }}>{b.description}</p>
                          </div>
                          {b.status === 'FIXED' && (
                            <button
                              onClick={() => handleVerifyBug(b.id)}
                              className="glass-btn glass-btn-success text-xs"
                            >
                              Verify Fix
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="glass-card p-12 text-center space-y-2">
                <CheckSquare className="w-8 h-8 mx-auto" style={{ color: 'var(--g-text-faint)' }} />
                <p className="text-sm font-medium" style={{ color: 'var(--g-text-muted)' }}>
                  Select a project on the left to begin quality testing.
                </p>
              </div>
            )}
          </div>

        </div>
      </main>

      {/* Modal: Report Bug */}
      {showBugModal && (
        <div className="glass-modal-overlay">
          <div className="glass-modal">
            <button onClick={() => setShowBugModal(false)} className="glass-btn glass-btn-ghost absolute top-4 right-4 p-1">
              <X className="w-4 h-4" style={{ color: 'var(--g-text-muted)' }} />
            </button>
            <div className="flex items-center space-x-2 mb-4">
              <Bug className="w-5 h-5" style={{ color: 'var(--g-danger)' }} />
              <h3 className="text-base font-bold" style={{ color: 'var(--g-text-primary)' }}>Report Defect / Bug</h3>
            </div>
            <form onSubmit={handleReportBug} className="space-y-3">
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--g-text-secondary)' }}>Bug Title</label>
                <input type="text" required value={bugTitle} onChange={e => setBugTitle(e.target.value)}
                  placeholder="e.g. Encryption handshake fails on safari" className="glass-input" />
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--g-text-secondary)' }}>Severity</label>
                <select value={severity} onChange={e => setSeverity(e.target.value)} className="glass-input">
                  <option value="CRITICAL">CRITICAL</option>
                  <option value="HIGH">HIGH</option>
                  <option value="MEDIUM">MEDIUM</option>
                  <option value="LOW">LOW</option>
                </select>
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--g-text-secondary)' }}>Description & Steps to Reproduce</label>
                <textarea rows={3} required value={bugDesc} onChange={e => setBugDesc(e.target.value)} className="glass-input" />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--g-text-secondary)' }}>Expected Result</label>
                  <input type="text" value={expectedRes} onChange={e => setExpectedRes(e.target.value)} className="glass-input" />
                </div>
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--g-text-secondary)' }}>Actual Result</label>
                  <input type="text" value={actualRes} onChange={e => setActualRes(e.target.value)} className="glass-input" />
                </div>
              </div>
              <div className="flex items-center justify-end space-x-3 pt-2">
                <button type="button" onClick={() => setShowBugModal(false)} className="glass-btn glass-btn-ghost text-xs">Cancel</button>
                <button type="submit" disabled={submittingBug} className="glass-btn glass-btn-danger-solid">
                  {submittingBug ? 'Reporting...' : 'Return to Developer'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
