import { useEffect, useState } from 'react';
import { useAuth, getInitials } from '../context/AuthContext';
import { Shield, Lock, LogOut, Clock, Code2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export const DeveloperDashboard = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [tasks, setTasks] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchTasks = async () => {
    try {
      const res = await fetch('http://localhost:3001/api/tasks', {
        headers: { 'x-user-id': user!.id, 'x-user-role': user!.role }
      });
      if (res.ok) setTasks(await res.json());
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchTasks(); }, []);

  const statusBadgeClass = (status: string) => {
    switch(status) {
      case 'ASSIGNED':    return 'glass-badge glass-badge-blue';
      case 'IN_PROGRESS': return 'glass-badge glass-badge-yellow';
      case 'SUBMITTED':   return 'glass-badge glass-badge-purple';
      case 'COMPLETED':   return 'glass-badge glass-badge-emerald';
      case 'INCOMPLETE':  return 'glass-badge glass-badge-red';
      default:            return 'glass-badge glass-badge-neutral';
    }
  };

  const isOverdue = (deadline: string | null, status: string) => {
    if (!deadline || status === 'COMPLETED') return false;
    return new Date(deadline) < new Date();
  };

  if (loading) return (
    <div className="glass-loading-page">
      <div className="flex items-center space-x-3" style={{ color: 'var(--g-text-secondary)' }}>
        <Lock className="w-5 h-5 animate-pulse" style={{ color: 'var(--g-accent)' }} />
        <span className="text-sm font-mono">Loading secure workspace...</span>
      </div>
    </div>
  );

  return (
    <div className="glass-page">

      {/* Header */}
      <header className="glass-nav">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className="glass-icon-wrap">
              <Code2 className="h-4 w-4" style={{ color: 'var(--g-accent)' }} />
            </div>
            <span className="text-sm font-bold tracking-tight" style={{ color: 'var(--g-text-primary)' }}>
              SECURE WORKSPACE
            </span>
            <span className="glass-badge glass-badge-blue">DEVELOPER</span>
          </div>
          <div className="flex items-center space-x-3">
            <div className="glass-user-pill hidden sm:inline-flex items-center space-x-2">
              <div className="w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0"
                style={{ background: 'var(--g-accent)', color: '#ffffff' }}>
                {getInitials(user?.name || user?.email, 'D')}
              </div>
              <div className="flex flex-col text-left leading-tight">
                <span className="font-bold text-xs" style={{ color: 'var(--g-text-primary)' }}>
                  {user?.name || user?.email}
                </span>
                <span className="text-[10px] font-medium capitalize" style={{ color: 'var(--g-text-secondary)' }}>
                  Developer
                </span>
              </div>
            </div>
            <button
              onClick={() => { logout(); navigate('/'); }}
              className="glass-signout-btn"
            >
              <LogOut className="w-3.5 h-3.5 text-red-500" />
              <span>Sign Out</span>
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-5xl mx-auto px-4 sm:px-6 py-8 w-full">

        {/* Welcome Greeting */}
        <div className="mb-6">
          <h1 className="text-2xl font-black tracking-tight" style={{ color: 'var(--g-text-primary)' }}>
            Welcome, {user?.name || 'Developer'}
          </h1>
          <p className="text-xs mt-0.5" style={{ color: 'var(--g-text-secondary)' }}>
            Assigned secure engineering tasks & encrypted cryptographic deliverables
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
          {[
            { label: 'My Tasks',    count: tasks.length,                                        color: 'var(--g-accent)' },
            { label: 'In Progress', count: tasks.filter(t => t.status === 'IN_PROGRESS').length, color: 'var(--g-warning)' },
            { label: 'Submitted',   count: tasks.filter(t => t.status === 'SUBMITTED').length,   color: 'var(--g-accent-pink)' },
            { label: 'Completed',   count: tasks.filter(t => t.status === 'COMPLETED').length,   color: 'var(--g-success)' }
          ].map(item => (
            <div key={item.label} className="glass-stat">
              <p className="text-3xl font-extrabold" style={{ color: item.color }}>{item.count}</p>
              <p className="text-[11px] uppercase font-medium mt-1 tracking-wide" style={{ color: 'var(--g-text-muted)' }}>
                {item.label}
              </p>
            </div>
          ))}
        </div>

        {/* Task List */}
        <div className="glass-card overflow-hidden">
          <div className="px-5 py-4 flex items-center justify-between" style={{ borderBottom: '1px solid rgba(168,85,247,0.15)' }}>
            <h2 className="text-sm font-semibold flex items-center" style={{ color: 'var(--g-text-primary)' }}>
              <Shield className="w-4 h-4 mr-2" style={{ color: 'var(--g-accent)' }} />
              My Assigned Tasks
            </h2>
            <span className="text-xs font-mono" style={{ color: 'var(--g-text-faint)' }}>End-to-End Encrypted</span>
          </div>

          {tasks.length === 0 ? (
            <div className="py-16 text-center">
              <Lock className="w-8 h-8 mx-auto mb-3" style={{ color: 'var(--g-text-faint)' }} />
              <p className="text-sm" style={{ color: 'var(--g-text-muted)' }}>No tasks assigned yet.</p>
              <p className="text-xs mt-1" style={{ color: 'var(--g-text-faint)' }}>Your manager will assign encrypted tasks here.</p>
            </div>
          ) : (
            <ul>
              {tasks.map(task => (
                <li
                  key={task.id}
                  className="glass-row cursor-pointer group"
                  onClick={() => navigate(`/developer/tasks/${task.id}`)}
                >
                  <div className="flex justify-between items-start">
                    <div className="flex-1 min-w-0 mr-3">
                      <p className="text-sm font-medium transition-colors" style={{ color: 'var(--g-text-primary)' }}>
                        {task.title}
                      </p>
                      <div className="flex items-center space-x-3 mt-1">
                        <span className="flex items-center text-xs" style={{ color: 'var(--g-text-muted)' }}>
                          <Clock className="w-3 h-3 mr-1" />
                          {task.deadline ? new Date(task.deadline).toLocaleString() : 'No deadline'}
                        </span>
                        {isOverdue(task.deadline, task.status) && (
                          <span className="glass-badge glass-badge-red">OVERDUE</span>
                        )}
                      </div>
                    </div>
                    <span className={statusBadgeClass(task.status)}>{task.status}</span>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Encryption notice */}
        <div className="mt-4 flex items-center justify-center space-x-2 text-xs" style={{ color: 'var(--g-text-faint)' }}>
          <Shield className="w-3.5 h-3.5" style={{ color: 'var(--g-accent)', opacity: 0.5 }} />
          <span>All task content is end-to-end encrypted. Only you can decrypt it locally.</span>
        </div>
      </main>
    </div>
  );
};
