import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth, getInitials } from '../context/AuthContext';
import { 
  Shield, Plus, Users, Clock, LogOut, 
  UserPlus, Send, XCircle, StopCircle, RefreshCw, LayoutDashboard
} from 'lucide-react';
import { TaskForm } from '../components/TaskForm';
import { importPublicKey, encryptHybrid } from '../utils/crypto';

export const ManagerDashboard = () => {
  const { user, logout, privateKey } = useAuth();
  const navigate = useNavigate();

  const [developers, setDevelopers] = useState<any[]>([]);
  const [testers, setTesters] = useState<any[]>([]);
  const [tasks, setTasks] = useState<any[]>([]);
  const [auditLogs, setAuditLogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showTaskForm, setShowTaskForm] = useState(false);

  const [newEmpName, setNewEmpName] = useState('');
  const [newEmpEmail, setNewEmpEmail] = useState('');
  const [newEmpPassword, setNewEmpPassword] = useState('TempPass123!');
  const [newEmpRole, setNewEmpRole] = useState<'developer' | 'sales' | 'tester'>('developer');
  const [empMsg, setEmpMsg] = useState('');

  const [selectedTaskToAssign, setSelectedTaskToAssign] = useState<any | null>(null);
  const [assignDevId, setAssignDevId] = useState('');
  const [assignTesterId, setAssignTesterId] = useState('');

  const [rejectTaskId, setRejectTaskId] = useState<string | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');

  const [stopTaskId, setStopTaskId] = useState<string | null>(null);
  const [stopReason, setStopReason] = useState('');

  const fetchData = async () => {
    if (!user) return;
    try {
      const headers = { 'x-user-id': user.id, 'x-user-role': user.role };
      const [devsRes, testersRes, tasksRes, logsRes] = await Promise.all([
        fetch('http://localhost:3001/api/users/developers', { headers }),
        fetch('http://localhost:3001/api/users/testers', { headers }),
        fetch('http://localhost:3001/api/tasks', { headers }),
        fetch('http://localhost:3001/api/users/audit', { headers })
      ]);
      setDevelopers(await devsRes.json() || []);
      setTesters(await testersRes.json() || []);
      setTasks(await tasksRes.json() || []);
      setAuditLogs(await logsRes.json() || []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, [user]);

  const handleCreateEmployee = async (e: React.FormEvent) => {
    e.preventDefault();
    setEmpMsg('');
    try {
      const tempPasswordHash = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(newEmpPassword))
        .then(b => Array.from(new Uint8Array(b)).map(x => x.toString(16).padStart(2, '0')).join(''));
      const res = await fetch('http://localhost:3001/api/auth/create-employee', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          managerId: user!.id, 
          name: newEmpName.trim(), 
          email: newEmpEmail, 
          tempPasswordHash, 
          role: newEmpRole 
        })
      });
      const data = await res.json();
      if (res.ok) {
        setEmpMsg(`✅ ${newEmpRole.toUpperCase()} ${data.name || newEmpName} (${newEmpEmail}) created.`);
        setNewEmpName('');
        setNewEmpEmail('');
        fetchData();
      } else {
        setEmpMsg(`❌ ${data.error}`);
      }
    } catch (e: any) {
      setEmpMsg(`❌ ${e.message}`);
    }
  };

  const handleApproveIntake = async (taskId: string) => {
    try {
      const res = await fetch(`http://localhost:3001/api/tasks/${taskId}/manager-approve-intake`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', 'x-user-id': user!.id, 'x-user-role': user!.role }
      });
      if (res.ok) fetchData();
    } catch (e) {}
  };

  const handleAssignDeveloperTester = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTaskToAssign) return;
    try {
      const selectedDev = developers.find(d => d.id === assignDevId);
      const selectedTester = testers.find(t => t.id === assignTesterId);
      let wrappedKeyDeveloper = '';
      let wrappedKeyTester = '';
      if (selectedDev && selectedDev.publicKey && selectedDev.publicKey !== 'PENDING' && privateKey) {
        try {
          const devPubKey = await importPublicKey(selectedDev.publicKey);
          const enc = await encryptHybrid(selectedTaskToAssign.title, privateKey, devPubKey);
          wrappedKeyDeveloper = enc.wrappedKey;
        } catch (e) {}
      } else {
        wrappedKeyDeveloper = selectedTaskToAssign.wrappedKeyManager || '';
      }
      if (selectedTester && selectedTester.publicKey && selectedTester.publicKey !== 'PENDING' && privateKey) {
        try {
          const testerPubKey = await importPublicKey(selectedTester.publicKey);
          const enc = await encryptHybrid(selectedTaskToAssign.title, privateKey, testerPubKey);
          wrappedKeyTester = enc.wrappedKey;
        } catch (e) {}
      } else {
        wrappedKeyTester = selectedTaskToAssign.wrappedKeyManager || '';
      }
      const res = await fetch(`http://localhost:3001/api/tasks/${selectedTaskToAssign.id}/assign-developer`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', 'x-user-id': user!.id, 'x-user-role': user!.role },
        body: JSON.stringify({ developerId: assignDevId, testerId: assignTesterId || null, wrappedKeyDeveloper, wrappedKeyTester })
      });
      if (res.ok) { setSelectedTaskToAssign(null); fetchData(); }
    } catch (e) {}
  };

  const handleDeliverToClient = async (task: any) => {
    try {
      let wrappedKeyClient = task.wrappedKeyManager || '';
      if (task.clientId && privateKey) {
        try {
          const cRes = await fetch(`http://localhost:3001/api/users/${task.clientId}/public-key`);
          const cData = await cRes.json();
          if (cData.publicKey && cData.publicKey !== 'PENDING') {
            const cPubKey = await importPublicKey(cData.publicKey);
            const enc = await encryptHybrid(task.title, privateKey, cPubKey);
            wrappedKeyClient = enc.wrappedKey;
          }
        } catch (e) {}
      }
      const res = await fetch(`http://localhost:3001/api/tasks/${task.id}/deliver-to-client`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', 'x-user-id': user!.id, 'x-user-role': user!.role },
        body: JSON.stringify({ wrappedKeyClient, version: task.version || 'v1' })
      });
      if (res.ok) { alert('Delivered to Client!'); fetchData(); }
    } catch (e) {}
  };

  const handleApproveChangeRequest = async (taskId: string) => {
    try {
      const res = await fetch(`http://localhost:3001/api/tasks/${taskId}/manager-review-change`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', 'x-user-id': user!.id, 'x-user-role': user!.role },
        body: JSON.stringify({ decision: 'APPROVE' })
      });
      if (res.ok) { alert('Client Change Request Approved. Task routed back to Developer.'); fetchData(); }
    } catch (e) {}
  };

  const handleRejectChangeRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!rejectTaskId) return;
    try {
      const res = await fetch(`http://localhost:3001/api/tasks/${rejectTaskId}/manager-review-change`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', 'x-user-id': user!.id, 'x-user-role': user!.role },
        body: JSON.stringify({ decision: 'REJECT', rejectionReason })
      });
      if (res.ok) {
        alert('Client Change Request REJECTED by Manager. Request closed without Developer work.');
        setRejectTaskId(null);
        setRejectionReason('');
        fetchData();
      }
    } catch (e) {}
  };

  const handleStopProject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!stopTaskId) return;
    try {
      const res = await fetch(`http://localhost:3001/api/tasks/${stopTaskId}/stop-project`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', 'x-user-id': user!.id, 'x-user-role': user!.role },
        body: JSON.stringify({ stopReason })
      });
      if (res.ok) {
        alert('Project stopped and closed by Manager.');
        setStopTaskId(null);
        setStopReason('');
        fetchData();
      }
    } catch (e) {}
  };

  if (loading) return (
    <div className="glass-loading-page">
      <div className="flex items-center space-x-3" style={{ color: 'var(--g-text-secondary)' }}>
        <Shield className="w-5 h-5 animate-pulse" style={{ color: 'var(--g-accent)' }} />
        <span className="text-sm font-mono">Loading secure manager workspace...</span>
      </div>
    </div>
  );

  return (
    <div className="glass-page">
      {showTaskForm && (
        <TaskForm
          developers={developers}
          onClose={() => setShowTaskForm(false)}
          onSuccess={() => { setShowTaskForm(false); fetchData(); }}
        />
      )}

      {/* Header */}
      <header className="glass-nav">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className="glass-icon-wrap">
              <LayoutDashboard className="h-4 w-4" style={{ color: 'var(--g-accent)' }} />
            </div>
            <span className="text-sm font-bold tracking-tight" style={{ color: 'var(--g-text-primary)' }}>
              SECURE ENTERPRISE WORKFLOW
            </span>
            <span className="glass-badge glass-badge-purple">MANAGER CONTROL</span>
          </div>
          <div className="flex items-center space-x-3">
            <div className="glass-user-pill hidden sm:inline-flex items-center space-x-2">
              <div className="w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0"
                style={{ background: 'var(--g-accent)', color: '#ffffff' }}>
                {getInitials(user?.name || user?.email, 'M')}
              </div>
              <div className="flex flex-col text-left leading-tight">
                <span className="font-bold text-xs" style={{ color: 'var(--g-text-primary)' }}>
                  {user?.name || user?.email}
                </span>
                <span className="text-[10px] font-medium capitalize" style={{ color: 'var(--g-text-secondary)' }}>
                  Manager
                </span>
              </div>
            </div>
            <button
              onClick={() => { logout(); navigate('/'); }}
              className="glass-signout-btn"
            >
              <LogOut className="w-3.5 h-3.5 text-red-500" />
              <span>Sign Out</span>
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 py-8 w-full grid grid-cols-1 lg:grid-cols-3 gap-8">

        {/* Main Column */}
        <div className="lg:col-span-2 space-y-6">

          {/* Welcome Greeting */}
          <div className="pb-1">
            <h1 className="text-2xl font-black tracking-tight" style={{ color: 'var(--g-text-primary)' }}>
              Welcome, {user?.name || 'Manager'}
            </h1>
            <p className="text-xs mt-0.5" style={{ color: 'var(--g-text-secondary)' }}>
              End-to-end encrypted enterprise operations & resource orchestration
            </p>
          </div>

          {/* Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { label: 'Sales Intakes', value: tasks.filter(t => t.status === 'SENT_TO_MANAGER').length, color: 'var(--g-warning)' },
              { label: 'In Development', value: tasks.filter(t => t.status === 'IN_DEVELOPMENT' || t.status === 'DEVELOPER_ASSIGNED').length, color: 'var(--g-accent)' },
              { label: 'Testing / Review', value: tasks.filter(t => t.status === 'TESTING' || t.status === 'MANAGER_REVIEW').length, color: 'var(--g-accent-pink)' },
              { label: 'Client Reviews', value: tasks.filter(t => t.status === 'CLIENT_REVIEW' || t.status === 'CHANGES_REQUESTED').length, color: 'var(--g-info)' }
            ].map(s => (
              <div key={s.label} className="glass-stat">
                <p className="text-2xl font-extrabold" style={{ color: s.color }}>{s.value}</p>
                <p className="text-[11px] font-medium mt-1 uppercase tracking-wide" style={{ color: 'var(--g-text-muted)' }}>{s.label}</p>
              </div>
            ))}
          </div>

          {/* Sales Intakes */}
          <div className="glass-card p-5 space-y-4">
            <div className="flex items-center justify-between pb-3" style={{ borderBottom: '1px solid rgba(168,85,247,0.15)' }}>
              <h2 className="text-sm font-bold flex items-center space-x-2" style={{ color: 'var(--g-text-primary)' }}>
                <Send className="w-4 h-4" style={{ color: 'var(--g-warning)' }} />
                <span>Sales Requirements & Quotation Approvals</span>
              </h2>
              <span className="text-xs font-mono" style={{ color: 'var(--g-text-muted)' }}>
                {tasks.filter(t => t.status === 'SENT_TO_MANAGER').length} pending
              </span>
            </div>

            {tasks.filter(t => t.status === 'SENT_TO_MANAGER').length === 0 ? (
              <div className="p-4 text-center text-xs" style={{ color: 'var(--g-text-muted)' }}>No pending Sales intake requests.</div>
            ) : (
              <div className="space-y-3">
                {tasks.filter(t => t.status === 'SENT_TO_MANAGER').map(t => (
                  <div key={t.id} className="glass-inset p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="space-y-1">
                      <div className="flex items-center space-x-2">
                        <span className="text-sm font-bold" style={{ color: 'var(--g-text-primary)' }}>{t.title}</span>
                        <span className="glass-badge glass-badge-neutral">{t.projectType || 'Web App'}</span>
                      </div>
                      <div className="text-xs flex items-center space-x-3" style={{ color: 'var(--g-text-secondary)' }}>
                        <span>Budget: <strong style={{ color: 'var(--g-success)' }}>{t.clientBudget}</strong></span>
                        <span>Quoted: <strong style={{ color: 'var(--g-accent)' }}>{t.quotedPrice}</strong></span>
                      </div>
                    </div>
                    <button onClick={() => handleApproveIntake(t.id)} className="glass-btn glass-btn-success">
                      Approve Project Intake
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Assign Developer & Tester */}
          <div className="glass-card p-5 space-y-4">
            <div className="flex items-center justify-between pb-3" style={{ borderBottom: '1px solid rgba(168,85,247,0.15)' }}>
              <h2 className="text-sm font-bold flex items-center space-x-2" style={{ color: 'var(--g-text-primary)' }}>
                <Users className="w-4 h-4" style={{ color: 'var(--g-accent)' }} />
                <span>Assign Developer & Tester to Approved Projects</span>
              </h2>
            </div>

            {tasks.filter(t => t.status === 'APPROVED').length === 0 ? (
              <div className="p-4 text-center text-xs" style={{ color: 'var(--g-text-muted)' }}>No approved projects awaiting assignment.</div>
            ) : (
              <div className="space-y-3">
                {tasks.filter(t => t.status === 'APPROVED').map(t => (
                  <div key={t.id} className="glass-inset p-4 flex items-center justify-between">
                    <div>
                      <h3 className="text-sm font-bold" style={{ color: 'var(--g-text-primary)' }}>{t.title}</h3>
                      <p className="text-xs" style={{ color: 'var(--g-text-muted)' }}>Status: Approved by Manager</p>
                    </div>
                    <button onClick={() => setSelectedTaskToAssign(t)} className="glass-btn glass-btn-primary">
                      Assign Resources
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Client Change Request Triage */}
          <div className="glass-card p-5 space-y-4">
            <div className="flex items-center justify-between pb-3" style={{ borderBottom: '1px solid rgba(168,85,247,0.15)' }}>
              <h2 className="text-sm font-bold flex items-center space-x-2" style={{ color: 'var(--g-text-primary)' }}>
                <RefreshCw className="w-4 h-4" style={{ color: 'var(--g-info)' }} />
                <span>Client Change Request Triage</span>
              </h2>
            </div>

            {tasks.filter(t => t.status === 'CHANGES_REQUESTED').length === 0 ? (
              <div className="p-4 text-center text-xs" style={{ color: 'var(--g-text-muted)' }}>No pending Client change requests.</div>
            ) : (
              <div className="space-y-3">
                {tasks.filter(t => t.status === 'CHANGES_REQUESTED').map(t => (
                  <div key={t.id} className="glass-inset p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-sm font-bold" style={{ color: 'var(--g-text-primary)' }}>{t.title}</h3>
                        <p className="text-xs" style={{ color: 'var(--g-text-secondary)' }}>
                          Change Request Count: <strong style={{ color: 'var(--g-accent)' }}>{t.changeRequestCount}</strong>
                        </p>
                      </div>
                      <span className="glass-badge glass-badge-yellow">CHANGES REQUESTED</span>
                    </div>
                    <div className="flex items-center space-x-3 pt-1">
                      <button onClick={() => handleApproveChangeRequest(t.id)} className="glass-btn glass-btn-success">
                        Approve Change Request (Send to Dev)
                      </button>
                      <button onClick={() => setRejectTaskId(t.id)} className="glass-btn glass-btn-danger">
                        Reject Request (No Dev Task)
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* All Projects Table */}
          <div className="glass-card overflow-hidden">
            <div className="px-5 py-4 flex items-center justify-between" style={{ borderBottom: '1px solid rgba(168,85,247,0.15)' }}>
              <h2 className="text-sm font-bold" style={{ color: 'var(--g-text-primary)' }}>
                All Master Projects ({tasks.length})
              </h2>
              <button onClick={() => setShowTaskForm(true)} className="glass-btn glass-btn-ghost text-xs" style={{ color: 'var(--g-accent)' }}>
                <Plus className="w-3.5 h-3.5" />
                <span>Direct Task</span>
              </button>
            </div>

            <div>
              {tasks.map(t => (
                <div key={t.id} className="glass-row flex items-center justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center space-x-2">
                      <span className="text-sm font-bold" style={{ color: 'var(--g-text-primary)' }}>{t.title}</span>
                      <span className="glass-badge glass-badge-neutral">{t.status}</span>
                    </div>
                    <div className="text-xs" style={{ color: 'var(--g-text-secondary)' }}>
                      Developer: {t.developerEmail || 'Unassigned'} | Client: {t.clientEmail || 'None'}
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    {t.status === 'MANAGER_REVIEW' && (
                      <button onClick={() => handleDeliverToClient(t)} className="glass-btn glass-btn-primary text-xs">
                        Deliver to Client
                      </button>
                    )}
                    {t.status !== 'CLOSED' && t.status !== 'COMPLETED' && (
                      <button
                        onClick={() => setStopTaskId(t.id)}
                        className="glass-btn glass-btn-ghost p-1"
                        title="Stop / Close Project"
                      >
                        <StopCircle className="w-4 h-4" style={{ color: 'var(--g-danger)' }} />
                      </button>
                    )}
                    <button onClick={() => navigate(`/manager/tasks/${t.id}`)} className="glass-btn glass-btn-secondary text-xs">
                      View Details
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">

          {/* Provision Employee */}
          <div className="glass-card p-5 space-y-4">
            <h2 className="text-sm font-bold flex items-center space-x-2" style={{ color: 'var(--g-text-primary)' }}>
              <UserPlus className="w-4 h-4" style={{ color: 'var(--g-accent)' }} />
              <span>Provision Employee Account</span>
            </h2>

            {empMsg && (
              <div className="glass-inset p-2.5 text-xs font-mono" style={{ color: 'var(--g-text-primary)' }}>{empMsg}</div>
            )}

            <form onSubmit={handleCreateEmployee} className="space-y-3">
              <div>
                <label className="block text-xs mb-1 font-semibold" style={{ color: 'var(--g-text-secondary)' }}>Role</label>
                <select
                  value={newEmpRole} onChange={e => setNewEmpRole(e.target.value as any)}
                  className="glass-input"
                >
                  <option value="developer">Developer</option>
                  <option value="sales">Sales</option>
                  <option value="tester">Tester</option>
                </select>
              </div>
              <div>
                <label className="block text-xs mb-1 font-semibold" style={{ color: 'var(--g-text-secondary)' }}>Employee Full Name</label>
                <input
                  type="text" required value={newEmpName} onChange={e => setNewEmpName(e.target.value)}
                  placeholder="e.g. Arun Kumar"
                  className="glass-input"
                />
              </div>
              <div>
                <label className="block text-xs mb-1 font-semibold" style={{ color: 'var(--g-text-secondary)' }}>Employee Email</label>
                <input
                  type="email" required value={newEmpEmail} onChange={e => setNewEmpEmail(e.target.value)}
                  placeholder="employee@company.sec"
                  className="glass-input"
                />
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--g-text-secondary)' }}>Initial Password</label>
                <input
                  type="text" required value={newEmpPassword} onChange={e => setNewEmpPassword(e.target.value)}
                  className="glass-input font-mono"
                />
              </div>
              <button type="submit" className="glass-btn glass-btn-primary w-full justify-center">
                Provision {newEmpRole.toUpperCase()} Account
              </button>
            </form>
          </div>

          {/* Audit Logs */}
          <div className="glass-card p-5 space-y-3">
            <h2 className="text-sm font-bold flex items-center space-x-2" style={{ color: 'var(--g-text-primary)' }}>
              <Clock className="w-4 h-4" style={{ color: 'var(--g-success)' }} />
              <span>Immutable Audit Logs</span>
            </h2>
            <div className="space-y-2 max-h-80 overflow-y-auto glass-scroll pr-1">
              {auditLogs.map((log: any) => (
                <div key={log.id} className="glass-inset p-2.5 space-y-1">
                  <div className="text-[11px] font-medium" style={{ color: 'var(--g-text-primary)' }}>{log.action}</div>
                  <div className="text-[9px] font-mono" style={{ color: 'var(--g-text-muted)' }}>
                    {new Date(log.timestamp).toLocaleString()}
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      </main>

      {/* Modal: Assign Developer & Tester */}
      {selectedTaskToAssign && (
        <div className="glass-modal-overlay">
          <div className="glass-modal max-w-md">
            <button onClick={() => setSelectedTaskToAssign(null)} className="glass-btn glass-btn-ghost absolute top-4 right-4 p-1">
              <XCircle className="w-4 h-4" style={{ color: 'var(--g-text-muted)' }} />
            </button>
            <h3 className="text-base font-bold mb-1" style={{ color: 'var(--g-text-primary)' }}>Assign Engineering & Testing Resources</h3>
            <p className="text-xs mb-4" style={{ color: 'var(--g-text-secondary)' }}>Project: <strong>{selectedTaskToAssign.title}</strong></p>
            <form onSubmit={handleAssignDeveloperTester} className="space-y-4">
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--g-text-secondary)' }}>Select Developer</label>
                <select required value={assignDevId} onChange={e => setAssignDevId(e.target.value)} className="glass-input">
                  <option value="">-- Choose Developer --</option>
                  {developers.map(d => (
                    <option key={d.id} value={d.id}>
                      {d.name ? `${d.name} (${d.email})` : d.email}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--g-text-secondary)' }}>Select QA Tester</label>
                <select value={assignTesterId} onChange={e => setAssignTesterId(e.target.value)} className="glass-input">
                  <option value="">-- Choose QA Tester --</option>
                  {testers.map(t => (
                    <option key={t.id} value={t.id}>
                      {t.name ? `${t.name} (${t.email})` : t.email}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex justify-end space-x-3 pt-2">
                <button type="button" onClick={() => setSelectedTaskToAssign(null)} className="glass-btn glass-btn-ghost text-xs">Cancel</button>
                <button type="submit" className="glass-btn glass-btn-primary">Confirm Assignment</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Reject Client Request */}
      {rejectTaskId && (
        <div className="glass-modal-overlay">
          <div className="glass-modal">
            <h3 className="text-base font-bold mb-1" style={{ color: 'var(--g-danger)' }}>Reject Client Change Request</h3>
            <p className="text-xs mb-4" style={{ color: 'var(--g-text-secondary)' }}>
              This request will be marked REJECTED. No task will be created for Developers.
            </p>
            <form onSubmit={handleRejectChangeRequest} className="space-y-4">
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--g-text-secondary)' }}>Reason for Rejection</label>
                <textarea
                  rows={3} required value={rejectionReason} onChange={e => setRejectionReason(e.target.value)}
                  placeholder="e.g. Scope requested exceeds original contract terms..."
                  className="glass-input"
                />
              </div>
              <div className="flex justify-end space-x-3">
                <button type="button" onClick={() => setRejectTaskId(null)} className="glass-btn glass-btn-ghost text-xs">Cancel</button>
                <button type="submit" className="glass-btn glass-btn-danger-solid">Confirm Rejection</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Stop Project */}
      {stopTaskId && (
        <div className="glass-modal-overlay">
          <div className="glass-modal">
            <h3 className="text-base font-bold mb-1" style={{ color: 'var(--g-danger)' }}>Stop / Close Project</h3>
            <p className="text-xs mb-4" style={{ color: 'var(--g-text-secondary)' }}>
              Immediately stops all development and testing activities for this project.
            </p>
            <form onSubmit={handleStopProject} className="space-y-4">
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--g-text-secondary)' }}>Reason for Stopping Project</label>
                <textarea
                  rows={3} required value={stopReason} onChange={e => setStopReason(e.target.value)}
                  placeholder="e.g. Client requested early termination..."
                  className="glass-input"
                />
              </div>
              <div className="flex justify-end space-x-3">
                <button type="button" onClick={() => setStopTaskId(null)} className="glass-btn glass-btn-ghost text-xs">Cancel</button>
                <button type="submit" className="glass-btn glass-btn-danger-solid">Stop Project</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
