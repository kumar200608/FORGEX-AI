import React, { useState, useEffect } from 'react';
import { useAuth, getInitials } from '../context/AuthContext';
import { 
  Briefcase, UserPlus, PlusCircle, LogOut, CheckCircle, 
  FileText, Send, User, X, AlertCircle
} from 'lucide-react';
import { importPublicKey, encryptHybrid } from '../utils/crypto';

interface ClientUser {
  id: string;
  name?: string;
  email: string;
  publicKey: string;
  createdAt: string;
}

interface ProjectRequirement {
  id: string;
  title: string;
  status: string;
  projectType: string;
  clientBudget: string;
  quotedPrice: string;
  quotationStatus: string;
  clientEmail?: string;
  createdAt: string;
}

export const SalesDashboard = () => {
  const { user, privateKey, logout } = useAuth();

  const [clients, setClients] = useState<ClientUser[]>([]);
  const [projects, setProjects] = useState<ProjectRequirement[]>([]);
  const [loading, setLoading] = useState(true);

  const [showCreateClient, setShowCreateClient] = useState(false);
  const [showNewRequirement, setShowNewRequirement] = useState(false);

  const [clientName, setClientName] = useState('');
  const [clientEmail, setClientEmail] = useState('');
  const [clientPass, setClientPass] = useState('ClientPass123!');

  const [selectedClientId, setSelectedClientId] = useState('');
  const [projectTitle, setProjectTitle] = useState('');
  const [projectType, setProjectType] = useState('Web Application');
  const [clientBudget, setClientBudget] = useState('$15,000');
  const [quotedPrice, setQuotedPrice] = useState('$18,000');
  const [requirementsText, setRequirementsText] = useState('');

  const [formSubmitting, setFormSubmitting] = useState(false);
  const [formError, setFormError] = useState('');

  const fetchData = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const cRes = await fetch('http://localhost:3001/api/users/clients');
      if (cRes.ok) setClients(await cRes.json() || []);

      const pRes = await fetch('http://localhost:3001/api/tasks', {
        headers: { 'x-user-id': user.id, 'x-user-role': user.role }
      });
      if (pRes.ok) setProjects(await pRes.json() || []);
    } catch (err: any) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, [user]);

  const handleCreateClient = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');
    setFormSubmitting(true);
    try {
      const tempHash = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(clientPass))
        .then(b => Array.from(new Uint8Array(b)).map(x => x.toString(16).padStart(2, '0')).join(''));
      const res = await fetch('http://localhost:3001/api/auth/create-client', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          salesId: user?.id, 
          name: clientName.trim(), 
          email: clientEmail, 
          tempPasswordHash: tempHash 
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setShowCreateClient(false);
      setClientName('');
      setClientEmail('');
      fetchData();
    } catch (err: any) {
      setFormError(err.message || 'Failed to create client');
    } finally {
      setFormSubmitting(false);
    }
  };

  const handleCreateRequirement = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');
    setFormSubmitting(true);
    try {
      if (!selectedClientId) throw new Error('Please select a client');
      const mRes = await fetch('http://localhost:3001/api/users/role/manager');
      const managers = await mRes.json();
      const manager = managers[0];
      if (!manager) throw new Error('No manager account found in system');
      const managerPubKey = await importPublicKey(manager.publicKey);
      const salesPubKey = user?.publicKey ? await importPublicKey(user.publicKey) : managerPubKey;
      const mgrEncrypted = await encryptHybrid(requirementsText || projectTitle, privateKey!, managerPubKey);
      const salesEncrypted = await encryptHybrid(requirementsText || projectTitle, privateKey!, salesPubKey);
      const res = await fetch('http://localhost:3001/api/tasks/sales-intake', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-user-id': user!.id, 'x-user-role': user!.role },
        body: JSON.stringify({
          clientId: selectedClientId,
          managerId: manager.id,
          title: projectTitle,
          projectType,
          clientBudget,
          quotedPrice,
          encryptedPayload: mgrEncrypted.encryptedPayload,
          wrappedKeySales: salesEncrypted.wrappedKey,
          wrappedKeyManager: mgrEncrypted.wrappedKey
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setShowNewRequirement(false);
      setProjectTitle('');
      setRequirementsText('');
      fetchData();
    } catch (err: any) {
      setFormError(err.message || 'Failed to submit project requirement');
    } finally {
      setFormSubmitting(false);
    }
  };

  const statusBadgeClass = (status: string) => {
    if (status === 'SENT_TO_MANAGER') return 'glass-badge glass-badge-yellow';
    if (status === 'APPROVED') return 'glass-badge glass-badge-emerald';
    if (status === 'COMPLETED') return 'glass-badge glass-badge-emerald';
    return 'glass-badge glass-badge-neutral';
  };

  return (
    <div className="glass-page">
      {/* Header */}
      <header className="glass-nav">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="glass-icon-wrap">
              <Briefcase className="w-4 h-4" style={{ color: 'var(--g-accent)' }} />
            </div>
            <span className="text-sm font-bold tracking-tight" style={{ color: 'var(--g-text-primary)' }}>
              Sales Workspace
            </span>
          </div>
          <div className="flex items-center space-x-3">
            <div className="glass-user-pill hidden sm:inline-flex items-center space-x-2">
              <div className="w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0"
                style={{ background: 'var(--g-accent)', color: '#ffffff' }}>
                {getInitials(user?.name || user?.email, 'S')}
              </div>
              <div className="flex flex-col text-left leading-tight">
                <span className="font-bold text-xs" style={{ color: 'var(--g-text-primary)' }}>
                  {user?.name || user?.email}
                </span>
                <span className="text-[10px] font-medium capitalize" style={{ color: 'var(--g-text-secondary)' }}>
                  Sales
                </span>
              </div>
            </div>
            <button onClick={logout} className="glass-signout-btn">
              <LogOut className="w-3.5 h-3.5 text-red-500" />
              <span>Sign Out</span>
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {/* Welcome Banner */}
        <div className="pb-1">
          <h1 className="text-2xl font-black tracking-tight" style={{ color: 'var(--g-text-primary)' }}>
            Welcome, {user?.name || 'Sales'}
          </h1>
          <p className="text-xs mt-0.5" style={{ color: 'var(--g-text-secondary)' }}>
            Collect client requirements, prepare quotations, and submit intake records to Engineering Management.
          </p>
        </div>

        {/* Page Title + Actions */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold tracking-tight" style={{ color: 'var(--g-text-primary)' }}>
              Sales & Client Operations
            </h2>
            <p className="text-xs mt-0.5" style={{ color: 'var(--g-text-muted)' }}>
              Active customer pipeline and lead provisioning
            </p>
          </div>
          <div className="flex items-center space-x-3">
            <button
              onClick={() => { setFormError(''); setShowCreateClient(true); }}
              className="glass-btn glass-btn-secondary"
            >
              <UserPlus className="w-4 h-4" style={{ color: 'var(--g-accent)' }} />
              <span>Create Client</span>
            </button>
            <button
              onClick={() => { setFormError(''); setShowNewRequirement(true); }}
              className="glass-btn glass-btn-primary"
            >
              <PlusCircle className="w-4 h-4" />
              <span>New Requirement & Quotation</span>
            </button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: 'Active Clients', value: clients.length, icon: <User className="w-4 h-4" />, color: 'var(--g-accent)' },
            { label: 'Total Requirements', value: projects.length, icon: <FileText className="w-4 h-4" />, color: 'var(--g-info)' },
            { label: 'Sent to Manager', value: projects.filter(p => p.status === 'SENT_TO_MANAGER').length, icon: <Send className="w-4 h-4" />, color: 'var(--g-warning)' },
            { label: 'Approved Projects', value: projects.filter(p => p.status !== 'SENT_TO_MANAGER' && p.status !== 'DRAFT').length, icon: <CheckCircle className="w-4 h-4" />, color: 'var(--g-success)' }
          ].map(s => (
            <div key={s.label} className="glass-stat">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs" style={{ color: 'var(--g-text-muted)' }}>{s.label}</span>
                <span style={{ color: s.color }}>{s.icon}</span>
              </div>
              <div className="text-2xl font-bold" style={{ color: 'var(--g-text-primary)' }}>{s.value}</div>
            </div>
          ))}
        </div>

        {/* Project Intakes Table */}
        <div className="glass-card overflow-hidden">
          <div className="px-6 py-4 flex items-center justify-between" style={{ borderBottom: '1px solid rgba(168,85,247,0.15)' }}>
            <h2 className="text-sm font-bold" style={{ color: 'var(--g-text-primary)' }}>Project Intakes & Quotations</h2>
            <span className="text-xs" style={{ color: 'var(--g-text-muted)' }}>{projects.length} records</span>
          </div>

          {loading ? (
            <div className="p-8 text-center text-xs" style={{ color: 'var(--g-text-muted)' }}>Loading sales records...</div>
          ) : projects.length === 0 ? (
            <div className="p-12 text-center space-y-3">
              <div className="w-10 h-10 rounded-full flex items-center justify-center mx-auto glass-inset">
                <FileText className="w-5 h-5" style={{ color: 'var(--g-text-muted)' }} />
              </div>
              <p className="text-sm font-medium" style={{ color: 'var(--g-text-secondary)' }}>No project requirements collected yet.</p>
              <p className="text-xs" style={{ color: 'var(--g-text-muted)' }}>Click "New Requirement & Quotation" to create an intake for a client.</p>
            </div>
          ) : (
            <div>
              {projects.map((proj) => (
                <div key={proj.id} className="glass-row flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center space-x-3">
                      <span className="text-sm font-bold" style={{ color: 'var(--g-text-primary)' }}>{proj.title}</span>
                      <span className="glass-badge glass-badge-neutral">{proj.projectType || 'Web App'}</span>
                    </div>
                    <div className="flex items-center space-x-4 text-xs" style={{ color: 'var(--g-text-secondary)' }}>
                      <span>Client: <strong style={{ color: 'var(--g-text-primary)' }}>{proj.clientEmail || 'Client Account'}</strong></span>
                      <span>Budget: <strong style={{ color: 'var(--g-success)' }}>{proj.clientBudget}</strong></span>
                      <span>Quoted: <strong style={{ color: 'var(--g-accent)' }}>{proj.quotedPrice}</strong></span>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="text-right space-y-1">
                      <span className={statusBadgeClass(proj.status)}>{proj.status.replace(/_/g, ' ')}</span>
                      <div className="text-[10px] font-mono" style={{ color: 'var(--g-text-faint)' }}>
                        {new Date(proj.createdAt).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>

      {/* Modal: Create Client */}
      {showCreateClient && (
        <div className="glass-modal-overlay">
          <div className="glass-modal">
            <button onClick={() => setShowCreateClient(false)} className="glass-btn glass-btn-ghost absolute top-4 right-4 p-1">
              <X className="w-4 h-4" style={{ color: 'var(--g-text-muted)' }} />
            </button>
            <div className="flex items-center space-x-2 mb-4">
              <UserPlus className="w-5 h-5" style={{ color: 'var(--g-accent)' }} />
              <h3 className="text-base font-bold" style={{ color: 'var(--g-text-primary)' }}>Create Client Account</h3>
            </div>
            {formError && (
              <div className="p-3 mb-4 rounded-lg flex items-center space-x-2 glass-badge-red text-xs"
                style={{ background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.25)', color: 'var(--g-danger)' }}>
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{formError}</span>
              </div>
            )}
            <form onSubmit={handleCreateClient} className="space-y-4">
              <div>
                <label className="block text-xs mb-1 font-semibold" style={{ color: 'var(--g-text-secondary)' }}>Client Name / Company</label>
                <input type="text" required value={clientName} onChange={e => setClientName(e.target.value)}
                  placeholder="e.g. Rahul Kumar or ABC Technologies" className="glass-input" />
              </div>
              <div>
                <label className="block text-xs mb-1 font-semibold" style={{ color: 'var(--g-text-secondary)' }}>Client Email Address</label>
                <input type="email" required value={clientEmail} onChange={e => setClientEmail(e.target.value)}
                  placeholder="client@acme.com" className="glass-input" />
              </div>
              <div>
                <label className="block text-xs mb-1 font-semibold" style={{ color: 'var(--g-text-secondary)' }}>Temporary Initial Password</label>
                <input type="text" required value={clientPass} onChange={e => setClientPass(e.target.value)}
                  className="glass-input font-mono" />
                <p className="text-[11px] mt-1" style={{ color: 'var(--g-text-muted)' }}>Client will register ECDH security keys on first login.</p>
              </div>
              <div className="flex items-center justify-end space-x-3 pt-2">
                <button type="button" onClick={() => setShowCreateClient(false)} className="glass-btn glass-btn-ghost text-xs">Cancel</button>
                <button type="submit" disabled={formSubmitting} className="glass-btn glass-btn-primary">
                  {formSubmitting ? 'Creating...' : 'Provision Client'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: New Requirement */}
      {showNewRequirement && (
        <div className="glass-modal-overlay">
          <div className="glass-modal" style={{ maxWidth: '32rem', maxHeight: '90vh', overflowY: 'auto' }}>
            <button onClick={() => setShowNewRequirement(false)} className="glass-btn glass-btn-ghost absolute top-4 right-4 p-1">
              <X className="w-4 h-4" style={{ color: 'var(--g-text-muted)' }} />
            </button>
            <div className="flex items-center space-x-2 mb-4">
              <PlusCircle className="w-5 h-5" style={{ color: 'var(--g-accent)' }} />
              <h3 className="text-base font-bold" style={{ color: 'var(--g-text-primary)' }}>New Requirement & Quotation</h3>
            </div>
            {formError && (
              <div className="p-3 mb-4 rounded-lg flex items-center space-x-2 text-xs"
                style={{ background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.25)', color: 'var(--g-danger)' }}>
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{formError}</span>
              </div>
            )}
            <form onSubmit={handleCreateRequirement} className="space-y-4">
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--g-text-secondary)' }}>Select Client</label>
                <select required value={selectedClientId} onChange={e => setSelectedClientId(e.target.value)} className="glass-input">
                  <option value="">-- Choose Client --</option>
                  {clients.map(c => (
                    <option key={c.id} value={c.id}>
                      {c.name ? `${c.name} (${c.email})` : c.email}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--g-text-secondary)' }}>Project Name / Title</label>
                <input type="text" required value={projectTitle} onChange={e => setProjectTitle(e.target.value)}
                  placeholder="e.g. Encrypted Fintech Mobile Portal" className="glass-input" />
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--g-text-secondary)' }}>Project Type</label>
                  <input type="text" value={projectType} onChange={e => setProjectType(e.target.value)} className="glass-input" />
                </div>
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--g-text-secondary)' }}>Client Budget</label>
                  <input type="text" value={clientBudget} onChange={e => setClientBudget(e.target.value)} className="glass-input font-mono" />
                </div>
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--g-text-secondary)' }}>Quoted Price</label>
                  <input type="text" value={quotedPrice} onChange={e => setQuotedPrice(e.target.value)} className="glass-input font-mono" />
                </div>
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--g-text-secondary)' }}>Detailed Requirements (Encrypted End-to-End)</label>
                <textarea rows={4} value={requirementsText} onChange={e => setRequirementsText(e.target.value)}
                  placeholder="Describe scope, features, expected deliverables, and deadline considerations..."
                  className="glass-input" />
              </div>
              <div className="flex items-center justify-end space-x-3 pt-2">
                <button type="button" onClick={() => setShowNewRequirement(false)} className="glass-btn glass-btn-ghost text-xs">Cancel</button>
                <button type="submit" disabled={formSubmitting} className="glass-btn glass-btn-primary">
                  {formSubmitting ? 'Encrypting & Submitting...' : 'Send to Manager'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
