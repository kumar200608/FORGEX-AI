import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { encryptHybrid, importPublicKey } from '../utils/crypto';
import { Shield, X } from 'lucide-react';

interface TaskFormProps {
  developers: any[];
  onClose: () => void;
  onSuccess: () => void;
}

export const TaskForm: React.FC<TaskFormProps> = ({ developers, onClose, onSuccess }) => {
  const { user, privateKey } = useAuth();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [deadline, setDeadline] = useState('');
  const [developerId, setDeveloperId] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [isEphemeral, setIsEphemeral] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const activeDevelopers = developers.filter(d => d.publicKey !== 'PENDING');

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setFile(e.target.files[0]);
    }
  };

  const fileToBase64 = (f: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve((reader.result as string).split(',')[1]);
      reader.onerror = error => reject(error);
      reader.readAsDataURL(f);
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!developerId) {
      setError('Please select an active developer');
      return;
    }
    if (!deadline) {
      setError('Please select both date and time for the deadline.');
      return;
    }
    
    setLoading(true);
    setError('');

    try {
      const dev = activeDevelopers.find(d => d.id === developerId);
      const devPubKey = await importPublicKey(dev.publicKey);

      const payloadObj: any = { description };
      if (file) {
        payloadObj.attachment = {
          filename: file.name,
          mimeType: file.type,
          data: await fileToBase64(file)
        };
      }
      const plaintextPayload = JSON.stringify(payloadObj);

      const devEncrypted = await encryptHybrid(plaintextPayload, privateKey!, devPubKey);
      const myPubKeyStr = user!.publicKey;
      const myPubKey = await importPublicKey(myPubKeyStr);
      const mgrEncrypted = await encryptHybrid(plaintextPayload, privateKey!, myPubKey);

      const res = await fetch('http://localhost:3001/api/tasks', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-id': user!.id,
          'x-user-role': user!.role
        },
        body: JSON.stringify({
          developerId,
          title,
          deadline,
          encryptedPayload: devEncrypted.encryptedPayload,
          wrappedKeyDeveloper: devEncrypted.wrappedKey,
          wrappedKeyManager: mgrEncrypted.wrappedKey,
          isEphemeral
        })
      });

      if (!res.ok) throw new Error(await res.text());
      onSuccess();
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Encryption or network failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="glass-modal-overlay">
      <div className="glass-modal max-w-lg w-full max-h-[90vh] overflow-y-auto glass-scroll relative">
        <button onClick={onClose} className="glass-btn glass-btn-ghost absolute top-4 right-4 p-1">
          <X className="w-4 h-4" style={{ color: 'var(--g-text-muted)' }} />
        </button>

        <h2 className="text-lg font-bold mb-4 flex items-center" style={{ color: 'var(--g-text-primary)' }}>
          <Shield className="w-5 h-5 mr-2" style={{ color: 'var(--g-accent)' }} /> 
          Create Secure Task
        </h2>

        {error && (
          <div className="mb-4 p-2.5 rounded-lg text-xs" style={{ background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.25)', color: 'var(--g-danger)' }}>
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--g-text-secondary)' }}>Title</label>
            <input type="text" required value={title} onChange={e=>setTitle(e.target.value)} className="glass-input" placeholder="Task title..." />
          </div>

          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--g-text-secondary)' }}>Assign To</label>
            <select required value={developerId} onChange={e=>setDeveloperId(e.target.value)} className="glass-input">
              <option value="">Select an active developer...</option>
              {activeDevelopers.map(d => (
                <option key={d.id} value={d.id}>{d.email}</option>
              ))}
            </select>
            {activeDevelopers.length === 0 && <p className="text-xs mt-1" style={{ color: 'var(--g-danger)' }}>No active developers (waiting for first login).</p>}
          </div>

          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--g-text-secondary)' }}>Deadline</label>
            <input 
              type="datetime-local" 
              value={deadline} 
              onChange={e => {
                setDeadline(e.target.value);
                if (error === 'Please select both date and time for the deadline.') setError('');
              }} 
              onInvalid={(e) => {
                e.preventDefault();
                setError('Please select both date and time for the deadline.');
              }}
              min={(() => {
                const now = new Date();
                const pad = (n: number) => n.toString().padStart(2, '0');
                return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}T${pad(now.getHours())}:${pad(now.getMinutes())}`;
              })()}
              className="glass-input font-mono text-xs" 
            />
          </div>

          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--g-text-secondary)' }}>Description (End-to-End Encrypted)</label>
            <textarea required rows={3} value={description} onChange={e=>setDescription(e.target.value)} className="glass-input font-mono text-xs" placeholder="Task details..." />
          </div>

          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--g-text-secondary)' }}>Attachment (End-to-End Encrypted)</label>
            <input type="file" onChange={handleFileChange} className="glass-input text-xs" />
          </div>

          {/* Ephemeral Toggle */}
          <div className="p-3 rounded-lg" style={{ background: 'rgba(239,68,68,0.06)', border: '1px solid rgba(239,68,68,0.2)' }}>
            <h4 className="text-xs font-semibold flex items-center" style={{ color: 'var(--g-danger)' }}>
              <Shield className="w-3.5 h-3.5 mr-1" /> ADVANCED SECURITY
            </h4>
            <label className="flex items-center mt-2 text-xs font-medium cursor-pointer" style={{ color: 'var(--g-danger)' }}>
              <input type="checkbox" checked={isEphemeral} onChange={e => setIsEphemeral(e.target.checked)} className="mr-2 rounded" />
              Ephemeral Task
            </label>
            {isEphemeral && (
              <div className="mt-2 text-xs space-y-1" style={{ color: 'var(--g-danger)' }}>
                <p><strong>Retention:</strong> Until completion or overdue</p>
                <p className="mt-1 text-[10px] italic">
                  Reduces the long-term exposure of sensitive encrypted task data. Sensitive temporary work does not need to remain decryptable indefinitely. Wrapped keys will be shredded from the server.
                </p>
              </div>
            )}
          </div>
          
          {/* Secure Sharing Indicator */}
          {developerId && (
            <div className="p-3 rounded-lg" style={{ background: 'rgba(99,102,241,0.06)', border: '1px solid rgba(99,102,241,0.2)' }}>
              <h4 className="text-xs font-semibold flex items-center" style={{ color: 'var(--g-info)' }}>
                <Shield className="w-3.5 h-3.5 mr-1" /> SHARE SECURELY
              </h4>
              <div className="mt-2 text-xs space-y-1" style={{ color: 'var(--g-info)' }}>
                <p><strong>Recipient:</strong> {activeDevelopers.find(d => d.id === developerId)?.email}</p>
                <p><strong>Protection:</strong> Recipient-bound encryption</p>
                <p><strong>Expiry:</strong> {deadline ? new Date(deadline).toLocaleString() : 'Never'}</p>
              </div>
              <p className="mt-2 text-[10px] italic" style={{ color: 'var(--g-info)' }}>
                Possessing a shared link does not automatically provide the ability to decrypt the protected content.
              </p>
            </div>
          )}

          <div className="flex justify-end space-x-3 pt-3">
            <button type="button" onClick={onClose} className="glass-btn glass-btn-ghost text-xs">Cancel</button>
            <button type="submit" disabled={loading} className="glass-btn glass-btn-primary">
              {loading ? 'Encrypting...' : 'Encrypt & Assign Task 🔐'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
