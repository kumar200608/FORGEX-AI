import React, { useEffect, useState, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { Send, MessageSquare } from 'lucide-react';
import { encryptHybrid, decryptHybrid, importPublicKey } from '../utils/crypto';

interface SecureMessageBoxProps {
  taskId: string;
  peerId: string;
  existingMessages: any[];
}

export const SecureMessageBox: React.FC<SecureMessageBoxProps> = ({ taskId, peerId, existingMessages }) => {
  const { user, privateKey } = useAuth();
  const [decryptedMessages, setDecryptedMessages] = useState<any[]>([]);
  const [peerPubKey, setPeerPubKey] = useState<CryptoKey | null>(null);
  const [newMessage, setNewMessage] = useState('');
  const [sending, setSending] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const fetchAndDecrypt = async () => {
      const res = await fetch(`http://localhost:3001/api/users/${peerId}/public-key`);
      const data = await res.json();
      const pubKey = await importPublicKey(data.publicKey);
      setPeerPubKey(pubKey);

      const decrypted: any[] = [];
      for (const msg of existingMessages) {
        try {
          const isMine = msg.senderId === user!.id;
          const wrappedKey = isMine ? msg.wrappedKeyManager : msg.wrappedKeyDeveloper;
          const plain = await decryptHybrid(msg.encryptedPayload, wrappedKey, privateKey!, pubKey);
          decrypted.push({ ...msg, content: plain, isMine });
        } catch (e) {
          console.warn('Could not decrypt message', e);
        }
      }
      setDecryptedMessages(decrypted);
    };

    if (existingMessages.length > 0 || peerId) {
      fetchAndDecrypt().catch(console.error);
    }
  }, [existingMessages, peerId, privateKey, user]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [decryptedMessages]);

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!peerPubKey || !newMessage.trim()) return;
    setSending(true);
    try {
      const recvEnc = await encryptHybrid(newMessage, privateKey!, peerPubKey);
      const myPubKey = await importPublicKey(user!.publicKey);
      const selfEnc = await encryptHybrid(newMessage, privateKey!, myPubKey);

      const isManager = user!.role === 'manager';
      await fetch('http://localhost:3001/api/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-id': user!.id,
          'x-user-role': user!.role
        },
        body: JSON.stringify({
          taskId,
          receiverId: peerId,
          encryptedPayload: recvEnc.encryptedPayload,
          wrappedKeyManager: isManager ? selfEnc.wrappedKey : recvEnc.wrappedKey,
          wrappedKeyDeveloper: isManager ? recvEnc.wrappedKey : selfEnc.wrappedKey
        })
      });

      setDecryptedMessages(prev => [...prev, {
        id: Date.now().toString(),
        content: newMessage,
        isMine: true,
        timestamp: new Date().toISOString()
      }]);
      setNewMessage('');
    } catch (e) {
      console.error(e);
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="glass-card flex flex-col h-[500px] overflow-hidden">
      <div className="p-4 flex justify-between items-center" style={{ borderBottom: '1px solid rgba(168,85,247,0.15)' }}>
        <h2 className="text-sm font-bold flex items-center" style={{ color: 'var(--g-text-primary)' }}>
          <MessageSquare className="w-4 h-4 mr-2" style={{ color: 'var(--g-accent)' }} /> 
          Secure Messages
        </h2>
        <div className="glass-badge glass-badge-emerald text-[9px] font-mono">
          🔒 End-to-End Encrypted
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-3 glass-scroll">
        {decryptedMessages.length === 0 && (
          <p className="text-center text-xs mt-8" style={{ color: 'var(--g-text-muted)' }}>
            No messages yet. All messages are end-to-end encrypted.
          </p>
        )}
        {decryptedMessages.map(msg => (
          <div key={msg.id} className={`flex ${msg.isMine ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-xs px-3.5 py-2.5 rounded-2xl text-xs ${
              msg.isMine 
                ? 'glass-btn-primary rounded-br-sm text-white shadow-md' 
                : 'glass-inset rounded-bl-sm shadow-sm'
            }`}
            style={!msg.isMine ? { color: 'var(--g-text-primary)' } : {}}
            >
              <p className="leading-relaxed">{msg.content}</p>
              <p className={`text-[10px] mt-1 text-right ${msg.isMine ? 'text-white/80' : ''}`} style={!msg.isMine ? { color: 'var(--g-text-muted)' } : {}}>
                {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      <form onSubmit={sendMessage} className="p-3 flex space-x-2" style={{ borderTop: '1px solid rgba(168,85,247,0.15)' }}>
        <input
          type="text"
          placeholder="Type secure message..."
          value={newMessage}
          onChange={e => setNewMessage(e.target.value)}
          className="glass-input flex-1 text-xs"
        />
        <button
          type="submit"
          disabled={sending || !newMessage.trim()}
          className="glass-btn glass-btn-primary px-3 py-2"
        >
          <Send className="w-3.5 h-3.5" />
        </button>
      </form>
    </div>
  );
};
