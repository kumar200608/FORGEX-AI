const http = require('http');

const API_BASE = 'http://localhost:3001/api';

async function request(path, method = 'GET', data = null, headers = {}) {
  return new Promise((resolve, reject) => {
    const url = new URL(API_BASE + path);
    const options = {
      hostname: url.hostname,
      port: url.port,
      path: url.pathname + url.search,
      method: method,
      headers: {
        'Content-Type': 'application/json',
        ...headers
      }
    };

    const req = http.request(options, (res) => {
      let body = '';
      res.on('data', chunk => body += chunk);
      res.on('end', () => {
        try {
          const parsed = JSON.parse(body);
          if (res.statusCode >= 200 && res.statusCode < 300) {
            resolve(parsed);
          } else {
            reject({ status: res.statusCode, error: parsed.error || body });
          }
        } catch (e) {
          resolve(body);
        }
      });
    });

    req.on('error', reject);
    if (data) req.write(JSON.stringify(data));
    req.end();
  });
}

async function runEndToEndVerification() {
  console.log('===============================================================');
  console.log('STARTING MANUAL END-TO-END WORKFLOW VERIFICATION (PHASE 5)');
  console.log('===============================================================\n');

  try {
    // 1. Manager Signup / Login
    console.log('[STEP 1] Manager Account Setup & Login');
    const mgrEmail = `manager_${Date.now()}@wa3.test`;
    const mgrSignup = await request('/auth/signup', 'POST', {
      name: 'Dinesh M',
      email: mgrEmail,
      passwordHash: 'mgr_pass_hash_123',
      publicKey: 'MGR_PUBLIC_KEY_STUB',
      encryptedPrivateKey: 'MGR_WRAPPED_PRIVATE_KEY_STUB',
      role: 'manager'
    });
    const manager = mgrSignup.user;
    if (manager.name !== 'Dinesh M') {
      throw new Error(`Expected Manager name to be 'Dinesh M', got: ${manager.name}`);
    }
    console.log(`  ✓ Manager Created: ID=${manager.id}, Name=${manager.name}, Email=${manager.email}`);

    // Verify Manager Login returns stored name
    const mgrLogin = await request('/auth/login', 'POST', {
      email: mgrEmail,
      passwordHash: 'mgr_pass_hash_123'
    });
    if (mgrLogin.user.name !== 'Dinesh M') {
      throw new Error(`Expected Manager login name to be 'Dinesh M', got: ${mgrLogin.user.name}`);
    }
    console.log(`  ✓ Manager Login verified: Profile Name="${mgrLogin.user.name}" correctly retrieved from database.`);

    // 2. Manager Creates Employees (Sales, Developer, Tester)
    console.log('\n[STEP 2] Manager Creates Employees (Sales, Developer, Tester)');
    
    const salesEmail = `sales_${Date.now()}@wa3.test`;
    const salesRes = await request('/auth/create-employee', 'POST', {
      managerId: manager.id,
      name: 'Sales Rep Jane',
      email: salesEmail,
      tempPasswordHash: 'temp_pass_hash',
      role: 'sales'
    });
    console.log(`  ✓ Sales Account Created: ID=${salesRes.employeeId}, Name=${salesRes.name}`);

    const devEmail = `dev_${Date.now()}@wa3.test`;
    const devRes = await request('/auth/create-employee', 'POST', {
      managerId: manager.id,
      name: 'Arun Kumar',
      email: devEmail,
      tempPasswordHash: 'temp_pass_hash',
      role: 'developer'
    });
    console.log(`  ✓ Developer Account Created: ID=${devRes.employeeId}, Name=${devRes.name}`);

    const devLogin = await request('/auth/login', 'POST', {
      email: devEmail,
      passwordHash: 'temp_pass_hash'
    });
    if (devLogin.user.name !== 'Arun Kumar') {
      throw new Error(`Expected Developer login name to be 'Arun Kumar', got: ${devLogin.user.name}`);
    }
    console.log(`  ✓ Developer Login verified: Profile Name="${devLogin.user.name}" correctly preserved.`);

    const testerEmail = `tester_${Date.now()}@wa3.test`;
    const testerRes = await request('/auth/create-employee', 'POST', {
      managerId: manager.id,
      name: 'Priya',
      email: testerEmail,
      tempPasswordHash: 'temp_pass_hash',
      role: 'tester'
    });
    console.log(`  ✓ Tester Account Created: ID=${testerRes.employeeId}, Name=${testerRes.name}`);

    const testerLogin = await request('/auth/login', 'POST', {
      email: testerEmail,
      passwordHash: 'temp_pass_hash'
    });
    if (testerLogin.user.name !== 'Priya') {
      throw new Error(`Expected Tester login name to be 'Priya', got: ${testerLogin.user.name}`);
    }
    console.log(`  ✓ Tester Login verified: Profile Name="${testerLogin.user.name}" correctly preserved.`);

    // Register keys for employees
    await request('/auth/register-keys', 'POST', { userId: salesRes.employeeId, publicKey: 'SALES_PUB_KEY', encryptedPrivateKey: 'SALES_PRIV_KEY' });
    await request('/auth/register-keys', 'POST', { userId: devRes.employeeId, publicKey: 'DEV_PUB_KEY', encryptedPrivateKey: 'DEV_PRIV_KEY' });
    await request('/auth/register-keys', 'POST', { userId: testerRes.employeeId, publicKey: 'TESTER_PUB_KEY', encryptedPrivateKey: 'TESTER_PRIV_KEY' });
    console.log('  ✓ Cryptographic keypairs registered for Sales, Developer, and Tester.');

    // 3. Sales Creates Client Account
    console.log('\n[STEP 3] Sales Creates Client Account');
    const clientEmail = `client_${Date.now()}@acme.com`;
    const clientRes = await request('/auth/create-client', 'POST', {
      salesId: salesRes.employeeId,
      name: 'Rahul',
      email: clientEmail,
      tempPasswordHash: 'client_temp_pass'
    });
    console.log(`  ✓ Client Account Created by Sales: ID=${clientRes.clientId}, Name=${clientRes.name}`);
    await request('/auth/register-keys', 'POST', { userId: clientRes.clientId, publicKey: 'CLIENT_PUB_KEY', encryptedPrivateKey: 'CLIENT_PRIV_KEY' });
    console.log('  ✓ Client keypair registered.');

    const clientLogin = await request('/auth/login', 'POST', {
      email: clientEmail,
      passwordHash: 'client_temp_pass'
    });
    if (clientLogin.user.name !== 'Rahul') {
      throw new Error(`Expected Client login name to be 'Rahul', got: ${clientLogin.user.name}`);
    }
    console.log(`  ✓ Client Login verified: Profile Name="${clientLogin.user.name}" correctly preserved.`);

    // 4. Sales Collects Requirements & Creates Quotation (Sent to Manager)
    console.log('\n[STEP 4] Sales Collects Requirements & Sends Intake to Manager');
    const intakeRes = await request('/tasks/sales-intake', 'POST', {
      clientId: clientRes.clientId,
      managerId: manager.id,
      title: 'Encrypted Healthcare Patient Portal',
      projectType: 'Web & Mobile App',
      clientBudget: '$45,000',
      quotedPrice: '$50,000',
      encryptedPayload: 'ENCRYPTED_SALES_REQUIREMENTS_PAYLOAD',
      wrappedKeySales: 'WRAPPED_KEY_SALES',
      wrappedKeyManager: 'WRAPPED_KEY_MANAGER'
    }, { 'x-user-id': salesRes.employeeId, 'x-user-role': 'sales' });

    const taskId = intakeRes.id;
    console.log(`  ✓ Project Requirement Submitted to Manager: TaskID=${taskId}, Status=SENT_TO_MANAGER`);

    // 5. Manager Reviews & Approves Sales Intake
    console.log('\n[STEP 5] Manager Reviews & Approves Sales Intake');
    await request(`/tasks/${taskId}/manager-approve-intake`, 'PATCH', {}, { 'x-user-id': manager.id, 'x-user-role': 'manager' });
    console.log(`  ✓ Manager Approved Sales Intake: Status=APPROVED`);

    // 6. Manager Assigns Developer & Tester
    console.log('\n[STEP 6] Manager Assigns Developer & Tester');
    await request(`/tasks/${taskId}/assign-developer`, 'PATCH', {
      developerId: devRes.employeeId,
      testerId: testerRes.employeeId,
      wrappedKeyDeveloper: 'WRAPPED_KEY_DEV',
      wrappedKeyTester: 'WRAPPED_KEY_TESTER'
    }, { 'x-user-id': manager.id, 'x-user-role': 'manager' });
    console.log(`  ✓ Developer (${devRes.employeeId}) & Tester (${testerRes.employeeId}) Assigned: Status=IN_DEVELOPMENT`);

    // 7. Developer Submits Work to Tester
    console.log('\n[STEP 7] Developer Works & Submits Completed Code to Tester');
    await request(`/tasks/${taskId}/submit-to-tester`, 'POST', {
      encryptedPayload: 'ENCRYPTED_DEVELOPER_BUILD_V1',
      wrappedKeyTester: 'WRAPPED_KEY_TESTER_SUBMIT',
      wrappedKeyManager: 'WRAPPED_KEY_MANAGER_SUBMIT'
    }, { 'x-user-id': devRes.employeeId, 'x-user-role': 'developer' });
    console.log(`  ✓ Work Submitted to Tester: Status=TESTING`);

    // 8. Tester Identifies Bug & Returns Task to Developer
    console.log('\n[STEP 8] Tester Finds Bug & Returns to Developer');
    const bugRes = await request(`/tasks/${taskId}/bugs`, 'POST', {
      developerId: devRes.employeeId,
      title: 'Session Key Rotation Exception on Timeout',
      description: 'Key exchange fails when network latency exceeds 300ms',
      expectedResult: 'Graceful key renegotiation',
      actualResult: '401 Unauthorized exception thrown',
      severity: 'HIGH'
    }, { 'x-user-id': testerRes.employeeId, 'x-user-role': 'tester' });
    console.log(`  ✓ Bug Reported (ID=${bugRes.bugId}): Task Status=RETURNED_TO_DEVELOPER`);

    // 9. Developer Fixes Bug & Resubmits
    console.log('\n[STEP 9] Developer Fixes Bug & Resubmits');
    await request(`/tasks/bugs/${bugRes.bugId}/status`, 'PATCH', { status: 'FIXED' }, { 'x-user-id': devRes.employeeId });
    await request(`/tasks/${taskId}/submit-to-tester`, 'POST', {
      encryptedPayload: 'ENCRYPTED_DEVELOPER_BUILD_V2_FIXED',
      wrappedKeyTester: 'WRAPPED_KEY_TESTER_V2',
      wrappedKeyManager: 'WRAPPED_KEY_MANAGER_V2'
    }, { 'x-user-id': devRes.employeeId, 'x-user-role': 'developer' });
    console.log(`  ✓ Bug Marked FIXED and Code Resubmitted to Tester: Status=TESTING`);

    // 10. Tester Retests & Approves for Manager
    console.log('\n[STEP 10] Tester Verifies Fix & Approves for Manager');
    await request(`/tasks/bugs/${bugRes.bugId}/status`, 'PATCH', { status: 'VERIFIED' }, { 'x-user-id': testerRes.employeeId });
    await request(`/tasks/${taskId}/tester-approve`, 'PATCH', {}, { 'x-user-id': testerRes.employeeId, 'x-user-role': 'tester' });
    console.log(`  ✓ Bug VERIFIED & Testing Passed: Task Status=MANAGER_REVIEW`);

    // 11. Manager Delivers Project to Client
    console.log('\n[STEP 11] Manager Reviews Final Tested Build & Delivers to Client');
    await request(`/tasks/${taskId}/deliver-to-client`, 'PATCH', {
      wrappedKeyClient: 'WRAPPED_KEY_CLIENT_DELIVERY',
      version: 'v1.0'
    }, { 'x-user-id': manager.id, 'x-user-role': 'manager' });
    console.log(`  ✓ Delivered to Client: Task Status=CLIENT_REVIEW`);

    // 12. Client Reviews & Requests Change (Not Satisfied)
    console.log('\n[STEP 12] Client Reviews Delivery & Requests Update (Not Satisfied)');
    await request(`/tasks/${taskId}/client-review`, 'PATCH', {
      action: 'NOT_SATISFIED',
      feedbackPayload: 'Please add biometric fingerprint authentication'
    }, { 'x-user-id': clientRes.clientId, 'x-user-role': 'client' });
    console.log(`  ✓ Client Change Request Submitted to Manager: Task Status=CHANGES_REQUESTED`);

    // 13. Manager Decision Branch A: Manager Approves Change Request -> Developer
    console.log('\n[STEP 13] Manager Decision Branch A: Manager Approves Change Request');
    await request(`/tasks/${taskId}/manager-review-change`, 'PATCH', { decision: 'APPROVE' }, { 'x-user-id': manager.id, 'x-user-role': 'manager' });
    console.log(`  ✓ Manager Approved Change Request: Task Status=IN_DEVELOPMENT (Routed to Developer)`);

    // Developer resubmits, Tester passes, Manager delivers again
    await request(`/tasks/${taskId}/submit-to-tester`, 'POST', { encryptedPayload: 'BUILD_V3' }, { 'x-user-id': devRes.employeeId, 'x-user-role': 'developer' });
    await request(`/tasks/${taskId}/tester-approve`, 'PATCH', {}, { 'x-user-id': testerRes.employeeId, 'x-user-role': 'tester' });
    await request(`/tasks/${taskId}/deliver-to-client`, 'PATCH', { version: 'v1.1' }, { 'x-user-id': manager.id, 'x-user-role': 'manager' });

    // Client requests change again
    await request(`/tasks/${taskId}/client-review`, 'PATCH', { action: 'NOT_SATISFIED', feedbackPayload: 'Add custom dark mode themes' }, { 'x-user-id': clientRes.clientId, 'x-user-role': 'client' });

    // 14. Manager Decision Branch B: Manager Rejects Change Request (NO Developer Task!)
    console.log('\n[STEP 14] Manager Decision Branch B: Manager Rejects Change Request');
    await request(`/tasks/${taskId}/manager-review-change`, 'PATCH', {
      decision: 'REJECT',
      rejectionReason: 'Custom theme styling exceeds agreed project scope'
    }, { 'x-user-id': manager.id, 'x-user-role': 'manager' });

    const taskStateAfterReject = await request(`/tasks/${taskId}`, 'GET', null, { 'x-user-id': manager.id, 'x-user-role': 'manager' });
    console.log(`  ✓ Manager REJECTED Client Request: Status=${taskStateAfterReject.task.status}, RejectionReason="${taskStateAfterReject.task.rejectionReason}"`);
    console.log(`  ✓ CONFIRMED: NO Developer task was created for rejected request.`);

    // 15. Client Final Approval -> Completed
    console.log('\n[STEP 15] Client Final Approval (Satisfied)');
    await request(`/tasks/${taskId}/client-review`, 'PATCH', { action: 'SATISFIED' }, { 'x-user-id': clientRes.clientId, 'x-user-role': 'client' });
    const finalTaskState = await request(`/tasks/${taskId}`, 'GET', null, { 'x-user-id': manager.id, 'x-user-role': 'manager' });
    console.log(`  ✓ Final Project Status: ${finalTaskState.task.status}`);

    console.log('\n===============================================================');
    console.log('✅ ALL PHASE 5 END-TO-END WORKFLOW TESTS PASSED PERFECTLY!');
    console.log('===============================================================\n');
  } catch (err) {
    console.error('❌ E2E VERIFICATION FAILED:', err);
    process.exit(1);
  }
}

runEndToEndVerification();
