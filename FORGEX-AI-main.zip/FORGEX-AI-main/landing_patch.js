const fs = require('fs');

const capabilities = [
  { num: '01', title: 'Blind Search', desc: 'Future capability: Search encrypted tasks and messages using privacy-preserving search tokens without maintaining a normal plaintext keyword index.', tags: ['Searchable Encryption', 'Blind Index', 'Privacy Search'] },
  { num: '02', title: 'Ephemeral Self-Destruct', desc: 'Future capability: Sensitive temporary tasks can invalidate their protected encryption keys after completion or expiry, reducing long-term decryptable exposure.', tags: ['Ephemeral Data', 'Key Invalidation', 'Data Lifecycle'] },
  { num: '03', title: 'Double-Ratchet Forward Secrecy', desc: 'Planned capability: Future secure messaging can continuously rotate message keys so that a later long-term key compromise does not automatically expose historical conversations.', tags: ['Double Ratchet', 'Forward Secrecy', 'Secure Messaging'] },
  { num: '04', title: 'Duress Vault', desc: 'Future capability: A separate authentication path can open a decoy workspace during a coercion scenario while keeping the primary sensitive workspace protected.', tags: ['Plausible Deniability', 'Secure Login', 'Privacy'] },
  { num: '05', title: 'Time-Lock Encryption', desc: 'Future capability: Progress reports can be cryptographically protected until a defined time, enforcing when protected information becomes available.', tags: ['Time-Lock', 'Encrypted Reports', 'Access Timing'] },
  { num: '06', title: 'Audit Integrity Anchoring', desc: 'Future capability: Periodic hashes of audit records can be anchored to a trusted external timestamp or public system to make later modification detectable.', tags: ['Audit Integrity', 'Hash Anchoring', 'Verification'] },
  { num: '07', title: 'Multi-Signature Revocation', desc: 'Future capability: High-risk task revocation or reassignment can require approval from multiple authorized parties before access changes take effect.', tags: ['Multi-Signature', 'Access Control', 'Shared Trust'] },
  { num: '08', title: 'Hardware-Backed Authentication', desc: 'Future capability: WebAuthn can bind account authentication to a hardware-backed authenticator such as a security key or platform biometric.', tags: ['WebAuthn', 'Security Key', 'Strong Authentication'] },
  { num: '09', title: 'Metadata Padding', desc: 'Future capability: Requests can be padded toward uniform sizes and traffic patterns to reduce information exposed through message size and timing analysis.', tags: ['Traffic Privacy', 'Metadata Protection', 'Side-Channel Defense'] },
  { num: '10', title: 'Steganographic Encrypted Attachments', desc: 'Future capability: Encrypted report data can optionally be embedded inside an innocent-looking image container, separating content secrecy from the appearance of the file.', tags: ['Steganography', 'Encrypted Attachments', 'Covert Storage'] }
];

let code = fs.readFileSync('client/src/pages/Landing.tsx', 'utf8');

const startRegex = /\{\/\* SECTION 3: CORE WORKFLOW TIMELINE \*\/\}[\s\S]*?<\/section>/;

if (!startRegex.test(code)) {
  console.log('Could not find section boundaries');
  process.exit(1);
}

const newSection = `
        {/* SECTION 3: CORE WORKFLOW TIMELINE */}
        <section id="workflow" className="py-24 border-t border-neutral-900 bg-[#0a0a0c]">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-3xl mx-auto mb-20">
              <span className="text-xs font-mono font-bold tracking-widest text-orange-500 uppercase">
                — CORE WORKFLOW
              </span>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-white mt-2 tracking-tight">
                WA-3 Future Security Capabilities
              </h2>
              <p className="text-sm sm:text-base text-neutral-400 mt-3">
                Ten advanced security capabilities designed to extend WA-3 beyond its core encrypted workflow.
              </p>
            </div>

            {/* Vertical Timeline */}
            <div className="relative space-y-12 before:absolute before:inset-0 before:left-1/2 before:-translate-x-1/2 before:w-0.5 before:bg-neutral-800 hidden md:block">
              { ${JSON.stringify(capabilities)}.map((item, idx) => (
                <div key={idx} className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full border border-neutral-700 bg-neutral-900 text-orange-500 font-mono font-bold text-xs shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 shadow-lg z-10">
                    {item.num}
                  </div>
                  <div className="w-[calc(50%-2.5rem)] bg-neutral-900/80 border border-neutral-800 rounded-xl p-6">
                    <h3 className="text-base font-bold text-white mb-2">{item.title}</h3>
                    <p className="text-xs text-neutral-400 leading-relaxed mb-4">
                      {item.desc}
                    </p>
                    <div className="flex flex-wrap gap-1.5 font-mono text-[10px]">
                      {item.tags.map((tag, i) => (
                        <span key={i} className="px-2 py-0.5 bg-neutral-800 text-neutral-300 rounded border border-neutral-700">
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Mobile Timeline view */}
            <div className="space-y-6 md:hidden">
              { ${JSON.stringify(capabilities)}.map((item, idx) => (
                <div key={idx} className="bg-neutral-900/80 border border-neutral-800 rounded-xl p-5">
                  <div className="flex items-center space-x-3 mb-2">
                    <span className="px-2 py-0.5 bg-orange-500/10 text-orange-400 font-mono text-xs font-bold rounded border border-orange-500/30">
                      {item.num}
                    </span>
                    <h3 className="text-sm font-bold text-white">{item.title}</h3>
                  </div>
                  <p className="text-xs text-neutral-400 leading-relaxed mb-3">{item.desc}</p>
                  <div className="flex flex-wrap gap-1 font-mono text-[10px]">
                    {item.tags.map((t, i) => (
                      <span key={i} className="px-2 py-0.5 bg-neutral-800 text-neutral-300 rounded border border-neutral-700">{t}</span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>`;

code = code.replace(startRegex, newSection);

fs.writeFileSync('client/src/pages/Landing.tsx', code);
console.log('Updated Landing.tsx');
