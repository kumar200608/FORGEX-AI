const sqlite3 = require('./server/node_modules/sqlite3').verbose();
const path = require('path');

const dbPath = path.resolve(__dirname, 'database.sqlite');
const db = new sqlite3.Database(dbPath);

const table = (process.argv[2] || 'summary').toLowerCase();

if (table === 'users') {
  db.all('SELECT id, name, email, role, createdAt FROM users ORDER BY createdAt DESC', [], (err, rows) => {
    if (err) console.error(err);
    else {
      console.log('\n=== USERS TABLE ===');
      console.table(rows);
    }
    db.close();
  });
} else if (table === 'tasks') {
  db.all('SELECT id, title, status, projectType, clientBudget, quotedPrice, createdAt FROM tasks ORDER BY createdAt DESC', [], (err, rows) => {
    if (err) console.error(err);
    else {
      console.log('\n=== TASKS TABLE ===');
      console.table(rows);
    }
    db.close();
  });
} else if (table === 'audit' || table === 'audit_logs') {
  db.all('SELECT id, userId, action, timestamp FROM audit_logs ORDER BY timestamp DESC LIMIT 20', [], (err, rows) => {
    if (err) console.error(err);
    else {
      console.log('\n=== RECENT AUDIT LOGS ===');
      console.table(rows);
    }
    db.close();
  });
} else {
  console.log('\n=== DATABASE OVERVIEW (database.sqlite) ===');
  db.all('SELECT id, name, email, role, createdAt FROM users ORDER BY createdAt DESC LIMIT 10', [], (err, users) => {
    console.log('\n[Recent Users]');
    console.table(users);

    db.all('SELECT id, title, status, projectType, createdAt FROM tasks ORDER BY createdAt DESC LIMIT 10', [], (err2, tasks) => {
      console.log('\n[Recent Tasks]');
      console.table(tasks);

      console.log('\nTip: To view specific tables, run:');
      console.log('  node view_db.js users');
      console.log('  node view_db.js tasks');
      console.log('  node view_db.js audit');
      db.close();
    });
  });
}
