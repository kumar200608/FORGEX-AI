CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  role TEXT NOT NULL CHECK(role IN ('manager', 'developer', 'sales', 'tester', 'client')),
  name TEXT,
  email TEXT UNIQUE NOT NULL,
  passwordHash TEXT NOT NULL,
  publicKey TEXT NOT NULL, -- JSON string or Base64 of CryptoKey export
  encryptedPrivateKey TEXT NOT NULL,
  managerId TEXT, -- Only set if role = developer or tester or sales or client
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS tasks (
  id TEXT PRIMARY KEY,
  managerId TEXT NOT NULL,
  developerId TEXT,
  testerId TEXT,
  clientId TEXT,
  salesId TEXT,
  title TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'DRAFT',
  encryptedPayload TEXT NOT NULL,
  wrappedKeyManager TEXT,
  wrappedKeyDeveloper TEXT,
  wrappedKeyTester TEXT,
  wrappedKeyClient TEXT,
  wrappedKeySales TEXT,
  projectType TEXT,
  clientBudget TEXT,
  quotedPrice TEXT,
  quotationStatus TEXT DEFAULT 'DRAFT',
  changeRequestCount INTEGER DEFAULT 0,
  rejectionReason TEXT,
  stopReason TEXT,
  version TEXT DEFAULT 'v1',
  deadline DATETIME,
  isEphemeral BOOLEAN DEFAULT 0,
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(managerId) REFERENCES users(id),
  FOREIGN KEY(developerId) REFERENCES users(id),
  FOREIGN KEY(testerId) REFERENCES users(id),
  FOREIGN KEY(clientId) REFERENCES users(id),
  FOREIGN KEY(salesId) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS bugs (
  id TEXT PRIMARY KEY,
  taskId TEXT NOT NULL,
  testerId TEXT NOT NULL,
  developerId TEXT,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  expectedResult TEXT,
  actualResult TEXT,
  severity TEXT DEFAULT 'MEDIUM',
  status TEXT NOT NULL DEFAULT 'OPEN', -- OPEN, FIXED, VERIFIED, REJECTED
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(taskId) REFERENCES tasks(id),
  FOREIGN KEY(testerId) REFERENCES users(id),
  FOREIGN KEY(developerId) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS change_requests (
  id TEXT PRIMARY KEY,
  taskId TEXT NOT NULL,
  clientId TEXT NOT NULL,
  requestNumber INTEGER DEFAULT 1,
  feedbackPayload TEXT NOT NULL,
  wrappedKeyManager TEXT,
  wrappedKeyClient TEXT,
  status TEXT DEFAULT 'PENDING_MANAGER', -- PENDING_MANAGER, APPROVED, REJECTED
  rejectionReason TEXT,
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(taskId) REFERENCES tasks(id),
  FOREIGN KEY(clientId) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS reports (
  id TEXT PRIMARY KEY,
  taskId TEXT NOT NULL,
  developerId TEXT NOT NULL,
  encryptedPayload TEXT NOT NULL,
  wrappedKeyManager TEXT NOT NULL,
  wrappedKeyDeveloper TEXT NOT NULL,
  wrappedKeyTester TEXT,
  wrappedKeyClient TEXT,
  wrappedKeySales TEXT,
  timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(taskId) REFERENCES tasks(id)
);

CREATE TABLE IF NOT EXISTS messages (
  id TEXT PRIMARY KEY,
  taskId TEXT NOT NULL,
  senderId TEXT NOT NULL,
  receiverId TEXT NOT NULL,
  encryptedPayload TEXT NOT NULL,
  wrappedKeyManager TEXT,
  wrappedKeyDeveloper TEXT,
  wrappedKeyTester TEXT,
  wrappedKeyClient TEXT,
  wrappedKeySales TEXT,
  timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(taskId) REFERENCES tasks(id)
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id TEXT PRIMARY KEY,
  userId TEXT NOT NULL,
  taskId TEXT,
  action TEXT NOT NULL,
  timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(userId) REFERENCES users(id),
  FOREIGN KEY(taskId) REFERENCES tasks(id)
);

CREATE TABLE IF NOT EXISTS password_reset_tokens (
  id TEXT PRIMARY KEY,
  userId TEXT NOT NULL,
  otpHash TEXT NOT NULL,
  expiresAt DATETIME NOT NULL,
  used BOOLEAN DEFAULT 0,
  attemptCount INTEGER DEFAULT 0,
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(userId) REFERENCES users(id)
);
