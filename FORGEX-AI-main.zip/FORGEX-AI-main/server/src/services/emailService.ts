import nodemailer from 'nodemailer';

const EMAIL_DEBUG = process.env.EMAIL_DEBUG === 'true';

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: Number(process.env.SMTP_PORT) || 587,
  secure: process.env.SMTP_SECURE === 'true',
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

export const sendPasswordResetOTP = async (email: string, otp: string) => {
  if (EMAIL_DEBUG) {
    console.log(`[EMAIL DEV] Password reset OTP generated for ${email}: ${otp}`);
  }

  const mailOptions = {
    from: process.env.SMTP_FROM || 'Security <noreply@sec.com>',
    to: email,
    subject: 'Password Reset OTP',
    text: `
Secure Workspace

Your password reset OTP is:

${otp}

This OTP expires in 10 minutes.

For your security:
- Never share this OTP.
- Support will never ask for your OTP.
- If you did not request a password reset, you can ignore this email.
    `.trim(),
    html: `
<div style="font-family: sans-serif; max-width: 600px; margin: 0 auto; background-color: #0d0d0f; color: #f5f5f5; padding: 20px; border-radius: 8px;">
  <h2 style="color: #f97316; margin-top: 0;">Security Portal</h2>
  <h3 style="color: #d4d4d4; font-weight: normal; margin-bottom: 30px;">Secure Workspace</h3>
  
  <p style="font-size: 16px;">Your password reset OTP is:</p>
  
  <div style="background-color: #111113; border: 1px solid #333; padding: 15px; border-radius: 8px; text-align: center; margin: 20px 0;">
    <strong style="font-size: 32px; letter-spacing: 4px; color: #10b981;">${otp}</strong>
  </div>
  
  <p style="font-size: 14px; color: #a3a3a3;">This OTP expires in 10 minutes.</p>
  
  <div style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #333; font-size: 12px; color: #737373;">
    <strong>For your security:</strong>
    <ul style="padding-left: 20px;">
      <li>Never share this OTP.</li>
      <li>Support will never ask for your OTP.</li>
      <li>If you did not request a password reset, you can ignore this email.</li>
    </ul>
  </div>
</div>
    `.trim(),
  };

  try {
    // In dev mode with no SMTP configured, we just log and return
    if (!process.env.SMTP_HOST) {
      if (EMAIL_DEBUG) {
        console.log('[EMAIL DEV] SMTP_HOST not configured. Email not sent.');
        return;
      }
      throw new Error('Email service is not configured.');
    }
    await transporter.sendMail(mailOptions);
  } catch (error) {
    console.error('Error sending email:', error);
    throw new Error('Failed to send email. Please try again later.');
  }
};
