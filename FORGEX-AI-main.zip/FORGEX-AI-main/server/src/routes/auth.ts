import crypto from 'crypto';
import { sendPasswordResetOTP } from '../services/emailService';
import { Router } from 'express';
import { db } from '../index';

export const authRouter = Router();

// Helper to generate UUIDs
const generateId = () => crypto.randomUUID();

/**
 * Manager Signup
 * Receives email, passwordHash, publicKey, and encryptedPrivateKey
 */
authRouter.post('/signup', (req, res) => {
  const { name, email, passwordHash, publicKey, encryptedPrivateKey, role = 'manager' } = req.body;
  
  if (!name || !name.trim()) {
    return res.status(400).json({ error: 'Please enter your name.' });
  }

  if (!email || !passwordHash || !publicKey || !encryptedPrivateKey) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const validRoles = ['manager', 'developer', 'sales', 'tester', 'client'];
  if (!validRoles.includes(role)) {
    return res.status(400).json({ error: 'Invalid role' });
  }

  const id = generateId();
  const trimmedName = name.trim();
  
  const stmt = db.prepare(`
    INSERT INTO users (id, role, name, email, passwordHash, publicKey, encryptedPrivateKey)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);
  
  stmt.run([id, role, trimmedName, email, passwordHash, publicKey, encryptedPrivateKey], function(err) {
    if (err) {
      if (err.message.includes('UNIQUE constraint failed')) {
        return res.status(409).json({ error: 'Email already exists' });
      }
      console.error(err);
      return res.status(500).json({ error: 'Database error' });
    }
    
    res.status(201).json({ 
      message: `${role} account created`, 
      user: { id, name: trimmedName, email, role, publicKey, encryptedPrivateKey } 
    });
  });
});

/**
 * Login
 */
authRouter.post('/login', (req, res) => {
  const { email, passwordHash } = req.body;
  
  if (!email || !passwordHash) {
    return res.status(400).json({ error: 'Missing credentials' });
  }

  db.get(`SELECT * FROM users WHERE email = ? AND passwordHash = ?`, [email, passwordHash], (err, row: any) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Database error' });
    }
    if (!row) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }
    
    res.json({
      message: 'Login successful',
      user: {
        id: row.id,
        role: row.role,
        name: row.name || row.email.split('@')[0],
        email: row.email,
        publicKey: row.publicKey,
        encryptedPrivateKey: row.encryptedPrivateKey,
        managerId: row.managerId
      }
    });
  });
});

/**
 * Create Employee (Manager Action - developer, sales, tester)
 */
authRouter.post('/create-employee', (req, res) => {
  const { managerId, name, email, tempPasswordHash, role = 'developer' } = req.body;
  
  if (!managerId || !email || !tempPasswordHash) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const validEmployeeRoles = ['developer', 'sales', 'tester'];
  if (!validEmployeeRoles.includes(role)) {
    return res.status(400).json({ error: 'Invalid employee role' });
  }

  db.get(`SELECT id, role FROM users WHERE id = ?`, [managerId], (err, manager: any) => {
    if (err || !manager || manager.role !== 'manager') {
      return res.status(403).json({ error: 'Unauthorized: Only managers can create employees' });
    }

    const id = generateId();
    const empName = (name && name.trim()) || email.split('@')[0];
    const stmt = db.prepare(`
      INSERT INTO users (id, role, name, email, passwordHash, publicKey, encryptedPrivateKey, managerId)
      VALUES (?, ?, ?, ?, ?, 'PENDING', 'PENDING', ?)
    `);
    
    stmt.run([id, role, empName, email, tempPasswordHash, managerId], function(err) {
      if (err) {
        if (err.message.includes('UNIQUE constraint failed')) {
          return res.status(409).json({ error: 'Email already exists' });
        }
        console.error(err);
        return res.status(500).json({ error: 'Database error' });
      }
      
      db.run(`INSERT INTO audit_logs (id, userId, action) VALUES (?, ?, ?)`, [generateId(), managerId, `Created ${role} employee ${empName} (${email})`]);
      res.status(201).json({ message: `${role} account created successfully`, employeeId: id, id, role, name: empName });
    });
  });
});

/**
 * Legacy Create Developer endpoint (maps to create-employee)
 */
authRouter.post('/create-developer', (req, res) => {
  req.body.role = 'developer';
  const { managerId, name, email, tempPasswordHash } = req.body;
  
  if (!managerId || !email || !tempPasswordHash) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  db.get(`SELECT id, role FROM users WHERE id = ?`, [managerId], (err, manager: any) => {
    if (err || !manager || manager.role !== 'manager') {
      return res.status(403).json({ error: 'Unauthorized: Only managers can create developers' });
    }

    const id = generateId();
    const devName = (name && name.trim()) || email.split('@')[0];
    const stmt = db.prepare(`
      INSERT INTO users (id, role, name, email, passwordHash, publicKey, encryptedPrivateKey, managerId)
      VALUES (?, 'developer', ?, ?, ?, 'PENDING', 'PENDING', ?)
    `);
    
    stmt.run([id, devName, email, tempPasswordHash, managerId], function(err) {
      if (err) {
        if (err.message.includes('UNIQUE constraint failed')) {
          return res.status(409).json({ error: 'Email already exists' });
        }
        console.error(err);
        return res.status(500).json({ error: 'Database error' });
      }
      
      db.run(`INSERT INTO audit_logs (id, userId, action) VALUES (?, ?, ?)`, [generateId(), managerId, `Created developer ${devName} (${email})`]);
      res.status(201).json({ message: 'Developer stub created', developerId: id, id, name: devName });
    });
  });
});

/**
 * Create Client (Sales Action)
 */
authRouter.post('/create-client', (req, res) => {
  const { salesId, name, email, tempPasswordHash } = req.body;
  
  if (!salesId || !email || !tempPasswordHash) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  db.get(`SELECT id, role FROM users WHERE id = ?`, [salesId], (err, sales: any) => {
    if (err || !sales || sales.role !== 'sales') {
      return res.status(403).json({ error: 'Unauthorized: Only Sales agents can create client accounts' });
    }

    const id = generateId();
    const clientName = (name && name.trim()) || email.split('@')[0];
    const stmt = db.prepare(`
      INSERT INTO users (id, role, name, email, passwordHash, publicKey, encryptedPrivateKey, managerId)
      VALUES (?, 'client', ?, ?, ?, 'PENDING', 'PENDING', ?)
    `);
    
    stmt.run([id, clientName, email, tempPasswordHash, salesId], function(err) {
      if (err) {
        if (err.message.includes('UNIQUE constraint failed')) {
          return res.status(409).json({ error: 'Email already exists' });
        }
        console.error(err);
        return res.status(500).json({ error: 'Database error' });
      }
      
      db.run(`INSERT INTO audit_logs (id, userId, action) VALUES (?, ?, ?)`, [generateId(), salesId, `Created client account ${clientName} (${email})`]);
      res.status(201).json({ message: 'Client account created successfully', clientId: id, id, name: clientName });
    });
  });
});

/**
 * Register Keys (First Login for Developer/Sales/Tester/Client)
 */
authRouter.post('/register-keys', (req, res) => {
  const { userId, developerId, publicKey, encryptedPrivateKey } = req.body;
  const targetId = userId || developerId;
  
  if (!targetId || !publicKey || !encryptedPrivateKey) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  db.get(`SELECT id, publicKey FROM users WHERE id = ?`, [targetId], (err, user: any) => {
    if (err || !user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    if (user.publicKey !== 'PENDING') {
      return res.status(400).json({ error: 'Keys already registered for this user' });
    }

    const stmt = db.prepare(`UPDATE users SET publicKey = ?, encryptedPrivateKey = ? WHERE id = ?`);
    stmt.run([publicKey, encryptedPrivateKey, targetId], function(err) {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: 'Database error' });
      }
      
      db.run(`INSERT INTO audit_logs (id, userId, action) VALUES (?, ?, ?)`, [generateId(), targetId, `Registered cryptographic keys (First Login)`]);
      res.json({ message: 'Keys registered successfully' });
    });
  });
});

/**
 * Forgot Password - Step 1: Send OTP
 */
authRouter.post('/forgot-password/send-otp', async (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ error: 'Email required' });

  db.get(`SELECT id FROM users WHERE email = ?`, [email], async (err, user: any) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    
    // Privacy: Don't reveal if account exists or not
    if (!user) {
        // We still simulate a delay to prevent timing attacks, then return success.
        await new Promise(resolve => setTimeout(resolve, 500));
        return res.json({ message: 'If an account exists for this email, a reset OTP has been sent.' });
    }

    // Rate limiting: Check if an unexpired OTP was requested recently (cooldown)
    db.get(`SELECT id, createdAt FROM password_reset_tokens WHERE userId = ? AND used = 0 AND expiresAt > CURRENT_TIMESTAMP ORDER BY createdAt DESC LIMIT 1`, [user.id], async (err, lastToken: any) => {
        if (err) return res.status(500).json({ error: 'Database error' });
        
        if (lastToken) {
            const timeSinceCreated = Date.now() - new Date(lastToken.createdAt).getTime();
            if (timeSinceCreated < 45000) { // 45 seconds cooldown
                return res.status(429).json({ error: 'Please wait before requesting another OTP.' });
            }
        }

        // Invalidate previous active tokens for this user
        db.run(`UPDATE password_reset_tokens SET used = 1 WHERE userId = ? AND used = 0`, [user.id]);

        // Generate OTP
        const otp = crypto.randomInt(100000, 999999).toString();
        const otpHash = crypto.createHash('sha256').update(otp).digest('hex');
        const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString(); // 10 minutes

        const tokenId = crypto.randomUUID();
        db.run(`INSERT INTO password_reset_tokens (id, userId, otpHash, expiresAt) VALUES (?, ?, ?, ?)`, [tokenId, user.id, otpHash, expiresAt], async (err) => {
            if (err) return res.status(500).json({ error: 'Database error' });

            try {
                await sendPasswordResetOTP(email, otp);
                res.json({ message: 'If an account exists for this email, a reset OTP has been sent.' });
            } catch (emailErr: any) {
                // Delete the token if email failed to send
                db.run(`DELETE FROM password_reset_tokens WHERE id = ?`, [tokenId]);
                res.status(500).json({ error: emailErr.message || 'Failed to send email.' });
            }
        });
    });
  });
});

/**
 * Forgot Password - Step 2: Verify OTP + Set new password
 */

/**
 * Forgot Password - Verify OTP
 */
authRouter.post('/forgot-password/verify-otp', (req, res) => {
  const { email, otp } = req.body;
  if (!email || !otp) return res.status(400).json({ error: 'Missing fields' });

  db.get(`SELECT id FROM users WHERE email = ?`, [email], (err, user: any) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    if (!user) return res.status(400).json({ error: 'Invalid or expired OTP.' });

    const otpHash = crypto.createHash('sha256').update(otp).digest('hex');

    db.get(`SELECT * FROM password_reset_tokens WHERE userId = ? AND used = 0 AND expiresAt > CURRENT_TIMESTAMP ORDER BY createdAt DESC LIMIT 1`, [user.id], (err, token: any) => {
        if (err) return res.status(500).json({ error: 'Database error' });
        
        if (!token) return res.status(400).json({ error: 'Invalid or expired OTP.' });

        if (token.attemptCount >= 3) {
             db.run(`UPDATE password_reset_tokens SET used = 1 WHERE id = ?`, [token.id]);
             return res.status(400).json({ error: 'Too many failed attempts. Please request a new OTP.' });
        }

        if (token.otpHash !== otpHash) {
             db.run(`UPDATE password_reset_tokens SET attemptCount = attemptCount + 1 WHERE id = ?`, [token.id]);
             return res.status(400).json({ error: 'Invalid or expired OTP.' });
        }

        res.json({ message: 'OTP verified successfully' });
    });
  });
});



/**
 * Forgot Password - Verify OTP
 */
authRouter.post('/forgot-password/verify-otp', (req, res) => {
  const { email, otp } = req.body;
  if (!email || !otp) return res.status(400).json({ error: 'Missing fields' });

  db.get(`SELECT id FROM users WHERE email = ?`, [email], (err, user: any) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    if (!user) return res.status(400).json({ error: 'Invalid or expired OTP.' });

    const otpHash = crypto.createHash('sha256').update(otp).digest('hex');

    db.get(`SELECT * FROM password_reset_tokens WHERE userId = ? AND used = 0 AND expiresAt > CURRENT_TIMESTAMP ORDER BY createdAt DESC LIMIT 1`, [user.id], (err, token: any) => {
        if (err) return res.status(500).json({ error: 'Database error' });
        
        if (!token) return res.status(400).json({ error: 'Invalid or expired OTP.' });

        if (token.attemptCount >= 3) {
             db.run(`UPDATE password_reset_tokens SET used = 1 WHERE id = ?`, [token.id]);
             return res.status(400).json({ error: 'Too many failed attempts. Please request a new OTP.' });
        }

        if (token.otpHash !== otpHash) {
             db.run(`UPDATE password_reset_tokens SET attemptCount = attemptCount + 1 WHERE id = ?`, [token.id]);
             return res.status(400).json({ error: 'Invalid or expired OTP.' });
        }

        res.json({ message: 'OTP verified successfully' });
    });
  });
});


authRouter.post('/forgot-password/reset', (req, res) => {
  const { email, otp, newPasswordHash } = req.body;
  if (!email || !otp || !newPasswordHash) return res.status(400).json({ error: 'Missing fields' });

  db.get(`SELECT id FROM users WHERE email = ?`, [email], (err, user: any) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    if (!user) return res.status(400).json({ error: 'Invalid or expired OTP.' }); // Generic message

    const otpHash = crypto.createHash('sha256').update(otp).digest('hex');

    // Find valid token
    db.get(`SELECT * FROM password_reset_tokens WHERE userId = ? AND used = 0 AND expiresAt > CURRENT_TIMESTAMP ORDER BY createdAt DESC LIMIT 1`, [user.id], (err, token: any) => {
        if (err) return res.status(500).json({ error: 'Database error' });
        
        if (!token) return res.status(400).json({ error: 'Invalid or expired OTP.' });

        if (token.attemptCount >= 3) {
             db.run(`UPDATE password_reset_tokens SET used = 1 WHERE id = ?`, [token.id]);
             return res.status(400).json({ error: 'Too many failed attempts. Please request a new OTP.' });
        }

        if (token.otpHash !== otpHash) {
             db.run(`UPDATE password_reset_tokens SET attemptCount = attemptCount + 1 WHERE id = ?`, [token.id]);
             return res.status(400).json({ error: 'Invalid or expired OTP.' });
        }

        // Success! Mark token as used and update password
        db.run(`UPDATE password_reset_tokens SET used = 1 WHERE userId = ?`, [user.id]);
        
        db.run(`UPDATE users SET passwordHash = ? WHERE id = ?`, [newPasswordHash, user.id], function(err) {
            if (err) return res.status(500).json({ error: 'Database error' });
            
            db.run(`INSERT INTO audit_logs (id, userId, action) VALUES (?, ?, ?)`,
                [crypto.randomUUID(), user.id, `Password reset via OTP for ${email}`]);
                
            res.json({ message: 'Password updated successfully' });
        });
    });
  });
});
