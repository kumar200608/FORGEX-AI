import { Router } from 'express';
import { db } from '../index';
import crypto from 'crypto';

export const messagesRouter = Router();
const generateId = () => crypto.randomUUID();

// Send Message
messagesRouter.post('/', (req, res) => {
  const senderId = req.headers['x-user-id'];
  const { taskId, receiverId, encryptedPayload, wrappedKeyManager, wrappedKeyDeveloper } = req.body;
  
  if (!senderId || !taskId || !receiverId || !encryptedPayload) return res.status(400).json({ error: 'Missing fields' });

  const id = generateId();
  const stmt = db.prepare(`
    INSERT INTO messages (id, taskId, senderId, receiverId, encryptedPayload, wrappedKeyManager, wrappedKeyDeveloper)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);
  
  stmt.run([id, taskId, senderId, receiverId, encryptedPayload, wrappedKeyManager, wrappedKeyDeveloper], function(err) {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Database error' });
    }
    
    // Minimal metadata logging for messaging (no content)
    db.run(`INSERT INTO audit_logs (id, userId, taskId, action) VALUES (?, ?, ?, ?)`, 
      [generateId(), senderId, taskId, `Sent secure message`]);
      
    res.status(201).json({ message: 'Message sent', id });
  });
});
