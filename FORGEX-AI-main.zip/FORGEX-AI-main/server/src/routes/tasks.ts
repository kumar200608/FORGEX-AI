import { Router } from 'express';
import { db } from '../index';
import crypto from 'crypto';

export const tasksRouter = Router();
const generateId = () => crypto.randomUUID();

// Get Tasks by Role
tasksRouter.get('/', (req, res) => {
  const userId = req.headers['x-user-id'] as string;
  const role = req.headers['x-user-role'] as string;
  
  if (!userId || !role) return res.status(401).json({ error: 'Unauthorized' });

  let query = '';
  let params: any[] = [];

  if (role === 'manager') {
    query = `
      SELECT t.*, 
             uDev.email as developerEmail, 
             uTest.email as testerEmail, 
             uClient.email as clientEmail, 
             uSales.email as salesEmail 
      FROM tasks t 
      LEFT JOIN users uDev ON t.developerId = uDev.id 
      LEFT JOIN users uTest ON t.testerId = uTest.id 
      LEFT JOIN users uClient ON t.clientId = uClient.id 
      LEFT JOIN users uSales ON t.salesId = uSales.id 
      ORDER BY t.createdAt DESC`;
    params = [];
  } else if (role === 'sales') {
    query = `
      SELECT t.*, uClient.email as clientEmail 
      FROM tasks t 
      LEFT JOIN users uClient ON t.clientId = uClient.id 
      WHERE t.salesId = ? 
      ORDER BY t.createdAt DESC`;
    params = [userId];
  } else if (role === 'developer') {
    query = `SELECT * FROM tasks WHERE developerId = ? ORDER BY createdAt DESC`;
    params = [userId];
  } else if (role === 'tester') {
    query = `SELECT * FROM tasks WHERE testerId = ? OR status IN ('READY_FOR_TESTING', 'TESTING', 'RETURNED_TO_DEVELOPER') ORDER BY createdAt DESC`;
    params = [userId];
  } else if (role === 'client') {
    query = `SELECT * FROM tasks WHERE clientId = ? ORDER BY createdAt DESC`;
    params = [userId];
  } else {
    return res.status(400).json({ error: 'Invalid role' });
  }
    
  db.all(query, params, (err, rows) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Database error' });
    }
    res.json(rows || []);
  });
});

// Get single Task details (with reports, messages, bugs, change requests)
tasksRouter.get('/:id', (req, res) => {
  const { id } = req.params;
  const userId = req.headers['x-user-id'] as string;
  
  db.get(`SELECT * FROM tasks WHERE id = ?`, [id], (err, task) => {
    if (err || !task) return res.status(404).json({ error: 'Task not found' });
    
    db.all(`SELECT * FROM reports WHERE taskId = ? ORDER BY timestamp ASC`, [id], (err, reports) => {
      db.all(`SELECT * FROM messages WHERE taskId = ? ORDER BY timestamp ASC`, [id], (err, messages) => {
        db.all(`SELECT * FROM bugs WHERE taskId = ? ORDER BY createdAt DESC`, [id], (err, bugs) => {
          db.all(`SELECT * FROM change_requests WHERE taskId = ? ORDER BY createdAt DESC`, [id], (err, changeRequests) => {
            res.json({
              task,
              reports: reports || [],
              messages: messages || [],
              bugs: bugs || [],
              changeRequests: changeRequests || []
            });
          });
        });
      });
    });
  });
});

// 1. Sales Creates Requirement & Quotation Intake
tasksRouter.post('/sales-intake', (req, res) => {
  const salesId = req.headers['x-user-id'] as string;
  const { 
    clientId, managerId, title, projectType, clientBudget, quotedPrice, 
    encryptedPayload, wrappedKeySales, wrappedKeyManager 
  } = req.body;
  
  if (!salesId || !clientId || !title || !encryptedPayload) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const id = generateId();
  // Find a manager if not provided
  const findManager = (cb: (mId: string) => void) => {
    if (managerId) return cb(managerId);
    db.get(`SELECT id FROM users WHERE role = 'manager' LIMIT 1`, [], (err, mgr: any) => {
      cb(mgr ? mgr.id : salesId);
    });
  };

  findManager((targetManagerId) => {
    const stmt = db.prepare(`
      INSERT INTO tasks (
        id, managerId, salesId, clientId, title, projectType, clientBudget, quotedPrice, 
        status, quotationStatus, encryptedPayload, wrappedKeySales, wrappedKeyManager
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'SENT_TO_MANAGER', 'SENT_TO_MANAGER', ?, ?, ?)
    `);

    stmt.run([
      id, targetManagerId, salesId, clientId, title, projectType || 'Web App', clientBudget || '0', quotedPrice || '0',
      encryptedPayload, wrappedKeySales || '', wrappedKeyManager || ''
    ], function(err) {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: 'Database error' });
      }
      
      db.run(`INSERT INTO audit_logs (id, userId, taskId, action) VALUES (?, ?, ?, ?)`, 
        [generateId(), salesId, id, `Sales intake created: ${title} (Sent to Manager)`]);
        
      res.status(201).json({ message: 'Project requirement and quotation submitted to Manager', id });
    });
  });
});

// Legacy Task Creation by Manager
tasksRouter.post('/', (req, res) => {
  const managerId = req.headers['x-user-id'] as string;
  const { developerId, testerId, clientId, title, encryptedPayload, wrappedKeyManager, wrappedKeyDeveloper, deadline, isEphemeral } = req.body;
  
  if (!managerId || !developerId || !title || !encryptedPayload) return res.status(400).json({ error: 'Missing fields' });

  const id = generateId();
  const stmt = db.prepare(`
    INSERT INTO tasks (id, managerId, developerId, testerId, clientId, title, status, encryptedPayload, wrappedKeyManager, wrappedKeyDeveloper, deadline, isEphemeral)
    VALUES (?, ?, ?, ?, ?, ?, 'DEVELOPER_ASSIGNED', ?, ?, ?, ?, ?)
  `);
  
  stmt.run([id, managerId, developerId, testerId || null, clientId || null, title, encryptedPayload, wrappedKeyManager, wrappedKeyDeveloper, deadline, isEphemeral ? 1 : 0], function(err) {
    if (err) return res.status(500).json({ error: 'Database error' });
    
    db.run(`INSERT INTO audit_logs (id, userId, taskId, action) VALUES (?, ?, ?, ?)`, 
      [generateId(), managerId, id, `Created task: ${title}`]);
      
    res.status(201).json({ message: 'Task created', id });
  });
});

// 2. Manager Approves Sales Intake
tasksRouter.patch('/:id/manager-approve-intake', (req, res) => {
  const { id } = req.params;
  const managerId = req.headers['x-user-id'] as string;

  db.run(`UPDATE tasks SET status = 'APPROVED', quotationStatus = 'APPROVED', updatedAt = CURRENT_TIMESTAMP WHERE id = ?`, [id], function(err) {
    if (err) return res.status(500).json({ error: 'Database error' });
    
    db.run(`INSERT INTO audit_logs (id, userId, taskId, action) VALUES (?, ?, ?, ?)`, 
      [generateId(), managerId, id, `Manager approved Sales requirement & quotation`]);
      
    res.json({ message: 'Project intake approved by Manager' });
  });
});

// 3. Manager Assigns Developer & Tester
tasksRouter.patch('/:id/assign-developer', (req, res) => {
  const { id } = req.params;
  const managerId = req.headers['x-user-id'] as string;
  const { developerId, testerId, wrappedKeyDeveloper, wrappedKeyTester } = req.body;

  if (!developerId) return res.status(400).json({ error: 'Developer ID required' });

  db.run(`
    UPDATE tasks 
    SET developerId = ?, 
        testerId = COALESCE(?, testerId), 
        wrappedKeyDeveloper = COALESCE(?, wrappedKeyDeveloper), 
        wrappedKeyTester = COALESCE(?, wrappedKeyTester), 
        status = 'IN_DEVELOPMENT', 
        updatedAt = CURRENT_TIMESTAMP 
    WHERE id = ?
  `, [developerId, testerId || null, wrappedKeyDeveloper || null, wrappedKeyTester || null, id], function(err) {
    if (err) return res.status(500).json({ error: 'Database error' });
    
    db.run(`INSERT INTO audit_logs (id, userId, taskId, action) VALUES (?, ?, ?, ?)`, 
      [generateId(), managerId, id, `Manager assigned Developer (${developerId}) and Tester (${testerId || 'pending'})`]);
      
    res.json({ message: 'Developer assigned successfully' });
  });
});

// 4. Developer Submits Work to Tester
tasksRouter.post('/:id/submit-to-tester', (req, res) => {
  const { id } = req.params;
  const developerId = req.headers['x-user-id'] as string;
  const { encryptedPayload, wrappedKeyTester, wrappedKeyManager } = req.body;

  db.run(`
    UPDATE tasks 
    SET status = 'TESTING', 
        wrappedKeyTester = COALESCE(?, wrappedKeyTester), 
        wrappedKeyManager = COALESCE(?, wrappedKeyManager), 
        updatedAt = CURRENT_TIMESTAMP 
    WHERE id = ?
  `, [wrappedKeyTester || null, wrappedKeyManager || null, id], function(err) {
    if (err) return res.status(500).json({ error: 'Database error' });

    // Also record a report entry
    const reportId = generateId();
    db.run(`
      INSERT INTO reports (id, taskId, developerId, encryptedPayload, wrappedKeyManager, wrappedKeyDeveloper, wrappedKeyTester)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `, [reportId, id, developerId, encryptedPayload || 'Submitted work', wrappedKeyManager || '', '', wrappedKeyTester || '']);

    db.run(`INSERT INTO audit_logs (id, userId, taskId, action) VALUES (?, ?, ?, ?)`, 
      [generateId(), developerId, id, `Developer submitted work to Tester`]);
      
    res.json({ message: 'Work submitted to Tester' });
  });
});

// 5. Tester Logs Bug
tasksRouter.post('/:id/bugs', (req, res) => {
  const { id } = req.params;
  const testerId = req.headers['x-user-id'] as string;
  const { developerId, title, description, expectedResult, actualResult, severity = 'MEDIUM' } = req.body;

  if (!title || !description) return res.status(400).json({ error: 'Title and description required' });

  const bugId = generateId();
  db.run(`
    INSERT INTO bugs (id, taskId, testerId, developerId, title, description, expectedResult, actualResult, severity, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'OPEN')
  `, [bugId, id, testerId, developerId || null, title, description, expectedResult || '', actualResult || '', severity], function(err) {
    if (err) return res.status(500).json({ error: 'Database error' });

    // Update task status back to RETURNED_TO_DEVELOPER
    db.run(`UPDATE tasks SET status = 'RETURNED_TO_DEVELOPER', updatedAt = CURRENT_TIMESTAMP WHERE id = ?`, [id]);

    db.run(`INSERT INTO audit_logs (id, userId, taskId, action) VALUES (?, ?, ?, ?)`, 
      [generateId(), testerId, id, `Tester logged bug: "${title}" (Returned to Developer)`]);

    res.status(201).json({ message: 'Bug logged and returned to Developer', bugId });
  });
});

// Update Bug Status (Developer Fixes / Tester Verifies)
tasksRouter.patch('/bugs/:bugId/status', (req, res) => {
  const { bugId } = req.params;
  const userId = req.headers['x-user-id'] as string;
  const { status } = req.body; // FIXED, VERIFIED, REJECTED, OPEN

  db.run(`UPDATE bugs SET status = ?, updatedAt = CURRENT_TIMESTAMP WHERE id = ?`, [status, bugId], function(err) {
    if (err) return res.status(500).json({ error: 'Database error' });
    
    db.run(`INSERT INTO audit_logs (id, userId, action) VALUES (?, ?, ?)`, 
      [generateId(), userId, `Updated bug ${bugId} status to: ${status}`]);

    res.json({ message: 'Bug status updated' });
  });
});

// 6. Tester Approves Work for Manager
tasksRouter.patch('/:id/tester-approve', (req, res) => {
  const { id } = req.params;
  const testerId = req.headers['x-user-id'] as string;

  db.run(`UPDATE tasks SET status = 'MANAGER_REVIEW', updatedAt = CURRENT_TIMESTAMP WHERE id = ?`, [id], function(err) {
    if (err) return res.status(500).json({ error: 'Database error' });
    
    db.run(`INSERT INTO audit_logs (id, userId, taskId, action) VALUES (?, ?, ?, ?)`, 
      [generateId(), testerId, id, `Tester approved all test cases (Advanced to Manager Review)`]);

    res.json({ message: 'Testing passed and approved for Manager review' });
  });
});

// 7. Manager Delivers Work to Client
tasksRouter.patch('/:id/deliver-to-client', (req, res) => {
  const { id } = req.params;
  const managerId = req.headers['x-user-id'] as string;
  const { wrappedKeyClient, version } = req.body;

  db.run(`
    UPDATE tasks 
    SET status = 'CLIENT_REVIEW', 
        wrappedKeyClient = COALESCE(?, wrappedKeyClient), 
        version = COALESCE(?, version), 
        updatedAt = CURRENT_TIMESTAMP 
    WHERE id = ?
  `, [wrappedKeyClient || null, version || null, id], function(err) {
    if (err) return res.status(500).json({ error: 'Database error' });
    
    db.run(`INSERT INTO audit_logs (id, userId, taskId, action) VALUES (?, ?, ?, ?)`, 
      [generateId(), managerId, id, `Manager delivered project version (${version || 'v1'}) to Client`]);

    res.json({ message: 'Project delivered to Client for review' });
  });
});

// 8. Client Review (Satisfied -> Completed, Not Satisfied -> Change Request to Manager)
tasksRouter.patch('/:id/client-review', (req, res) => {
  const { id } = req.params;
  const clientId = req.headers['x-user-id'] as string;
  const { action, feedbackPayload, wrappedKeyClient, wrappedKeyManager } = req.body; // action: 'SATISFIED' | 'NOT_SATISFIED'

  if (action === 'SATISFIED') {
    db.run(`UPDATE tasks SET status = 'COMPLETED', updatedAt = CURRENT_TIMESTAMP WHERE id = ?`, [id], function(err) {
      if (err) return res.status(500).json({ error: 'Database error' });
      
      db.run(`INSERT INTO audit_logs (id, userId, taskId, action) VALUES (?, ?, ?, ?)`, 
        [generateId(), clientId, id, `Client marked project as Satisfied (COMPLETED)`]);

      res.json({ message: 'Project successfully completed!' });
    });
  } else if (action === 'NOT_SATISFIED') {
    db.get(`SELECT changeRequestCount FROM tasks WHERE id = ?`, [id], (err, task: any) => {
      const newCount = ((task ? task.changeRequestCount : 0) || 0) + 1;
      
      db.run(`
        UPDATE tasks 
        SET status = 'CHANGES_REQUESTED', 
            changeRequestCount = ?, 
            updatedAt = CURRENT_TIMESTAMP 
        WHERE id = ?
      `, [newCount, id], function(err) {
        if (err) return res.status(500).json({ error: 'Database error' });

        const reqId = generateId();
        db.run(`
          INSERT INTO change_requests (id, taskId, clientId, requestNumber, feedbackPayload, wrappedKeyManager, wrappedKeyClient, status)
          VALUES (?, ?, ?, ?, ?, ?, ?, 'PENDING_MANAGER')
        `, [reqId, id, clientId, newCount, feedbackPayload || 'Client requested update', wrappedKeyManager || '', wrappedKeyClient || '']);

        db.run(`INSERT INTO audit_logs (id, userId, taskId, action) VALUES (?, ?, ?, ?)`, 
          [generateId(), clientId, id, `Client submitted Change Request #${newCount} to Manager`]);

        res.json({ message: 'Change request submitted to Manager' });
      });
    });
  } else {
    res.status(400).json({ error: 'Invalid client review action' });
  }
});

// 9. Manager Reviews Client Change Request (Approve -> Developer, Reject -> Delivered/Closed)
tasksRouter.patch('/:id/manager-review-change', (req, res) => {
  const { id } = req.params;
  const managerId = req.headers['x-user-id'] as string;
  const { decision, rejectionReason } = req.body; // decision: 'APPROVE' | 'REJECT'

  if (decision === 'APPROVE') {
    db.run(`UPDATE tasks SET status = 'IN_DEVELOPMENT', updatedAt = CURRENT_TIMESTAMP WHERE id = ?`, [id], function(err) {
      if (err) return res.status(500).json({ error: 'Database error' });
      
      db.run(`INSERT INTO audit_logs (id, userId, taskId, action) VALUES (?, ?, ?, ?)`, 
        [generateId(), managerId, id, `Manager APPROVED Client Change Request (Routed to Developer)`]);

      res.json({ message: 'Change request approved and sent to Developer' });
    });
  } else if (decision === 'REJECT') {
    db.run(`
      UPDATE tasks 
      SET status = 'REJECTED', 
          rejectionReason = ?, 
          updatedAt = CURRENT_TIMESTAMP 
      WHERE id = ?
    `, [rejectionReason || 'Manager rejected change request', id], function(err) {
      if (err) return res.status(500).json({ error: 'Database error' });

      db.run(`INSERT INTO audit_logs (id, userId, taskId, action) VALUES (?, ?, ?, ?)`, 
        [generateId(), managerId, id, `Manager REJECTED Client Change Request: "${rejectionReason || 'No reason specified'}". (NO Developer task created, project closed/delivered)`]);

      res.json({ message: 'Client change request rejected by Manager' });
    });
  } else {
    res.status(400).json({ error: 'Invalid manager decision' });
  }
});

// 10. Manager Stop / Close Project
tasksRouter.patch('/:id/stop-project', (req, res) => {
  const { id } = req.params;
  const managerId = req.headers['x-user-id'] as string;
  const { stopReason } = req.body;

  db.run(`
    UPDATE tasks 
    SET status = 'CLOSED', 
        stopReason = ?, 
        updatedAt = CURRENT_TIMESTAMP 
    WHERE id = ?
  `, [stopReason || 'Project stopped by Manager', id], function(err) {
    if (err) return res.status(500).json({ error: 'Database error' });
    
    db.run(`INSERT INTO audit_logs (id, userId, taskId, action) VALUES (?, ?, ?, ?)`, 
      [generateId(), managerId, id, `Manager STOPPED / CLOSED Project: "${stopReason || 'No reason specified'}"`]);

    res.json({ message: 'Project stopped and closed by Manager' });
  });
});

// Update Task Status general endpoint
tasksRouter.patch('/:id/status', (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  const userId = req.headers['x-user-id'] as string;

  db.run(`UPDATE tasks SET status = ?, updatedAt = CURRENT_TIMESTAMP WHERE id = ?`, [status, id], function(err) {
    if (err) return res.status(500).json({ error: 'Database error' });
    
    db.run(`INSERT INTO audit_logs (id, userId, taskId, action) VALUES (?, ?, ?, ?)`, 
      [generateId(), userId, id, `Updated task status to: ${status}`]);
      
    res.json({ message: 'Status updated' });
  });
});

// Reassign Task & Rotate Keys
tasksRouter.post('/:id/reassign', (req, res) => {
  const { id } = req.params;
  const managerId = req.headers['x-user-id'] as string;
  const { newDeveloperId, newWrappedKeyDeveloper, encryptedPayload, wrappedKeyManager } = req.body;

  db.run(`UPDATE tasks SET developerId = ?, wrappedKeyDeveloper = ?, encryptedPayload = ?, wrappedKeyManager = ?, updatedAt = CURRENT_TIMESTAMP WHERE id = ? AND managerId = ?`, 
    [newDeveloperId, newWrappedKeyDeveloper, encryptedPayload, wrappedKeyManager, id, managerId], function(err) {
    if (err) return res.status(500).json({ error: 'Database error' });
    
    db.run(`INSERT INTO audit_logs (id, userId, taskId, action) VALUES (?, ?, ?, ?)`, 
      [generateId(), managerId, id, `Reassigned task to new developer (Key Rotated, Access Revoked for previous)`]);
      
    res.json({ message: 'Task reassigned securely' });
  });
});

// Submit 3-Hour Report
tasksRouter.post('/:id/reports', (req, res) => {
  const { id } = req.params;
  const developerId = req.headers['x-user-id'] as string;
  const { encryptedPayload, wrappedKeyManager, wrappedKeyDeveloper, isFinal } = req.body;

  const reportId = generateId();
  db.run(`
    INSERT INTO reports (id, taskId, developerId, encryptedPayload, wrappedKeyManager, wrappedKeyDeveloper)
    VALUES (?, ?, ?, ?, ?, ?)
  `, [reportId, id, developerId, encryptedPayload, wrappedKeyManager, wrappedKeyDeveloper], function(err) {
    if (err) return res.status(500).json({ error: 'Database error' });
    
    const actionDesc = isFinal ? 'Submitted final task result' : 'Submitted 3-hour status report';
    db.run(`INSERT INTO audit_logs (id, userId, taskId, action) VALUES (?, ?, ?, ?)`, 
      [generateId(), developerId, id, actionDesc]);
      
    if (isFinal) {
      db.run(`UPDATE tasks SET status = 'TESTING', updatedAt = CURRENT_TIMESTAMP WHERE id = ?`, [id]);
    }

    res.status(201).json({ message: 'Report submitted securely' });
  });
});
