import { Router } from 'express';
import { db } from '../index';

export const usersRouter = Router();

// Get Developers for a Manager
usersRouter.get('/developers', (req, res) => {
  const managerId = req.headers['x-user-id'];
  if (!managerId) return res.status(401).json({ error: 'Unauthorized' });

  db.all(`SELECT id, name, email, publicKey, role, createdAt FROM users WHERE role = 'developer'`, [], (err, rows) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    res.json(rows);
  });
});

// Get Testers
usersRouter.get('/testers', (req, res) => {
  db.all(`SELECT id, name, email, publicKey, role, createdAt FROM users WHERE role = 'tester'`, [], (err, rows) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    res.json(rows);
  });
});

// Get Sales
usersRouter.get('/sales', (req, res) => {
  db.all(`SELECT id, name, email, publicKey, role, createdAt FROM users WHERE role = 'sales'`, [], (err, rows) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    res.json(rows);
  });
});

// Get Clients
usersRouter.get('/clients', (req, res) => {
  db.all(`SELECT id, name, email, publicKey, role, createdAt FROM users WHERE role = 'client'`, [], (err, rows) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    res.json(rows);
  });
});

// Generic role query
usersRouter.get('/role/:role', (req, res) => {
  const { role } = req.params;
  db.all(`SELECT id, name, email, publicKey, role, managerId, createdAt FROM users WHERE role = ?`, [role], (err, rows) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    res.json(rows);
  });
});

// Get Public Key for a specific user (needed for encryption)
usersRouter.get('/:id/public-key', (req, res) => {
  db.get(`SELECT publicKey FROM users WHERE id = ?`, [req.params.id], (err, row: any) => {
    if (err || !row) return res.status(404).json({ error: 'User not found' });
    res.json({ publicKey: row.publicKey });
  });
});

// Get Audit Logs for Manager
usersRouter.get('/audit', (req, res) => {
  const managerId = req.headers['x-user-id'];
  
  if (!managerId) return res.status(401).json({ error: 'Unauthorized' });

  // Get logs for the manager and their developers
  db.all(`
    SELECT a.*, u.email as userEmail, u.name as userName 
    FROM audit_logs a 
    JOIN users u ON a.userId = u.id 
    WHERE a.userId = ? OR a.userId IN (SELECT id FROM users WHERE managerId = ?)
    ORDER BY a.timestamp DESC LIMIT 100
  `, [managerId, managerId], (err, rows) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Database error' });
    }
    res.json(rows);
  });
});
