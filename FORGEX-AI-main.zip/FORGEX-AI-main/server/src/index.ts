import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import sqlite3 from 'sqlite3';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

const generateId = () => crypto.randomUUID();

dotenv.config();

const app = express();
const port = process.env.PORT || 3001;

app.use(cors());
app.use(express.json());

// Initialize SQLite database
const dbPath = path.resolve(__dirname, '../../database.sqlite');
const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error('Error opening database', err);
  } else {
    console.log('Database connected');
    // Run schema
    const schemaPathSrc = path.resolve(__dirname, '../src/db/schema.sql');
    const schemaPathDist = path.resolve(__dirname, './db/schema.sql');
    const schemaPath = fs.existsSync(schemaPathDist) ? schemaPathDist : schemaPathSrc;
    if (fs.existsSync(schemaPath)) {
      const schema = fs.readFileSync(schemaPath, 'utf8');
      db.exec(schema, (err) => {
        if (err) {
          console.error('Error executing schema', err);
        } else {
          console.log('Schema loaded');
          // Migration helper for new Phase 5 columns & users/tasks schema
          db.run(`PRAGMA foreign_keys=OFF;`, () => {
            db.exec(`
              CREATE TABLE IF NOT EXISTS users_temp (
                id TEXT PRIMARY KEY,
                role TEXT NOT NULL CHECK(role IN ('manager', 'developer', 'sales', 'tester', 'client')),
                name TEXT,
                email TEXT UNIQUE NOT NULL,
                passwordHash TEXT NOT NULL,
                publicKey TEXT NOT NULL,
                encryptedPrivateKey TEXT NOT NULL,
                managerId TEXT,
                createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
              );
              INSERT OR IGNORE INTO users_temp (id, role, name, email, passwordHash, publicKey, encryptedPrivateKey, managerId, createdAt) 
              SELECT id, role, name, email, passwordHash, publicKey, encryptedPrivateKey, managerId, createdAt FROM users;
              DROP TABLE users;
              ALTER TABLE users_temp RENAME TO users;

              CREATE TABLE IF NOT EXISTS tasks_temp (
                id TEXT PRIMARY KEY,
                managerId TEXT NOT NULL,
                developerId TEXT,
                testerId TEXT,
                clientId TEXT,
                salesId TEXT,
                title TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'DRAFT',
                encryptedPayload TEXT NOT NULL,
                wrappedKeyManager TEXT,
                wrappedKeyDeveloper TEXT,
                wrappedKeyTester TEXT,
                wrappedKeyClient TEXT,
                wrappedKeySales TEXT,
                projectType TEXT,
                clientBudget TEXT,
                quotedPrice TEXT,
                quotationStatus TEXT DEFAULT 'DRAFT',
                changeRequestCount INTEGER DEFAULT 0,
                rejectionReason TEXT,
                stopReason TEXT,
                version TEXT DEFAULT 'v1',
                deadline DATETIME,
                isEphemeral BOOLEAN DEFAULT 0,
                createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
                updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
              );
              INSERT OR IGNORE INTO tasks_temp (id, managerId, developerId, title, status, encryptedPayload, wrappedKeyManager, wrappedKeyDeveloper, deadline, isEphemeral, createdAt, updatedAt) 
              SELECT id, managerId, developerId, title, status, encryptedPayload, wrappedKeyManager, wrappedKeyDeveloper, deadline, isEphemeral, createdAt, updatedAt FROM tasks;
              DROP TABLE tasks;
              ALTER TABLE tasks_temp RENAME TO tasks;
              PRAGMA foreign_keys=ON;
            `, (e) => {});
          });

          const alterCols = [
            'ALTER TABLE users ADD COLUMN name TEXT',
            'ALTER TABLE reports ADD COLUMN wrappedKeyTester TEXT',
            'ALTER TABLE reports ADD COLUMN wrappedKeyClient TEXT',
            'ALTER TABLE reports ADD COLUMN wrappedKeySales TEXT',
            'ALTER TABLE messages ADD COLUMN wrappedKeyTester TEXT',
            'ALTER TABLE messages ADD COLUMN wrappedKeyClient TEXT',
            'ALTER TABLE messages ADD COLUMN wrappedKeySales TEXT'
          ];
          alterCols.forEach(cmd => db.run(cmd, () => {}));
        }
      });
    }
  }
});

import { authRouter } from './routes/auth';
import { usersRouter } from './routes/users';
import { tasksRouter } from './routes/tasks';
import { messagesRouter } from './routes/messages';

// Basic health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok' });
});

// Add Audit Log
app.post('/api/audit', (req, res) => {
  const userId = req.headers['x-user-id'];
  const { action, taskId } = req.body;
  if (!userId || !action) return res.status(400).json({ error: 'Missing fields' });
  
  db.run(`INSERT INTO audit_logs (id, userId, taskId, action) VALUES (?, ?, ?, ?)`, 
    [generateId(), userId, taskId || null, action], function(err) {
      if (err) return res.status(500).json({ error: 'Database error' });
      res.json({ success: true });
    });
});

// Deadline & Ephemeral Shredding Background Job
setInterval(() => {
  const now = new Date().toISOString();
  
  // 1. Mark Overdue
  db.run(`UPDATE tasks SET status = 'OVERDUE', updatedAt = CURRENT_TIMESTAMP WHERE status IN ('ASSIGNED', 'IN_PROGRESS') AND deadline < ? AND deadline IS NOT NULL`, [now], function(err) {
    if (err) console.error('Deadline job error:', err);
    else if (this.changes > 0) console.log(`[Job] Marked ${this.changes} tasks as OVERDUE`);
  });

  // 2. Shred Ephemeral Keys (for completed or overdue tasks)
  db.run(`UPDATE tasks SET wrappedKeyManager = 'SHREDDED', wrappedKeyDeveloper = 'SHREDDED', updatedAt = CURRENT_TIMESTAMP WHERE isEphemeral = 1 AND status IN ('COMPLETED', 'OVERDUE') AND wrappedKeyManager != 'SHREDDED'`, [], function(err) {
    if (err) console.error('Shred job error:', err);
    else if (this.changes > 0) {
      console.log(`[Job] Shredded keys for ${this.changes} ephemeral tasks`);
      // Add audit log for system shredding
      db.run(`INSERT INTO audit_logs (id, userId, taskId, action) VALUES (?, ?, ?, ?)`, 
        [Math.random().toString(36).substring(2, 15), 'SYSTEM', null, `Shredded cryptographic keys for ${this.changes} ephemeral tasks`]);
    }
  });

}, 60000); // Check every minute

// Routes
app.use('/api/auth', authRouter);
app.use('/api/users', usersRouter);
app.use('/api/tasks', tasksRouter);
app.use('/api/messages', messagesRouter);

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});

export { db };
