const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const db = new sqlite3.Database(path.resolve(__dirname, '../database.sqlite'));

db.all("SELECT * FROM users", (err, rows) => {
  console.log("=== USERS ===");
  rows.forEach(r => console.log(JSON.stringify(r)));
});

db.all("SELECT * FROM tasks", (err, rows) => {
  console.log("\n=== TASKS ===");
  rows.forEach(r => console.log(JSON.stringify(r)));
});

db.all("SELECT * FROM audit_logs", (err, rows) => {
  console.log("\n=== AUDIT LOGS ===");
  rows.forEach(r => console.log(JSON.stringify(r)));
});
