const crypto = require('crypto');

// Setup WebCrypto for Node
const { subtle } = crypto.webcrypto;

const BASE_URL = 'http://localhost:3001/api';

async function generateKeyPair() {
  return await subtle.generateKey(
    { name: 'ECDH', namedCurve: 'P-256' },
    true,
    ['deriveKey', 'deriveBits']
  );
}

async function exportPublicKey(key) {
  const exported = await subtle.exportKey('raw', key);
  return Buffer.from(exported).toString('base64');
}

async function runTests() {
  console.log("=== WA-3 INTEGRATION TESTS ===\n");
  let mgrId = '';
  let devEmail = `dev_${Date.now()}@test.com`;
  let devId = '';
  
  try {
    console.log("1. Manager Signup");
    const kpMgr = await generateKeyPair();
    const pubMgr = await exportPublicKey(kpMgr.publicKey);
    
    // Hash password
    const pwHashBuffer = await subtle.digest('SHA-256', new TextEncoder().encode("managerpass"));
    const pwHash = Array.from(new Uint8Array(pwHashBuffer)).map(x => x.toString(16).padStart(2, '0')).join('');

    const res1 = await fetch(`${BASE_URL}/auth/signup`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: `manager_${Date.now()}@test.com`,
        passwordHash: pwHash,
        publicKey: pubMgr,
        encryptedPrivateKey: "MOCK_ENCRYPTED_KEY_BLOB_FOR_TESTING"
      })
    });
    if (!res1.ok) throw new Error(await res1.text());
    const data1 = await res1.json();
    mgrId = data1.user.id;
    console.log("   ✅ Manager Signed Up. ID:", mgrId);

    console.log("2. Manager Login");
    const res2 = await fetch(`${BASE_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: data1.user.email,
        passwordHash: pwHash
      })
    });
    if (!res2.ok) throw new Error("Login failed");
    console.log("   ✅ Manager Logged In.");

    console.log("3. Create Developer (Manager Action)");
    const devPwHashBuffer = await subtle.digest('SHA-256', new TextEncoder().encode("devpass"));
    const devPwHash = Array.from(new Uint8Array(devPwHashBuffer)).map(x => x.toString(16).padStart(2, '0')).join('');
    const res3 = await fetch(`${BASE_URL}/auth/create-developer`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-user-id': mgrId, 'x-user-role': 'manager' },
      body: JSON.stringify({
        managerId: mgrId,
        email: devEmail,
        tempPasswordHash: devPwHash
      })
    });
    if (!res3.ok) throw new Error(await res3.text());
    console.log("   ✅ Developer created (stub).");

    console.log("4. Developer First Login & Key Registration");
    const res4 = await fetch(`${BASE_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: devEmail,
        passwordHash: devPwHash
      })
    });
    const data4 = await res4.json();
    if (data4.user.publicKey !== 'PENDING') throw new Error("Expected PENDING public key");
    devId = data4.user.id;

    // Register Dev Keys
    const kpDev = await generateKeyPair();
    const pubDev = await exportPublicKey(kpDev.publicKey);
    const res5 = await fetch(`${BASE_URL}/auth/register-keys`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        developerId: devId,
        publicKey: pubDev,
        encryptedPrivateKey: "MOCK_DEV_ENCRYPTED_KEY_BLOB"
      })
    });
    if (!res5.ok) throw new Error("Key registration failed");
    console.log("   ✅ Developer keys registered.");

    console.log("5. Role-Based Access Control Checks");
    const resRbac = await fetch(`${BASE_URL}/users/developers`, {
      headers: { 'x-user-id': devId, 'x-user-role': 'developer' } // dev trying to access manager endpoint
    });
    const rbacData = await resRbac.json();
    if (rbacData.length === 0) console.log("   ✅ RBAC check passed (dev has no developers)");
    else console.warn("   ⚠️ Dev was able to fetch developers?", rbacData);

    console.log("6. Audit Log Check");
    const resAudit = await fetch(`${BASE_URL}/users/audit`, {
      headers: { 'x-user-id': mgrId, 'x-user-role': 'manager' }
    });
    const auditData = await resAudit.json();
    if (auditData.length > 0) console.log("   ✅ Audit logs retrieved (length:", auditData.length, ")");
    else throw new Error("No audit logs found");
    
    // Check if task endpoints work
    console.log("7. Create Task & Hybrid Encryption Mock test");
    const resTask = await fetch(`${BASE_URL}/tasks`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-user-id': mgrId, 'x-user-role': 'manager' },
      body: JSON.stringify({
        developerId: devId,
        title: "Test Security Task",
        deadline: new Date().toISOString(),
        encryptedPayload: "E2E_CIPHERTEXT",
        wrappedKeyManager: "MGR_WRAPPED_AES_KEY",
        wrappedKeyDeveloper: "DEV_WRAPPED_AES_KEY"
      })
    });
    if (!resTask.ok) throw new Error(await resTask.text());
    const dataTask = await resTask.json();
    const taskId = dataTask.id;
    console.log("   ✅ Task created. ID:", taskId);

    // Reassignment Test
    console.log("8. Reassign Task");
    const resReassign = await fetch(`${BASE_URL}/tasks/${taskId}/reassign`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-user-id': mgrId, 'x-user-role': 'manager' },
      body: JSON.stringify({
        newDeveloperId: "dev-2-id",
        newWrappedKeyDeveloper: "NEW_DEV_WRAPPED_KEY"
      })
    });
    if (!resReassign.ok) throw new Error(await resReassign.text());
    console.log("   ✅ Task Reassigned Securely");

    console.log("\n✅ ALL API / WORKFLOW TESTS PASSED");

  } catch (err) {
    console.error("❌ TEST FAILED:", err.message || err);
  }
}

runTests();
