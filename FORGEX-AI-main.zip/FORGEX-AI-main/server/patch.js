const fs = require('fs');
let code = fs.readFileSync('src/routes/auth.ts', 'utf8');

const verifyEndpoint = `
/**
 * Forgot Password - Verify OTP
 */
authRouter.post('/forgot-password/verify-otp', (req, res) => {
  const { email, otp } = req.body;
  if (!email || !otp) return res.status(400).json({ error: 'Missing fields' });

  db.get(\`SELECT id FROM users WHERE email = ?\`, [email], (err, user: any) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    if (!user) return res.status(400).json({ error: 'Invalid or expired OTP.' });

    const otpHash = crypto.createHash('sha256').update(otp).digest('hex');

    db.get(\`SELECT * FROM password_reset_tokens WHERE userId = ? AND used = 0 AND expiresAt > CURRENT_TIMESTAMP ORDER BY createdAt DESC LIMIT 1\`, [user.id], (err, token: any) => {
        if (err) return res.status(500).json({ error: 'Database error' });
        
        if (!token) return res.status(400).json({ error: 'Invalid or expired OTP.' });

        if (token.attemptCount >= 3) {
             db.run(\`UPDATE password_reset_tokens SET used = 1 WHERE id = ?\`, [token.id]);
             return res.status(400).json({ error: 'Too many failed attempts. Please request a new OTP.' });
        }

        if (token.otpHash !== otpHash) {
             db.run(\`UPDATE password_reset_tokens SET attemptCount = attemptCount + 1 WHERE id = ?\`, [token.id]);
             return res.status(400).json({ error: 'Invalid or expired OTP.' });
        }

        res.json({ message: 'OTP verified successfully' });
    });
  });
});
`;

code = code.replace(/authRouter\.post\('\/forgot-password\/reset'/g, verifyEndpoint + '\n\nauthRouter.post(\'/forgot-password/reset\'');

fs.writeFileSync('src/routes/auth.ts', code);
